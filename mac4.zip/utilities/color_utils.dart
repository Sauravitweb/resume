import 'package:flutter/material.dart';

Color getOppositeColor(Color? currentColor) {
  // If the color is light, return dark color and vice versa
  if (currentColor == null)
    return Colors.black; // Default to black if no color found

  // Calculate the luminance to determine whether the color is light or dark
  double luminance = currentColor.computeLuminance();

  // Return the opposite color based on luminance
  return luminance > 0.5 ? Colors.black : Colors.white;
}
