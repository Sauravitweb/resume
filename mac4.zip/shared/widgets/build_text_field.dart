import 'package:flutter/material.dart';
import 'package:organize/constants/task_constants.dart';

Widget buildInputCard({
  bool autoFocus = false,
  required TextEditingController controller,
  required String label,
  TextInputType keyboardType = TextInputType.text,
  int? maxLines,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 10),
    child: TextField(
      autofocus: autoFocus,
      maxLines: maxLines,
      keyboardType: keyboardType,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),

      controller: controller,
      cursorColor: Colors.blue, // Blue cursor color
      decoration: InputDecoration(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),

        labelText: label,
        labelStyle: const TextStyle(
            color: Colors.blue), // Blue label color when not focused
        floatingLabelStyle: const TextStyle(
          color: Colors.blue,
          fontWeight: FontWeight.bold,
        ), // Blue label color when focused
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16), // Rounded corners
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: Colors.blue,
            width: 2.0, // Blue border when focused
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(
            color: Colors.blue,
            width: 1.8, // Blue border when not focused
          ),
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    ),
  );
}
