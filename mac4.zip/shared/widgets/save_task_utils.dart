import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:organize/screens/Tasks/data/hive/task_hive_service.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:organize/screens/Tasks/services/notification_service.dart';
import 'package:hive/hive.dart';
import 'package:organize/services/task_service.dart';

Future<void> saveOrEditTask({
  required BuildContext context,
  required bool isEdit,
  required TaskService taskService,
  required TaskHiveService taskHiveService,
  required TextEditingController titleController,
  required TextEditingController descriptionController,
  required String selectedCategory,
  required String selectedPriority,
  required DateTime? reminderDateTime,
  Task? existingTask,
}) async {
  if (titleController.text.trim().isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Title cannot be empty')),
    );
    return;
  }

  final user = FirebaseAuth.instance.currentUser;
  final now = DateTime.now();
  final dueDate = reminderDateTime ?? now.add(const Duration(hours: 1));

  // If reminder time is in the past
  if (reminderDateTime != null && reminderDateTime.isBefore(now)) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Reminder time must be in the future!'),
        backgroundColor: Colors.red,
      ),
    );
    return;
  }

  final taskId = isEdit
      ? existingTask!.id
      : DateTime.now().millisecondsSinceEpoch.toString();

  final newTask = Task(
    id: taskId,
    title: titleController.text.trim(),
    description: descriptionController.text.trim(),
    dueDate: dueDate,
    priority: selectedPriority,
    isCompleted: false,
    category: selectedCategory,
    userId: user?.uid ?? 'offline_user',
    reminderDateTime: reminderDateTime,
    updatedAt: DateTime.now(),
  );

  // Schedule local notification
  await scheduleNotification(newTask, context, reminderDateTime);

  try {
    if (isEdit) {
      await taskService.updateTask(taskId, {
        'title': newTask.title,
        'description': newTask.description,
        'category': newTask.category,
        'priority': newTask.priority,
        'reminderDateTime': newTask.reminderDateTime,
        'dueDate': newTask.dueDate,
      });
      await taskService.editTask(taskId, newTask);
    } else {
      if (user != null) {
        await taskService.addTask(newTask);
        await taskService.syncTasks();
      }
    }

    await taskHiveService.addTask(newTask);
  } catch (e) {
    final box = await Hive.openBox<Task>('tasks');
    await box.put(taskId, newTask);
  }

  if (context.mounted) {
    Navigator.pop(context, true);
  }
}
