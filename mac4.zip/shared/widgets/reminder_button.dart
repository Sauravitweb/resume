import 'package:flutter/material.dart';

class ReminderButton extends StatelessWidget {
  final DateTime? reminderDateTime;
  final ValueChanged<DateTime> onDateTimeSelected;

  const ReminderButton({
    Key? key,
    required this.reminderDateTime,
    required this.onDateTimeSelected,
  }) : super(key: key);

  Future<void> _selectDateTime(BuildContext context) async {
    try {
      final pickedDate = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: DateTime.now(),
        lastDate: DateTime(2100),
      );

      if (pickedDate != null) {
        final pickedTime = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );

        if (pickedTime != null) {
          final selectedDateTime = DateTime(
            pickedDate.year,
            pickedDate.month,
            pickedDate.day,
            pickedTime.hour,
            pickedTime.minute,
          );

          if (selectedDateTime.isAfter(DateTime.now())) {
            onDateTimeSelected(selectedDateTime);
          } else {
            throw Exception('Selected time must be in the future.');
          }
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            e.toString(),
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _selectDateTime(context),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          color: reminderDateTime == null
              ? const Color(0xFF0288D1)
              : const Color(0xFF0277BD),
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              blurRadius: 4,
              spreadRadius: 1,
            ),
          ],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        child: Text(
          reminderDateTime == null
              ? 'Set Reminder'
              : 'Reminder set for: ${reminderDateTime!.toLocal().toString().split(" ")[0]} at ${reminderDateTime!.toLocal().toString().split(" ")[1].substring(0, 5)}',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}