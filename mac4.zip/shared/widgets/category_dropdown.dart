import 'package:flutter/material.dart';
import 'package:organize/utilities/color_utils.dart';
import 'package:organize/constants/task_constants.dart';

class CustomDropdown extends StatelessWidget {
  final String label;
  final List<String> items;
  final String selectedValue;
  final void Function(String) onChanged;

  const CustomDropdown({
    super.key,
    required this.label,
    required this.items,
    required this.selectedValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    //  final Color borderColor = Theme.of(context).dividerColor;
    final TextStyle? textStyle = Theme.of(context).textTheme.bodySmall;
    final Color dropdownColor =
        getOppositeColor(Theme.of(context).textTheme.bodySmall!.color);
    final Color iconColor =
        getOppositeColor(Theme.of(context).textTheme.bodySmall!.color);

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: bordercolor),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: DropdownButtonFormField<String>(
        value: selectedValue,
        style: textStyle,
        items: items.map((item) {
          return DropdownMenuItem(
            value: item,
            child: Text(item, style: textStyle),
          );
        }).toList(),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: textStyle,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 8),
        ),
        dropdownColor: dropdownColor,
        icon: Icon(Icons.arrow_drop_down, color: iconColor),
        onChanged: (value) {
          if (value != null) onChanged(value);
        },
      ),
    );
  }
}
