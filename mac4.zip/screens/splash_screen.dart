import 'package:flutter/material.dart';
import 'package:organize/constants/routes.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToNextScreen();
  }

  Future<void> _navigateToNextScreen() async {
    await Future.delayed(const Duration(seconds: 1)); // Splash screen duration
    Navigator.of(context).pushReplacementNamed(homeRoute);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // Set the background color
      body: Center(
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Image.asset(
          'assets/organizelogo.png',
          width: 100, // Adjust size as needed
          height: 100,
          fit: BoxFit.contain,
        ),
        const Text(
          'Powered By AEdiZz!',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ])),
    );
  }
}
