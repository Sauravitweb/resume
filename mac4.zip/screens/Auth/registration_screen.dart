import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:organize/constants/routes.dart';
import 'package:organize/services/auth_service.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _displayNameController = TextEditingController();
  final AuthService _authService = AuthService();
  final GoogleSignIn _googleSignIn = GoogleSignIn();
  bool _isPasswordVisible = false;

  void _register() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();
    final displayName = _displayNameController.text.trim();

    if (email.isEmpty || password.isEmpty || displayName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill in all fields.')),
      );
      return;
    }

    try {
      // Register the user with email and password
      UserCredential userCredential =
          await _authService.registerWithEmail(email, password);

      if (userCredential.user == null) {
        throw Exception("Failed to create user.");
      }

      // Get the user's UID
      String userId = userCredential.user!.uid;

      // Create a reference to the Firestore collection with the path users/{userId}/{userId}
      final userRef =
          FirebaseFirestore.instance.collection('users').doc(userId);

      // Save the user's display name and email in Firestore
      await userRef.set({
        'name': displayName,
        'email': email,
        // 'password': password,
        'profileImageUrl':
            '', // Placeholder, you can update with a profile picture later
        'createdAt': FieldValue.serverTimestamp(),
        'id': userId,
      });

      // Navigate to the profile screen
      // Navigator.pushReplacementNamed(context, '/home');
      Navigator.pushNamedAndRemoveUntil(
          context, homeRoute, (Route<dynamic> route) => false);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        // SnackBar(content: Text('Registration failed: ${e.toString()}')),
        SnackBar(
            content:
                Text('An unexpected error occurred. Please try again later.')),
      );
    }
  }

  Future<void> _signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      // Sign in to Firebase with the Google credentials
      UserCredential userCredential =
          await _authService.signInWithCredential(credential);

      // Get the user's UID
      String userId = userCredential.user?.uid ?? '';

      // Reference to the Firestore collection 'users'
      final userRef =
          FirebaseFirestore.instance.collection('users').doc(userId);

      // Check if the document already exists
      final userDoc = await userRef.get();

      if (userDoc.exists) {
        final userData = userDoc.data() as Map<String, dynamic>;

        // If the field 'isDisabled' exists and is true, update it to false
        if (userData.containsKey('isDisabled') &&
            userData['isDisabled'] == true) {
          await userRef.update({'isDisabled': false});
        }

        // Remove 'toDelete' and 'schedule_for_delete' fields if they exist
        if (userData.containsKey('toDelete') ||
            userData.containsKey('schedule_for_delete')) {
          await userRef.update({
            'toDelete': FieldValue.delete(),
            'schedule_for_delete': FieldValue.delete(),
          });
        }
      } else {
        // Create new user document if it doesn't exist
        await userRef.set({
          'name': googleUser?.displayName ?? 'Unknown',
          'email': googleUser?.email,
          'profileImageUrl': googleUser?.photoUrl,
          'createdAt': FieldValue.serverTimestamp(),
          'id': userId,
        });
      }

      // Navigate to the home screen
      Navigator.pushNamedAndRemoveUntil(
          context, homeRoute, (Route<dynamic> route) => false);
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Google sign-in failed.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Background color for a clean look
      appBar: AppBar(
        title: const Text(
          'Register',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.deepPurpleAccent,
        elevation: 0, // Remove the shadow for a sleek look
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: ListView(
          children: [
            const SizedBox(height: 50),

            // Logo or App name (optional)
            Image.asset(
              'assets/organizelogo.png', // Add logo image here
              width: 150,
              height: 150,
            ),

            const Center(
              child: Text(
                'Join Us!',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurpleAccent,
                ),
              ),
            ),
            const SizedBox(height: 50),

            // Email TextField with custom styling
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                labelStyle: const TextStyle(color: Colors.deepPurpleAccent),
                hintText: 'Enter your email',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 16),

            // Password TextField with custom styling
            TextField(
              controller: _passwordController,
              obscureText: !_isPasswordVisible,
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: const TextStyle(color: Colors.deepPurpleAccent),
                hintText: 'Enter your password',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                // Eye Icon to toggle visibility
                suffixIcon: IconButton(
                  icon: Icon(
                    _isPasswordVisible
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Colors.deepPurpleAccent,
                    size: 24,
                  ),
                  onPressed: () {
                    setState(() {
                      _isPasswordVisible = !_isPasswordVisible;
                    });
                  },
                ),
              ),
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 16),

            // Display Name TextField
            TextField(
              controller: _displayNameController,
              decoration: InputDecoration(
                labelText: 'Name',
                labelStyle: const TextStyle(color: Colors.deepPurpleAccent),
                hintText: 'Enter your name',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 20),

            // Register Button
            ElevatedButton(
              onPressed: _register,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurpleAccent, // Background color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 5, // Add shadow to elevate the button
              ),
              child: const Text(
                'Register',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Sign-in with Google Button
            ElevatedButton.icon(
              onPressed: _signInWithGoogle,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white,
                side: const BorderSide(color: Colors.deepPurpleAccent),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 5,
              ),
              icon: const FaIcon(
                FontAwesomeIcons.google,
                color: Colors.deepPurpleAccent,
                size: 24,
              ),
              label: const Text(
                'Sign in with Google',
                style: TextStyle(
                  color: Colors.deepPurpleAccent,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Login Button to navigate back
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, loginRoute);
              },
              child: const Text(
                'Already have an account? Login here.',
                style: TextStyle(
                  color: Colors.deepPurpleAccent,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
