import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:organize/constants/routes.dart';
import 'package:organize/services/auth_service.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // Import Font Awesome package

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthService _authService = AuthService();
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  bool _isPasswordVisible =
      false; // State variable to toggle password visibility

  void _login() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter email and password')),
      );
      return;
    }

    try {
      // Authenticate the user first
      UserCredential userCredential =
          await _authService.signInWithEmail(email, password);
      User? user = userCredential.user;

      if (user != null) {
        // Fetch the user's document from Firestore
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();

        // if (userDoc.exists) {
        //   final userData = userDoc.data() as Map<String, dynamic>;

        //   // Check if isDisabled is present and true
        //   if (userData.containsKey('isDisabled') &&
        //       userData['isDisabled'] == true) {
        //     // Update isDisabled to false
        //     await userDoc.reference.update({'isDisabled': false});
        //   }
        // }
        if (userDoc.exists) {
          final userData = userDoc.data() as Map<String, dynamic>;

          // Check if the account is disabled
          if (userData.containsKey('isDisabled') &&
              userData['isDisabled'] == true) {
            // Reactivate the account by setting isDisabled to false
            await userDoc.reference.update({'isDisabled': false});
          }

          // Remove 'toDelete' and 'schedule_for_delete' fields if they exist
          if (userData.containsKey('toDelete') ||
              userData.containsKey('schedule_for_delete')) {
            await userDoc.reference.update({
              'toDelete': FieldValue.delete(),
              'schedule_for_delete': FieldValue.delete(),
            });
          }
        }

        // Navigate to home after login
        Navigator.pushReplacementNamed(context, homeRoute);
      }
    } on FirebaseAuthException catch (e) {
      String errorMessage;
      switch (e.code) {
        case 'user-not-found':
          errorMessage = 'Email not registered. Please sign up first.';
          break;
        case 'wrong-password':
          errorMessage = 'Incorrect password. Please try again.';
          break;
        case 'invalid-email':
          errorMessage = 'Invalid email address. Please check and try again.';
          break;
        case 'user-disabled':
          errorMessage = 'This account has been disabled.';
          break;
        default:
          errorMessage =
              'An unexpected error occurred. Please try again later.';
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage)),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('An unexpected error occurred.')),
      );
    }
  }

  Future<void> _signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      final GoogleSignInAuthentication? googleAuth =
          await googleUser?.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth?.accessToken,
        idToken: googleAuth?.idToken,
      );

      // Sign in to Firebase with the Google credentials
      UserCredential userCredential =
          await _authService.signInWithCredential(credential);

      // Get the user's UID
      String userId = userCredential.user?.uid ?? '';

      // Reference to the Firestore collection 'users'
      final userRef =
          FirebaseFirestore.instance.collection('users').doc(userId);

      // Check if the document already exists
      final userDoc = await userRef.get();

      if (userDoc.exists) {
        final userData = userDoc.data() as Map<String, dynamic>;

        // If the field 'isDisabled' exists and is true, update it to false
        if (userData.containsKey('isDisabled') &&
            userData['isDisabled'] == true) {
          await userRef.update({'isDisabled': false});
        }

        // Remove 'toDelete' and 'schedule_for_delete' fields if they exist
        if (userData.containsKey('toDelete') ||
            userData.containsKey('schedule_for_delete')) {
          await userRef.update({
            'toDelete': FieldValue.delete(),
            'schedule_for_delete': FieldValue.delete(),
          });
        }
      } else {
        // Create new user document if it doesn't exist
        await userRef.set({
          'name': googleUser?.displayName ?? 'Unknown',
          'email': googleUser?.email,
          'profileImageUrl': googleUser?.photoUrl,
          'createdAt': FieldValue.serverTimestamp(),
          'id': userId,
        });
      }

      // Navigate to the home screen
      Navigator.pushNamedAndRemoveUntil(
          context, homeRoute, (Route<dynamic> route) => false);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Google sign-in failed.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Background color for a clean look
      appBar: AppBar(
        title: const Text('Login',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurpleAccent,
        elevation: 0, // Remove the shadow for a sleek look
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: ListView(
          children: [
            const SizedBox(height: 50),
            // Logo or App name (optional)
            Image.asset('assets/organizelogo.png',
                width: 150, height: 150), // Add logo image here
            const Center(
              child: Text(
                'Welcome Back!',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurpleAccent,
                ),
              ),
            ),
            const SizedBox(height: 50),

            // Email TextField with custom styling
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                labelStyle: const TextStyle(color: Colors.deepPurpleAccent),
                hintText: 'Enter your email',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 16),

            // Password TextField with custom styling
            TextField(
              controller: _passwordController,
              obscureText:
                  !_isPasswordVisible, // Toggle visibility based on state
              decoration: InputDecoration(
                labelText: 'Password',
                labelStyle: const TextStyle(color: Colors.deepPurpleAccent),
                hintText: 'Enter your password',
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: Colors.grey[200],
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                // Eye Icon to toggle visibility
                suffixIcon: IconButton(
                  icon: Icon(
                    _isPasswordVisible
                        ? Icons.visibility_off
                        : Icons.visibility,
                    color: Colors.deepPurpleAccent,
                    size: 24,
                  ),
                  onPressed: () {
                    setState(() {
                      _isPasswordVisible =
                          !_isPasswordVisible; // Toggle password visibility
                    });
                  },
                ),
              ),
              style: const TextStyle(color: Colors.black),
            ),
            const SizedBox(height: 20),

            // Login Button with smooth transition and shadow
            ElevatedButton(
              onPressed: _login,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurpleAccent, // Background color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 5, // Add shadow to elevate the button
              ),
              child: const Text(
                'Login',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),

            // Sign-in with Google Button with icon
            ElevatedButton.icon(
              onPressed: _signInWithGoogle,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white, // Background color
                side: const BorderSide(color: Colors.deepPurpleAccent),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(vertical: 16),
                elevation: 5, // Add shadow to elevate the button
              ),
              icon: const FaIcon(FontAwesomeIcons.google,
                  color: Colors.deepPurpleAccent, size: 24),
              label: const Text(
                'Sign in with Google',
                style: TextStyle(
                    color: Colors.deepPurpleAccent,
                    fontSize: 16,
                    fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),

            // Register Button with a transition to registration screen
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, registerRoute);
              },
              child: const Text(
                'Don\'t have an account? Register here.',
                style: TextStyle(color: Colors.deepPurpleAccent, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
