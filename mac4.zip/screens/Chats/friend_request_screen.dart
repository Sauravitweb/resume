import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:organize/screens/Chats/message_screen.dart';
import 'package:organize/screens/Chats/user_profile_screen.dart';
import 'package:startapp_sdk/startapp.dart';
import 'package:collection/collection.dart';
import 'package:cached_network_image/cached_network_image.dart';
//import 'package:google_mobile_ads/google_mobile_ads.dart';

class FriendRequestScreen extends StatefulWidget {
  const FriendRequestScreen({super.key});

  @override
  _FriendRequestScreenState createState() => _FriendRequestScreenState();
}

class _FriendRequestScreenState extends State<FriendRequestScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final User? currentUser = FirebaseAuth.instance.currentUser;
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  String searchQuery = '';
  late Stream<QuerySnapshot> _friendRequestsStream;
  late Stream<QuerySnapshot> _friendsStream;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _friendRequestsStream = _firestore
        .collection('friend_requests')
        .where('to', isEqualTo: currentUser!.uid)
        .where('status', isEqualTo: 'pending')
        .snapshots();

    _friendsStream = _firestore
        .collection('friends')
        .where('users', arrayContains: currentUser!.uid)
        .snapshots();

    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/4601109421', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       // print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  // Function to send a friend request
  Future<void> _sendFriendRequest(String recipientId) async {
    final requestId = _firestore.collection('friend_requests').doc().id;

    await _firestore.collection('friend_requests').doc(requestId).set({
      'from': currentUser!.uid,
      'to': recipientId,
      'status': 'pending',
    });
  }

  // Function to navigate to message screen
  void _navigateToMessageScreen(String recipientId, String recipientName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MessageScreen(
          recipientId: recipientId,
          recipientName: recipientName,
        ),
      ),
    );
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }
  // Widget _buildSearchResults() {
  //   // Check if the search query is empty
  //   if (searchQuery.isEmpty) {
  //     return const Center(child: Text('Search for users by name'));
  //   }

  //   return StreamBuilder<QuerySnapshot>(
  //     stream: _firestore
  //         .collection('users')
  //         .where('name', isGreaterThanOrEqualTo: searchQuery)
  //         .where('name', isLessThanOrEqualTo: '$searchQuery\uf8ff')
  //         .snapshots(),
  //     builder: (context, snapshot) {
  //       // Show loading indicator while fetching data
  //       if (!snapshot.hasData) {
  //         return const Center(
  //             child: CircularProgressIndicator(color: Colors.blueAccent));
  //       }

  //       // Get the list of users
  //       final users = snapshot.data!.docs;

  //       // // Show 'No users found' if the search returns no results
  //       // if (users.isEmpty) {
  //       //   return const Center(child: Text('No users found'));
  //       // }
  //       final filteredUsers = users.where((user) {
  //         final userData = user.data() as Map<String, dynamic>;
  //         final bool isDisabled =
  //             userData['isDisabled'] ?? false; // Default to false if missing
  //         return !isDisabled;
  //       }).toList();

  //       if (filteredUsers.isEmpty) {
  //         return const Center(child: Text('No users found'));
  //       }

  //       return ListView.builder(
  //         shrinkWrap: true, // Prevents ListView from taking up infinite space
  //         itemCount: users.length,
  //         itemBuilder: (context, index) {
  //           final user = users[index];
  //           final userId = user.id;
  //           final userName = user['name'];
  //           final profileImageUrl = user['profileImageUrl'] ?? '';

  //           // Don't show the current user in the search results
  //           if (userId == currentUser!.uid) {
  //             return const SizedBox.shrink();
  //           }

  //           // return StreamBuilder<QuerySnapshot>(
  //           //   stream: _firestore
  //           //       .collection('friend_requests')
  //           //       .where('from',
  //           //           isEqualTo:
  //           //               currentUser!.uid) // Filter by sender (current user)
  //           //       .where('to', isEqualTo: userId) // Filter by recipient (user)
  //           //       .limit(1)
  //           //       .snapshots(), // Stream for real-time updates

  //            builder: (context, requestSnapshot) {
  //               if (!requestSnapshot.hasData) {
  //                 return ListTile(
  //                   leading: CircleAvatar(
  //                     backgroundImage: profileImageUrl.isNotEmpty
  //                         ? NetworkImage(profileImageUrl)
  //                         : null,
  //                     child: profileImageUrl.isEmpty
  //                         ? const Icon(Icons.person)
  //                         : null,
  //                   ),
  //                   title: Text(userName),
  //                   trailing: IconButton(
  //                     icon: const Icon(Icons.person_add),
  //                     onPressed: () => _sendFriendRequest(userId),
  //                   ),
  //                 );
  //               }

  //               final requests = requestSnapshot.data!.docs;
  //               String iconStatus = 'send'; // Default to 'send request' icon
  //               bool isRequestPending = false;
  //               bool isRequestAccepted = false;

  //               if (requests.isNotEmpty) {
  //                 final request = requests.first;
  //                 final status = request['status'];

  //                 if (status == 'pending') {
  //                   iconStatus = 'pending'; // Pending request
  //                   isRequestPending = true;
  //                 } else if (status == 'accepted') {
  //                   iconStatus = 'accepted'; // Accepted request
  //                   isRequestAccepted = true;
  //                 }
  //               }

  //               return ListTile(
  //                 leading: CircleAvatar(
  //                   backgroundImage: profileImageUrl.isNotEmpty
  //                       ? NetworkImage(profileImageUrl)
  //                       : null,
  //                   child: profileImageUrl.isEmpty
  //                       ? const Icon(Icons.person)
  //                       : null,
  //                 ),
  //                 title: Text(userName),
  //                 trailing: Row(
  //                   mainAxisSize: MainAxisSize.min,
  //                   children: [
  //                     iconStatus == 'send'
  //                         ? ElevatedButton(
  //                             onPressed: () => _sendFriendRequest(userId),
  //                             child: const Text('Send Request'),
  //                           )
  //                         : iconStatus == 'pending'
  //                             ? const Icon(Icons.pending)
  //                             : iconStatus == 'accepted'
  //                                 ? const Icon(
  //                                     Icons.check_circle,
  //                                     color: Colors
  //                                         .green, // Tick icon for accepted friends
  //                                   )
  //                                 : const SizedBox
  //                                     .shrink(), // If no request, don't show anything
  //                     IconButton(
  //                       icon: const Icon(Icons.message),
  //                       onPressed: () =>
  //                           _navigateToMessageScreen(userId, userName),
  //                     ),
  //                   ],
  //                 ),
  //                 onTap: () {
  //                   // Navigate to the friend's profile
  //                   _navigateToProfile(userId);
  //                 },
  //               );
  //             },
  //           );
  //         },
  //       );
  //     },
  //   );
  // }
  Widget _buildSearchResults() {
    if (searchQuery.isEmpty) {
      return const Center(child: Text('Search for users by name'));
    }

    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('users')
          .where('name', isGreaterThanOrEqualTo: searchQuery)
          .where('name', isLessThanOrEqualTo: '$searchQuery\uf8ff')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }

        final users = snapshot.data!.docs;

        final filteredUsers = users.where((user) {
          final userData = user.data() as Map<String, dynamic>;
          final bool isDisabled = userData['isDisabled'] ?? false;
          return !isDisabled;
        }).toList();

        if (filteredUsers.isEmpty) {
          return const Center(child: Text('No users found'));
        }

        return ListView.builder(
          shrinkWrap: true,
          itemCount: filteredUsers.length,
          itemBuilder: (context, index) {
            final user = filteredUsers[index];
            final userId = user.id;
            final userName = user['name'];
            final profileImageUrl = user['profileImageUrl'] ?? '';

            if (userId == currentUser!.uid) {
              return const SizedBox.shrink();
            }

            return StreamBuilder<QuerySnapshot>(
              stream: _firestore
                  .collection('friend_requests')
                  .where('from', whereIn: [currentUser!.uid, userId]).where(
                      'to',
                      whereIn: [currentUser!.uid, userId]).snapshots(),
              builder: (context, requestSnapshot) {
                if (!requestSnapshot.hasData) {
                  return _buildUserTile(
                      userName, profileImageUrl, userId, 'send');
                }

                final requests = requestSnapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final from = data['from'];
                  final to = data['to'];
                  return (from == currentUser!.uid && to == userId) ||
                      (from == userId && to == currentUser!.uid);
                }).toList();

                String iconStatus = 'send';
                if (requests.isNotEmpty) {
                  final status = requests.first['status'];
                  if (status == 'pending') {
                    iconStatus = 'pending';
                  } else if (status == 'accepted') {
                    iconStatus = 'accepted';
                  }
                }

                return _buildUserTile(
                    userName, profileImageUrl, userId, iconStatus);
              },
            );
          },
        );
      },
    );
  }

  Widget _buildUserTile(String userName, String profileImageUrl, String userId,
      String iconStatus) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage:
            profileImageUrl.isNotEmpty ? NetworkImage(profileImageUrl) : null,
        child: profileImageUrl.isEmpty ? const Icon(Icons.person) : null,
      ),
      title: Text(userName),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          iconStatus == 'send'
              ? ElevatedButton(
                  onPressed: () => _sendFriendRequest(userId),
                  child: const Text('Send Request'),
                )
              : iconStatus == 'pending'
                  ? const Icon(Icons.pending)
                  : iconStatus == 'accepted'
                      ? const Icon(Icons.check_circle, color: Colors.green)
                      : const SizedBox.shrink(),
          IconButton(
            icon: const Icon(Icons.message),
            onPressed: () => _navigateToMessageScreen(userId, userName),
          ),
        ],
      ),
      onTap: () => _navigateToProfile(userId),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Friend Requests'),
      ),
      body: Column(
        children: [
          Expanded(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    controller: _searchController,
                    cursorColor: Colors.blue, // Blinking cursor color
                    decoration: InputDecoration(
                      labelText: 'Search For Users',
                      labelStyle: const TextStyle(
                          color: Colors.blue), // Label color when not focused
                      floatingLabelStyle: const TextStyle(
                          color: Colors.blue), // Label color when focused
                      border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(12.0), // Rounded corners
                      ),
                      prefixIcon: const Icon(
                        Icons.search,
                        color: Colors.blue,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                          vertical: 8.0, horizontal: 12.0), // Reduces height
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: Colors.blue,
                            width: 2.0), // Blue border when focused
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: Colors.blue,
                            width: 1.0), // Blue border when not focused
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                    ),
                    onChanged: (value) {
                      setState(() {
                        searchQuery = value.trim();
                      });
                    },
                  ),
                ),
                Expanded(
                  child: ListView(
                    shrinkWrap:
                        true, // This prevents ListView from taking infinite space
                    children: [
                      // Only show search results if the search query is not empty
                      if (searchQuery.isNotEmpty) _buildSearchResults(),
                      const Divider(),
                      // Received friend requests
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('Received Friend Requests',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                      _buildReceivedRequests(),
                      const Divider(),
                      // Accepted friends
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('Your Friends',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.bold)),
                      ),

                      _buildAcceptedFriends(),
                    ],
                  ),
                ),
              ],
            ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget _buildAcceptedFriends() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('friends')
          .where('users', arrayContains: currentUser!.uid)
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }

        final friends = snapshot.data!.docs;

        if (friends.isEmpty) {
          return const Center(
            child: Text(
              'You have no friends yet.',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
          );
        }

        return ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: friends.length,
          itemBuilder: (context, index) {
            final friend = friends[index];
            final users = friend['users'] as List;
            final friendId =
                users.first == currentUser!.uid ? users.last : users.first;

            return FutureBuilder<DocumentSnapshot>(
              future: _firestore.collection('users').doc(friendId).get(),
              builder: (context, userSnapshot) {
                if (!userSnapshot.hasData) {
                  return const SizedBox.shrink();
                }

                // Check if isDisabled exists and is true

                final user = userSnapshot.data!;
                final userData =
                    userSnapshot.data!.data() as Map<String, dynamic>?;

                // Ensure 'isDisabled' field exists before accessing it
                final bool isDisabled =
                    userData != null && userData.containsKey('isDisabled')
                        ? userData['isDisabled'] as bool
                        : false;

                if (isDisabled) {
                  return const SizedBox.shrink();
                }
                final profileImageUrl = user['profileImageUrl'] ?? '';
                final friendName = user['name'] ?? 'Unknown User';
                final userId = user.id; // Using Firestore document ID as userId

                return Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 3,
                  child: ListTile(
                    leading: GestureDetector(
                      onTap: () {
                        _navigateToProfile(userId);
                      },
                      child: CircleAvatar(
                        radius: 30,
                        backgroundImage: profileImageUrl.isNotEmpty
                            ? CachedNetworkImageProvider(profileImageUrl)
                            : null,
                        child: profileImageUrl.isEmpty
                            ? const Icon(Icons.person, size: 30)
                            : null,
                      ),
                    ),
                    title: Text(
                      friendName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Text(
                      'Friend since: ${friend['createdAt']?.toDate()?.toLocal().toString().split(' ')[0] ?? "Unknown"}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    trailing: IconButton(
                      icon: Icon(
                        Icons.chat,
                        color: Theme.of(context).primaryColor,
                      ),
                      onPressed: () {
                        _startChat(userId, friendName);
                      },
                    ),
                    onTap: () {
                      _navigateToProfile(userId);
                    },
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  void _navigateToProfile(String userId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserProfileScreen(userId: userId),
      ),
    );
  }

  void _startChat(String recipientId, String recipientName) {
    // Navigate to the message screen with the selected friend
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MessageScreen(
          recipientId: recipientId,
          recipientName: recipientName,
        ),
      ),
    );
  }

  Widget _buildReceivedRequests() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('friend_requests')
          .where('to', isEqualTo: currentUser!.uid)
          .where('status', isEqualTo: 'pending')
          .snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }

        final requests = snapshot.data!.docs;

        if (requests.isEmpty) {
          return const Center(
            child: Text(
              'No pending friend requests',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
            ),
          );
        }

        return ListView.builder(
          shrinkWrap: true,
          itemCount: requests.length,
          itemBuilder: (context, index) {
            final request = requests[index];
            final senderId = request['from'];
            final requestId = request.id;

            return FutureBuilder<DocumentSnapshot>(
              future: _firestore.collection('users').doc(senderId).get(),
              builder: (context, userSnapshot) {
                if (!userSnapshot.hasData) {
                  return const SizedBox.shrink();
                }

                final user = userSnapshot.data!;
                final senderName = user['name'];
                final profileImageUrl = user['profileImageUrl'];
                // final bool isDisabled = user['isDisabled'] ?? false;
                final userData =
                    userSnapshot.data!.data() as Map<String, dynamic>?;

                // Ensure 'isDisabled' field exists before accessing it
                final bool isDisabled =
                    userData != null && userData.containsKey('isDisabled')
                        ? userData['isDisabled'] as bool
                        : false;

                if (isDisabled) {
                  return const SizedBox.shrink(); // Hide disabled users
                }
                return Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 3,
                  child: ListTile(
                    leading: CircleAvatar(
                      radius: 30,
                      backgroundImage: profileImageUrl != null
                          ? NetworkImage(profileImageUrl)
                          : null,
                      child: profileImageUrl == null
                          ? const Icon(Icons.person, size: 30)
                          : null,
                    ),
                    title: Text(
                      senderName,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    // subtitle: Text(
                    //   'Sent you a friend request',
                    //   style: TextStyle(
                    //     fontSize: 14,
                    //     color: Colors.grey[600],
                    //   ),
                    // ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ElevatedButton(
                          onPressed: () =>
                              _acceptFriendRequest(requestId, senderId),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8), // Reduced padding
                          ),
                          child: const Text(
                            'Accept',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors
                                  .white, // Smaller font size for the button text
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        ElevatedButton(
                          onPressed: () => _rejectFriendRequest(requestId),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 8), // Reduced padding
                          ),
                          child: const Text(
                            'Reject',
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors
                                  .white, // Smaller font size for the button text
                            ),
                          ),
                        ),
                      ],
                    ),
                    onTap: () {
                      _navigateToProfile(senderId);
                    },
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  void _rejectFriendRequest(String requestId) {
    _firestore.collection('friend_requests').doc(requestId).update({
      'status': 'rejected',
    });
  }

  Future<void> _acceptFriendRequest(String requestId, String senderId) async {
    final batch = _firestore.batch();

    try {
      // Update the status of the friend request to 'accepted'
      final friendRequestRef =
          _firestore.collection('friend_requests').doc(requestId);
      batch.update(friendRequestRef, {'status': 'accepted'});

      // Fetch all documents in 'friends' collection containing the current user or sender
      final existingFriendsQuery = await _firestore
          .collection('friends')
          .where('users', arrayContains: currentUser!.uid)
          .get();

      // Delete any existing friendships between the current user and sender
      for (final doc in existingFriendsQuery.docs) {
        final users = doc['users'] as List<dynamic>;
        if (users.contains(senderId)) {
          batch.delete(doc.reference);
        }
      }

      // Add the new friendship
      final newFriendRef = _firestore.collection('friends').doc();
      batch.set(newFriendRef, {
        'users': [currentUser!.uid, senderId],
        'createdAt': FieldValue.serverTimestamp(),
      });

      // Commit the batch
      await batch.commit();

      // Notify the user
      // ScaffoldMessenger.of(context).showSnackBar(
      //   const SnackBar(content: Text('Friend request accepted!')),
      // );
    } catch (e) {
      // Handle errors
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error accepting friend request: $e')),
      // );
    }
  }
}
