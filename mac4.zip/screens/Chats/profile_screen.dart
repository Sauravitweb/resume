import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:image/image.dart' as img; // For image resizing and compression
import 'package:organize/constants/routes.dart';
import 'package:organize/screens/Chats/user_profile_screen.dart';

import 'package:organize/services/settings_service.dart';

import 'package:image_cropper/image_cropper.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:organize/shared/widgets/build_text_field.dart';

class SettingsProvider extends ChangeNotifier {
  bool _darkMode = false;

  bool get darkMode => _darkMode;

  Future<void> fetchSettings(String userId) async {
    final settings = await SettingsService().getSettings(userId);
    _darkMode = settings.darkMode;
    notifyListeners();
  }
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final User? user = FirebaseAuth.instance.currentUser;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _websiteController = TextEditingController();
  String? _profileImageUrl;
  File? _profileImage;
  List<String> _friends = [];
  final User? currentUser = FirebaseAuth.instance.currentUser;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Details section
  final TextEditingController _currentTownController = TextEditingController();
  final TextEditingController _homeTownController = TextEditingController();
  final TextEditingController _relationshipController = TextEditingController();
  final TextEditingController _educationController = TextEditingController();
  final TextEditingController _workplaceController = TextEditingController();

  @override
  void initState() {
    super.initState();

    _fetchUserProfile();
    _buildFriendsSection();

    _fetchSettings();
  }

  final settingsService = SettingsService();
  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
      });
    } catch (error) {
      // print("Error fetching settings: $error");
    }
  }

  bool _darkMode = false;

  Future<void> _fetchUserProfile() async {
    if (user != null) {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user!.uid)
          .get();
      if (userDoc.exists) {
        _nameController.text = userDoc['name'] ?? '';
        _emailController.text = userDoc['email'] ?? '';
        _phoneController.text = userDoc['phone'] ?? '';
        _bioController.text = userDoc['bio'] ?? '';
        _websiteController.text = userDoc['website'] ?? '';
        _profileImageUrl = userDoc['profileImageUrl'] ?? '';
        _currentTownController.text = userDoc['currentTown'] ?? '';
        _homeTownController.text = userDoc['homeTown'] ?? '';
        _relationshipController.text = userDoc['relationshipStatus'] ?? '';
        _educationController.text = userDoc['education'] ?? '';
        _workplaceController.text = userDoc['workplace'] ?? '';
        _friends = List<String>.from(userDoc['friends'] ?? []);
        setState(() {});
      }
    }
  }

  Future<void> _pickAndCropImage() async {
    try {
      final ImagePicker picker = ImagePicker();

      // Pick image from gallery
      final XFile? pickedImage =
          await picker.pickImage(source: ImageSource.gallery);

      if (pickedImage != null) {
        // Crop the image
        final CroppedFile? croppedImage = await ImageCropper().cropImage(
          sourcePath: pickedImage.path,
          aspectRatio:
              const CropAspectRatio(ratioX: 1, ratioY: 1), // Square crop
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Your Image',
              toolbarColor: Colors.blue,
              toolbarWidgetColor: Colors.white,
              hideBottomControls: true,
              lockAspectRatio: true,
            ),
            IOSUiSettings(
              title: 'Crop Your Image',
            ),
          ],
        );

        if (croppedImage != null) {
          // Compress and upload the cropped image
          final compressedImage = await _compressImage(File(croppedImage.path));
          setState(() {
            _profileImage = compressedImage;
          });

          final downloadUrl = await _uploadImage(compressedImage);
          if (downloadUrl != null) {
            // print("Uploaded Image URL: $downloadUrl");
          }
        }
      }
    } catch (e) {
      // print("Error during image picking or cropping: $e");
    }
  }

//upper one was previous one
  Future<File> _compressImage(File file) async {
    try {
      // Get the original file size
      final originalBytes = await file.readAsBytes();
      final originalSizeKB = originalBytes.lengthInBytes / 1024; // in KB

      // If the original image size is less than 120 KB, skip compression
      if (originalSizeKB < 120) {
        return file;
      }

      // Decode the image
      final decodedImage = img.decodeImage(originalBytes);

      if (decodedImage != null) {
        // Resize the image to 300x300
        final resizedImage =
            img.copyResize(decodedImage, width: 300, height: 300);

        // Compress the image (quality: 75)
        final compressedBytes = img.encodeJpg(resizedImage, quality: 85);

        // Save to temporary file
        final tempDir = Directory.systemTemp;
        final compressedFile =
            File('${tempDir.path}/compressed_${file.path.split('/').last}');
        await compressedFile.writeAsBytes(compressedBytes);

        return compressedFile;
      }
    } catch (e) {
      // Handle any errors here
      print("Error compressing image: $e");
    }

    // Return the original file if something goes wrong
    return file;
  }

  Future<String?> _uploadImage(File imageFile) async {
    try {
      final storageRef =
          FirebaseStorage.instance.ref().child('profile_images/${user!.uid}');
      await storageRef.putFile(imageFile);
      return await storageRef.getDownloadURL();
    } catch (e) {
      // print("Error uploading image: $e");
      return null;
    }
  }

  void _updateProfile() async {
    if (user != null) {
      try {
        // Check if name is present before updating
        // if (_nameController.text.isNotEmpty) {
        //   await user!.updateDisplayName(_nameController.text);
        // } else {
        //   ScaffoldMessenger.of(context).showSnackBar(
        //       const SnackBar(content: Text('Name cannot be empty')));
        //   return; // Exit if name is not provided
        // }
        if (_nameController.text.trim().isNotEmpty) {
          await user!.updateDisplayName(_nameController.text.trim());
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Name cannot be empty')),
          );
          return; // Exit if name is not provided
        }

        // Upload image if it's provided
        String? imageUrl = _profileImage != null
            ? await _uploadImage(_profileImage!)
            : _profileImageUrl;

        // Update Firestore with provided information
        await FirebaseFirestore.instance
            .collection('users')
            .doc(user!.uid)
            .set({
          'name': _nameController.text,
          'email': _emailController.text,
          'phone': _phoneController.text,
          'bio': _bioController.text,
          'website': _websiteController.text,
          'profileImageUrl': imageUrl,
          'currentTown': _currentTownController.text,
          'homeTown': _homeTownController.text,
          'relationshipStatus': _relationshipController.text,
          'education': _educationController.text,
          'workplace': _workplaceController.text,
          'friends': _friends,
          'id': user!.uid,
        }, SetOptions(merge: true));

        // Show success message
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Profile Updated')));

        // Fetch the updated profile information
        await _fetchUserProfile();
      } catch (e) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        centerTitle: true,
        elevation: 4,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.settings,
            ),
            onPressed: () => Navigator.pushNamed(context, settingsRoute),
          ),
        ],
        // backgroundColor: Colors.blueAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: SafeArea(
          child: Column(
            children: [
              GestureDetector(
                onTap: _pickAndCropImage,
                child: CircleAvatar(
                  radius: 80,
                  backgroundImage: _profileImage != null
                      ? FileImage(_profileImage!) // Local file
                      : _profileImageUrl != null && _profileImageUrl!.isNotEmpty
                          ? CachedNetworkImageProvider(
                              _profileImageUrl!) // Cached network image
                          : null,
                  child: _profileImage == null &&
                          (_profileImageUrl == null ||
                              _profileImageUrl!.isEmpty)
                      ? const Icon(Icons.camera_alt, size: 80)
                      : null,
                ),
              ),
              const SizedBox(height: 20),
              buildInputCard(controller: _nameController, label: 'Name'),
              buildInputCard(controller: _bioController, label: 'Bio'),
              buildInputCard(controller: _phoneController, label: 'Phone'),
              _buildDetailsSection(),
              _buildLinksSection(),
              _buildFriendsSection(),
              ElevatedButton(
                onPressed: _updateProfile,
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding:
                      const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                  backgroundColor: Colors.blueAccent,
                ),
                child: const Text('Update Profile'),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Widget _buildDetailsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Details',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        buildInputCard(
            controller: _currentTownController, label: 'Current Town/City'),
        buildInputCard(controller: _homeTownController, label: 'Home Town'),
        buildInputCard(
            controller: _relationshipController, label: 'Relationship Status'),
        buildInputCard(controller: _educationController, label: 'Education'),
        buildInputCard(controller: _workplaceController, label: 'Workplace'),
      ],
    );
  }

  void _navigateToProfile(String userId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserProfileScreen(userId: userId),
      ),
    );
  }

  Widget _buildLinksSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Links',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            )),
        buildInputCard(
            controller: _websiteController, label: 'Website or Social Links'),
      ],
    );
  }

  Widget _buildFriendsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Friends',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 200, // Adjust the height as needed
          child: StreamBuilder<QuerySnapshot>(
            stream: _firestore
                .collection('friends')
                .where('users', arrayContains: currentUser!.uid)
                .snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) {
                return const Center(
                    child: CircularProgressIndicator(color: Colors.blueAccent));
              }

              final friends = snapshot.data!.docs;
              if (friends.isEmpty) {
                return const Center(child: Text('You have no friends yet.'));
              }

              return FutureBuilder<List<Map<String, dynamic>>>(
                future: _fetchValidFriendsFast(friends),
                builder: (context, validFriendsSnapshot) {
                  if (!validFriendsSnapshot.hasData ||
                      validFriendsSnapshot.data!.isEmpty) {
                    return const Center(
                        child: Text('You have no friends yet.'));
                  }

                  final validFriends = validFriendsSnapshot.data!;
                  return GridView.builder(
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3, // 3 items per row
                      crossAxisSpacing: 8.0,
                      mainAxisSpacing: 8.0,
                      childAspectRatio: 1.0,
                    ),
                    itemCount:
                        validFriends.length > 24 ? 24 : validFriends.length,
                    itemBuilder: (context, index) {
                      final friendData = validFriends[index];
                      final friendId = friendData['id'];
                      final friendName = friendData['name'];
                      final profileImageUrl = friendData['profileImageUrl'];

                      return GestureDetector(
                        onTap: () => _navigateToProfile(friendId),
                        child: Column(
                          children: [
                            CircleAvatar(
                              radius: 40,
                              backgroundImage: profileImageUrl.isNotEmpty
                                  ? CachedNetworkImageProvider(profileImageUrl)
                                  : null,
                              child: profileImageUrl.isEmpty
                                  ? const Icon(Icons.person, size: 40)
                                  : null,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              friendName,
                              style: const TextStyle(
                                  fontSize: 12, fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
        TextButton(
          onPressed: () {
            Navigator.pushNamed(context, friendRequestRoute);
          },
          child: const Text(
            'See All Friends',
            style: TextStyle(color: Colors.blue),
          ),
        ),
      ],
    );
  }

  /// **Optimized function to fetch valid friends in parallel**
  Future<List<Map<String, dynamic>>> _fetchValidFriendsFast(
      List<QueryDocumentSnapshot> friends) async {
    List friendIds = friends.map((friend) {
      final users = friend['users'] as List;
      return users.first == currentUser!.uid ? users.last : users.first;
    }).toList();

    // Fetch all user documents in parallel
    List<Future<DocumentSnapshot>> userFetches = friendIds
        .map((id) => _firestore.collection('users').doc(id).get())
        .toList();
    List<DocumentSnapshot> userDocs = await Future.wait(userFetches);

    // Process user data efficiently
    return userDocs.where((doc) {
      final data = doc.data() as Map<String, dynamic>? ?? {};
      return !(data.containsKey('isDisabled') && data['isDisabled'] == true);
    }).map((doc) {
      final data = doc.data() as Map<String, dynamic>;
      return {
        'id': doc.id,
        'name': data['name'] ?? 'Unknown User',
        'profileImageUrl': data['profileImageUrl'] ?? '',
      };
    }).toList();
  }
}
