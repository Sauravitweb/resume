import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:organize/screens/full_screen_image_viewer.dart';
import 'package:organize/screens/Chats/message_screen.dart';
import 'package:photo_view/photo_view.dart';
import 'package:startapp_sdk/startapp.dart';

class UserProfileScreen extends StatefulWidget {
  final String userId;

  const UserProfileScreen({super.key, required this.userId});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  Future<bool> _areFriends(String currentUserId) async {
    final id1 = '$currentUserId${widget.userId}';
    final id2 = '${widget.userId}$currentUserId';

    final doc1 =
        await FirebaseFirestore.instance.collection('friends').doc(id1).get();

    if (doc1.exists) return true;

    final doc2 =
        await FirebaseFirestore.instance.collection('friends').doc(id2).get();

    return doc2.exists;
  }

  void _startChat(
      BuildContext context, String recipientId, String recipientName) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MessageScreen(
          recipientId: recipientId,
          recipientName: recipientName,
        ),
      ),
    );
  }

  void _showFullScreenImage(BuildContext context, String imageUrl) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FullScreenImageViewer(imageUrl: imageUrl),
      ),
    );
  }

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      print("Failed to load banner: $error");
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser!.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
        centerTitle: true,
        elevation: 0,
      ),
      body: Column(
        children: [
          Expanded(
            child: FutureBuilder<DocumentSnapshot>(
              future: FirebaseFirestore.instance
                  .collection('users')
                  .doc(widget.userId)
                  .get(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                      child:
                          CircularProgressIndicator(color: Colors.blueAccent));
                }
                if (!snapshot.hasData || !snapshot.data!.exists) {
                  return const Center(child: Text('User not found.'));
                }

                var userData = snapshot.data!.data() as Map<String, dynamic>;
                bool isDisabled = userData['isDisabled'] ?? false;

                if (isDisabled) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Text(
                        'This account is no longer available',
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.red),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  );
                }

                return Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ListView(
                    children: [
                      // Profile Image
                      Center(
                        child: GestureDetector(
                          onTap: () {
                            if (userData['profileImageUrl'] != null) {
                              _showFullScreenImage(
                                  context, userData['profileImageUrl']);
                            }
                          },
                          child: CircleAvatar(
                            backgroundImage: NetworkImage(userData[
                                    'profileImageUrl'] ??
                                'https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png'),
                            radius: 80,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      Card(
                        color: Theme.of(context).cardColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 5,
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                userData['name'],
                                style: const TextStyle(
                                    fontSize: 26, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                userData['bio'] ?? 'No bio available.',
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 16),
                              _buildDetailRow(
                                  'Current Town', userData['currentTown']),
                              _buildDetailRow(
                                  'Education', userData['education']),
                              _buildDetailRow(
                                  'Home Town', userData['homeTown']),
                              _buildDetailRow('Relationship Status',
                                  userData['relationshipStatus']),
                              _buildDetailRow('Website', userData['website']),
                              _buildDetailRow(
                                  'Workplace', userData['workplace']),
                              _buildDetailRow('Phone', userData['phone']),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (widget.userId != currentUserId) ...[
                        FutureBuilder<bool>(
                          future: _areFriends(currentUserId),
                          builder: (context, friendSnapshot) {
                            if (friendSnapshot.connectionState ==
                                ConnectionState.waiting) {
                              return const Center(
                                child: CircularProgressIndicator(
                                    color: Colors.blueAccent),
                              );
                            }

                            return Column(
                              children: [
                                const SizedBox(height: 16),
                                ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      vertical: 12,
                                      horizontal: 30,
                                    ),
                                    backgroundColor: Colors.green,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(30),
                                    ),
                                  ),
                                  onPressed: () => _startChat(
                                    context,
                                    widget.userId,
                                    userData['name'],
                                  ),
                                  child: const Text(
                                    'Start Chat',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Text(
            '$label: ',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
          Expanded(
            child: Text(
              value ?? 'Not specified',
              style: const TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}
