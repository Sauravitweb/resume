import 'dart:convert';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
//import 'package:jitsi_meet_flutter_sdk/jitsi_meet_flutter_sdk.dart';

import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter_sound/flutter_sound.dart' as fs;
import 'package:intl/intl.dart';
import 'package:organize/screens/Chats/user_profile_screen.dart';
// import 'package:organize/screens/LiveKitCallScreen.dart';
import 'package:organize/screens/full_screen_image_viewer.dart';

import 'package:organize/services/settings_service.dart';

import 'package:cached_network_image/cached_network_image.dart';
import 'dart:io';

import 'package:image_picker/image_picker.dart';

import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';

import 'package:googleapis_auth/auth_io.dart';

import 'dart:typed_data';
import 'package:image/image.dart' as img; // Import image package

class MessageScreen extends StatefulWidget {
  final String recipientId;
  final String recipientName;
  final String? recipientProfileUrl;

  const MessageScreen({
    super.key,
    required this.recipientId,
    required this.recipientName,
    this.recipientProfileUrl,
  });

  @override
  _MessageScreenState createState() => _MessageScreenState();
}

class _MessageScreenState extends State<MessageScreen> {
  bool _isDarkTheme = false;

  bool _isEmojiMenuVisible = false;

  // Sample emoji list from keyboard (use emojis available on devices)
  final List<String> emojiList = ['😀', '😂', '😍', '😢', '😡'];
  final senderId = FirebaseAuth.instance.currentUser!.uid;

  // Toggle theme mode

  final TextEditingController _messageController = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final User? currentUser = FirebaseAuth.instance.currentUser;
  _getuid() {
    final User? currentUser = FirebaseAuth.instance.currentUser;
    return currentUser?.uid
        as String; // Returns the UID of the currently signed-in user or null if no user is signed in
  }

  // final fs.FlutterSoundRecorder _audioRecorder = fs.FlutterSoundRecorder();

  final ImagePicker _imagePicker =
      ImagePicker(); // Create an instance of ImagePicker

  String recipientProfileUrl = '';

  @override
  void initState() {
    super.initState();

    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final data = message.data;
      if (data['type'] == 'CALL_INVITE') {
        final room = data['room'];
        final senderId = data['senderId'];
        final callType = data['callType'] ?? 'video';

        // _showIncomingCallDialog(
        //   room: room,
        //   senderId: senderId,
        //   callType: callType,
        // );
      }
    });

    _updateIsOnMessageScreen(true);
    updateMessageStatus(_getChatId(), _getuid());
    _fetchRecipientProfile();
    // _initializeRecorder();
    // getFCMToken();
    saveFCMToken();
    _fetchSettings();
  }

  // void _showIncomingCallDialog(String room, String senderId) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (ctx) {
  //       return AlertDialog(
  //         title: Text('Incoming Call'),
  //         content: Text('Call from $senderId'),
  //         actions: [
  //           TextButton(
  //             onPressed: () => Navigator.of(ctx).pop(), // Reject
  //             child: Text('Reject'),
  //           ),
  //           ElevatedButton(
  //             onPressed: () {
  //               Navigator.of(ctx).pop(); // Accept and close dialog
  //               joinJitsiCall(room);
  //             },
  //             child: Text('Accept'),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  // void _showIncomingCallDialog({
  //   required String room,
  //   required String senderId,
  //   required String callType,
  // }) {
  //   showDialog(
  //     context: context,
  //     barrierDismissible: false,
  //     builder: (ctx) {
  //       return AlertDialog(
  //         title: const Text('📞 Incoming Call'),
  //         content: Text('Call from $senderId'),
  //         actions: [
  //           TextButton(
  //             onPressed: () => Navigator.of(ctx).pop(), // Reject
  //             child: const Text('Reject'),
  //           ),
  //           ElevatedButton(
  //             onPressed: () {
  //               Navigator.of(ctx).pop(); // Close dialog
  //               final senderId = FirebaseAuth.instance.currentUser!.uid;

  //               // Navigate to LiveKitCallScreen
  //               Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                   builder: (_) => LiveKitCallScreen(
  //                     userId: senderId, // Replace with current user
  //                     roomId: room,
  //                     callType: callType, // 'video' or 'audio'
  //                   ),
  //                 ),
  //               );
  //             },
  //             child: const Text('Accept'),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  void onFCMCallInvite(Map<String, dynamic> data) {
    if (data['type'] == 'CALL_INVITE') {
      final room = data['room'];
      final senderId = data['senderId'];
      final callType = data['callType'] ?? 'video';

      // _showIncomingCallDialog(
      //   room: room,
      //   senderId: senderId,
      //   callType: callType,
      // );
    }
  }

  Future<void> updateMessageStatus(String chatId, String userId) async {
    if (currentUser == null || widget.recipientId == null) {
      // debugPrint('Error: currentUser or recipientId is null');
      return;
    }

    try {
      // Query messages with status 'sent', where the recipient is the current user
      final messagesQuery = _firestore
          .collection('messages')
          .where('chatId', isEqualTo: chatId)
          .where('to',
              isEqualTo: currentUser!.uid) // Current user is the receiver
          .where('status', isEqualTo: 'sent');

      final snapshot = await messagesQuery.get();

      if (snapshot.docs.isNotEmpty) {
        // Update only if there are messages to mark as seen
        final batch = _firestore.batch();
        for (var doc in snapshot.docs) {
          batch.update(doc.reference, {'status': 'seen'});
        }
        await batch.commit();

        // Update chat status to 'seen'
        await _firestore.collection('chats').doc(chatId).set({
          'participants': [currentUser!.uid, widget.recipientId],
          'status': 'seen',
          'from': currentUser!.uid,
        }, SetOptions(merge: true));
      }
    } catch (e) {
      // debugPrint('Error updating message status: $e');
    }
  }

  Future<void> saveFCMToken() async {
    final FirebaseMessaging messaging = FirebaseMessaging.instance;
    final String? token = await messaging.getToken();

    if (token != null) {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .update({'fcmToken': token});
    }
  }

  // Future<void> updateMessageStatus(String chatId, String userId) async {
  //   final messagesQuery = _firestore
  //       .collection('messages')
  //       .where('chatId', isEqualTo: chatId)
  //       .where('to', isEqualTo: userId)
  //       .where('status', isEqualTo: 'sent');

  //   final snapshot = await messagesQuery.get();
  //   for (var doc in snapshot.docs) {
  //     await doc.reference.update({'status': 'seen'});
  //   }

  //   await _firestore.collection('chats').doc(chatId).set({
  //     'participants': [currentUser!.uid, widget.recipientId],
  //     'status': 'seen',
  //   }, SetOptions(merge: true));
  // }

  // Future<String?> getFCMToken() async {
  //   String? token = await FirebaseMessaging.instance.getToken();
  //   print("FCM Token: $token");

  //   await FirebaseFirestore.instance.collection('users').doc(userId).update({
  //     'fcmToken': token, // Store the token in Firestore
  //   });
  // }

//   Future<void> getToken() async {
//   FirebaseMessaging messaging = FirebaseMessaging.instance;

//   String? token = await messaging.getToken();
//   print('FCM Token: $token');

//   // Store or send this token to your server if needed.
// }

  final settingsService = SettingsService();
  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
      });
    } catch (error) {
      // print("Error fetching settings: $error");
    }
  }

  bool _darkMode = false;

  String _getChatId() {
    return currentUser!.uid.compareTo(widget.recipientId) < 0
        ? '${currentUser!.uid}_${widget.recipientId}'
        : '${widget.recipientId}_${currentUser!.uid}';
  }

  // Future<void> _initializeRecorder() async {
  //   await _audioRecorder.openRecorder();
  //   _audioRecorder.setSubscriptionDuration(const Duration(milliseconds: 500));
  // }

  // Future<void> _fetchRecipientProfile() async {
  //   DocumentSnapshot userDoc =
  //       await _firestore.collection('users').doc(widget.recipientId).get();

  //   if (userDoc.exists) {
  //     setState(() {
  //       recipientProfileUrl =
  //           userDoc['profileImageUrl']; // Adjust field name if necessary
  //     });
  //   }
  // }
  Future<void> _fetchRecipientProfile() async {
    DocumentSnapshot userDoc =
        await _firestore.collection('users').doc(widget.recipientId).get();

    if (userDoc.exists) {
      Map<String, dynamic>? userData = userDoc.data() as Map<String, dynamic>?;

      bool isDisabled =
          userData?['isDisabled'] ?? false; // Default to false if missing

      if (!isDisabled) {
        setState(() {
          recipientProfileUrl =
              userData?['profileImageUrl'] ?? ''; // Default to empty if missing
        });
      }
    }
  }

  @override
  void dispose() {
    // _audioRecorder.closeRecorder();
    _messageController.dispose();
    _updateIsOnMessageScreen(false);
    // _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _updateIsOnMessageScreen(bool isOnMessageScreen) async {
    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser!.uid)
          .update({'isOnMessageScreen': isOnMessageScreen});
      // print('User screen status updated successfully!');
    } catch (e) {
      // print('Error updating screen status: $e');
    }
  }

  // Function to send a message
  // Future<void> _sendMessage(String message) async {
  //   if (message.isNotEmpty) {
  //     final chatId = currentUser!.uid.compareTo(widget.recipientId) < 0
  //         ? '${currentUser!.uid}_${widget.recipientId}'
  //         : '${widget.recipientId}_${currentUser!.uid}';

  //     await _firestore.collection('messages').add({
  //       'chatId': chatId,
  //       'from': currentUser!.uid,
  //       'to': widget.recipientId,
  //       'message': message,
  //       'timestamp': FieldValue.serverTimestamp(),
  //       'messageType': 'text',
  //       'status': 'sent',
  //     });

  //     await _firestore.collection('chats').doc(chatId).set({
  //       'participants': [currentUser!.uid, widget.recipientId],
  //       'lastMessage': message,
  //       'timestamp': FieldValue.serverTimestamp(),
  //       'messageType': 'text',
  //       'status': 'sent',
  //     }, SetOptions(merge: true));

  //     _messageController.clear();
  //   }
  // }

  Future<void> _sendMessage(String message) async {
    if (message.isNotEmpty) {
      final chatId = currentUser!.uid.compareTo(widget.recipientId) < 0
          ? '${currentUser!.uid}_${widget.recipientId}'
          : '${widget.recipientId}_${currentUser!.uid}';
      // String encryptedMessage = await EncryptionHelper.encryptData(message);
      // Save the message to Firestore
      await _firestore.collection('messages').add({
        'chatId': chatId,
        'from': currentUser!.uid,
        'to': widget.recipientId,
        'message': message,
        'timestamp': FieldValue.serverTimestamp(),
        'messageType': 'text',
        'status': 'sent',
      });

      // Update chat document
      await _firestore.collection('chats').doc(chatId).set({
        'participants': [currentUser!.uid, widget.recipientId],
        'lastMessage': message,
        'timestamp': FieldValue.serverTimestamp(),
        'from': currentUser!.uid,
        'messageType': 'text',
        'status': 'sent',
      }, SetOptions(merge: true));

      // Retrieve the recipient's FCM token
      final recipientDoc =
          await _firestore.collection('users').doc(widget.recipientId).get();
      final recipientToken = recipientDoc.data()?['fcmToken'];
      String senderId = currentUser!.uid;
      // if (recipientToken != null) {
      //   // Send a notification to the recipient
      //   await sendNotification(
      //     recipientToken: recipientToken,
      //     message: message,
      //     senderId: senderId,
      //   );
      // }
      final recipientIsOnMessageScreen =
          recipientDoc.data()?['isOnMessageScreen'] ?? false;

      if (recipientToken != null && !recipientIsOnMessageScreen) {
        // Send a notification to the recipient only if they are not on the message screen
        await sendNotification(
          recipientToken: recipientToken,
          message: message,
          senderId: currentUser!.uid,
        );
      }
      // Clear the message input field
      // _messageController.clear();
    }
  }

  // Future<void> _sendMessage(String message) async {
  //   if (message.isNotEmpty) {
  //     final chatId = currentUser!.uid.compareTo(widget.recipientId) < 0
  //         ? '${currentUser!.uid}_${widget.recipientId}'
  //         : '${widget.recipientId}_${currentUser!.uid}';

  //     try {
  //       // Encrypt the message
  //       // Map<String, String> encryptedData = await EncryptionHelper.encryptMessage(
  //       //   message,
  //       //   currentUser!.uid,
  //       //   widget.recipientId
  //       // );
  //       EncryptionHelper encryptionHelper = EncryptionHelper();

  //       // Encrypt the message
  //       Map<String, String> encryptedData = await encryptionHelper
  //           .encryptMessage(message, currentUser!.uid, widget.recipientId);
  //       // Extract encrypted data
  //       String encryptedMessage = encryptedData['message']!;
  //       String iv = encryptedData['iv']!;
  //       String aesKeySender = encryptedData['aesKeySender']!;
  //       String aesKeyReceiver = encryptedData['aesKeyReceiver']!;

  //       // Save the message to Firestore
  //       await _firestore.collection('messages').add({
  //         'chatId': chatId,
  //         'from': currentUser!.uid,
  //         'to': widget.recipientId,
  //         'message': encryptedMessage,
  //         'iv': iv,
  //         'aesKeySender': aesKeySender,
  //         'aesKeyReceiver': aesKeyReceiver,
  //         'timestamp': FieldValue.serverTimestamp(),
  //         'messageType': 'text',
  //         'status': 'sent',
  //       });

  //       // Update chat document
  //       await _firestore.collection('chats').doc(chatId).set({
  //         'participants': [currentUser!.uid, widget.recipientId],
  //         'lastMessage': encryptedMessage,
  //         'timestamp': FieldValue.serverTimestamp(),
  //         'from': currentUser!.uid,
  //         'messageType': 'text',
  //         'status': 'sent',
  //       }, SetOptions(merge: true));

  //       // Retrieve the recipient's FCM token
  //       final recipientDoc =
  //           await _firestore.collection('users').doc(widget.recipientId).get();
  //       final recipientToken = recipientDoc.data()?['fcmToken'];
  //       String senderId = currentUser!.uid;

  //       final recipientIsOnMessageScreen =
  //           recipientDoc.data()?['isOnMessageScreen'] ?? false;

  //       if (recipientToken != null && !recipientIsOnMessageScreen) {
  //         // Send a notification to the recipient only if they are not on the message screen
  //         await sendNotification(
  //           recipientToken: recipientToken,
  //           message: encryptedMessage, // Send encrypted message
  //           senderId: senderId,
  //         );
  //       }
  //     } catch (e) {
  //       print("Error encrypting message: $e");
  //     }
  //   }
  // }
//  this Future<void> _sendMessage(String message) async {
//     print('I am right here');
//     if (message.isNotEmpty) {
//       final chatId = currentUser!.uid.compareTo(widget.recipientId) < 0
//           ? '${currentUser!.uid}_${widget.recipientId}'
//           : '${widget.recipientId}_${currentUser!.uid}';

//       try {
//         // Encrypt the message
//         EncryptionHelper encryptionHelper = EncryptionHelper();

//         // Encrypt the message
//         Map<String, String> encryptedData = await encryptionHelper
//             .encryptMessage(message, currentUser!.uid, widget.recipientId);

//         // Extract encrypted data with null checks
//         String encryptedMessage = encryptedData['message'] ?? '';
//         String iv = encryptedData['iv'] ?? '';
//         String aesKeySender = encryptedData['aesKeySender'] ?? '';
//         String aesKeyReceiver = encryptedData['aesKeyReceiver'] ?? '';

//         if (encryptedMessage.isEmpty ||
//             iv.isEmpty ||
//             aesKeySender.isEmpty ||
//             aesKeyReceiver.isEmpty) {
//           print("Error: Encryption data is missing.");
//           return; // Exit early if encryption data is invalid
//         }

//         // Save the message to Firestore
//         await _firestore.collection('messages').add({
//           'chatId': chatId,
//           'from': currentUser!.uid,
//           'to': widget.recipientId,
//           'message': encryptedMessage,
//           'iv': iv,
//           'aesKeySender': aesKeySender,
//           'aesKeyReceiver': aesKeyReceiver,
//           'timestamp': FieldValue.serverTimestamp(),
//           'messageType': 'text',
//           'status': 'sent',
//         });

//         // Update chat document
//         await _firestore.collection('chats').doc(chatId).set({
//           'participants': [currentUser!.uid, widget.recipientId],
//           'lastMessage': encryptedMessage,
//           'timestamp': FieldValue.serverTimestamp(),
//           'from': currentUser!.uid,
//           'messageType': 'text',
//           'status': 'sent',
//         }, SetOptions(merge: true));
//         print(encryptedMessage);
//         // Retrieve the recipient's FCM token
//         final recipientDoc =
//             await _firestore.collection('users').doc(widget.recipientId).get();
//         final recipientToken = recipientDoc.data()?['fcmToken'];
//         String senderId = currentUser!.uid;

//         final recipientIsOnMessageScreen =
//             recipientDoc.data()?['isOnMessageScreen'] ?? false;

//         if (recipientToken != null && !recipientIsOnMessageScreen) {
//           // Send a notification to the recipient only if they are not on the message screen
//           await sendNotification(
//             recipientToken: recipientToken,
//             message: encryptedMessage, // Send encrypted message
//             senderId: senderId,
//           );
//         }
//       } catch (e) {
//         print("Error encrypting message: $e");
//       }
//     }
//   }

  // Future<void> sendNotification({
  //   required String recipientToken,
  //   required String message,
  //   required String senderId, // Sender's user ID
  // }) async {
  //   try {
  //     // Fetch sender's details from Firestore
  //     final senderDoc = await FirebaseFirestore.instance
  //         .collection('users')
  //         .doc(senderId)
  //         .get();

  //     final senderName = senderDoc.data()?['name'] ?? 'Unknown Sender';
  //     final senderProfileImageUrl =
  //         senderDoc.data()?['profileImageUrl'] ?? 'default_profile_url';

  //     // Load the service account file for Firebase Admin SDK
  //     final jsonString = await rootBundle.loadString(
  //         'assets/keys/life-manager-a2130-firebase-adminsdk-1uytl-c15fc6182e.json');
  //     final serviceAccount =
  //         ServiceAccountCredentials.fromJson(json.decode(jsonString));

  //     final httpClient = await clientViaServiceAccount(
  //       serviceAccount,
  //       ['https://www.googleapis.com/auth/firebase.messaging'],
  //     );

  //     final url = Uri.parse(
  //         'https://fcm.googleapis.com/v1/projects/life-manager-a2130/messages:send');

  //     // Include sender details in the payload
  //     final payload = {
  //       'message': {
  //         'token': recipientToken,
  //         'notification': {
  //           'title': senderName, // Sender's name as the notification title
  //           'body': message, // Message content as the body
  //         },
  //         'data': {
  //           // 'senderName': senderName,
  //           // 'senderProfileImageUrl': senderProfileImageUrl,
  //           // 'message': message,
  //           'click_action': 'FLUTTER_NOTIFICATION_CLICK',
  //         },
  //       },
  //     };

  //     // Send the notification
  //     final response = await httpClient.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(payload),
  //     );

  //     if (response.statusCode == 200) {
  //       // print('Notification sent successfully!');
  //     } else {
  //       // print('Failed to send notification: ${response.body}');
  //     }

  //     httpClient.close();
  //   } catch (e) {
  //     // print('Error sending notification: $e');
  //   }
  // }
// import 'package:cloud_firestore/cloud_firestore.dart';

// import 'dart:convert';

  // Future<void> sendNotification({
  //   required String recipientToken,
  //   required String message,
  //   required String senderId,
  // }) async {
  //   try {
  //     // Fetch sender's name and profile image
  //     final senderDoc = await FirebaseFirestore.instance
  //         .collection('users')
  //         .doc(senderId)
  //         .get();

  //     final senderName = senderDoc.data()?['name'] ?? 'Unknown Sender';
  //     final senderProfileImageUrl = senderDoc.data()?['profileImageUrl'] ?? '';

  //     // Prepare request payload
  //     final payload = {
  //       'token': recipientToken,
  //       'title': senderName.toString(), // Use sender's name as title
  //       'body': message,
  //       'data': {
  //         'senderProfileImageUrl': senderProfileImageUrl.toString(),
  //         'senderId': senderId.toString(),
  //         'type': 'chat',
  //       },
  //       'senderId': senderId,
  //     };

  //     // Send POST request to your backend
  //     final response = await http.post(
  //       Uri.parse('https://lifemanagerapi.vercel.app/notifications/device'),
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(payload),
  //     );

  //     if (response.statusCode == 200) {
  //       print('Notification sent successfully');
  //     } else {
  //       print('Failed to send notification: ${response.body}');
  //     }
  //   } catch (e) {
  //     print('Error sending notification: $e');
  //   }
  // }
  String generateRoomId(String uid1, String uid2) {
    // Consistent room for both users
    return uid1.compareTo(uid2) < 0 ? '$uid1-$uid2' : '$uid2-$uid1';
  }

  // void startCall(String receiverId, String callType) {
  //   print('I am startCall function');
  //   final senderId = FirebaseAuth.instance.currentUser!.uid;
  //   final roomId = generateRoomId(senderId, receiverId);

  //   Navigator.push(
  //     context,
  //     MaterialPageRoute(
  //       builder: (_) => LiveKitCallScreen(
  //         userId: senderId,
  //         roomId: roomId,
  //         callType: callType, // 'audio' or 'video'
  //       ),
  //     ),
  //   );
  // }

  Future<void> sendNotification({
    required String recipientToken,
    required String message,
    required String senderId,
  }) async {
    try {
      // Fetch sender info
      final senderDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(senderId)
          .get();

      final senderName =
          (senderDoc.data()?['name'] ?? 'Unknown Sender').toString();
      final senderProfileImageUrl =
          (senderDoc.data()?['profileImageUrl'] ?? '').toString();

      // Strictly convert all `data` values to strings
      final payload = {
        'token': recipientToken,
        'title': senderName,
        'body': message,
        'data': {
          'senderProfileImageUrl': senderProfileImageUrl.toString(),
          'senderId': senderId.toString(),
          'type': 'chat',
          'click_action': 'FLUTTER_NOTIFICATION_CLICK',
          'message': message.toString(),
        },
      };

      final response = await http.post(
        Uri.parse('https://lifemanagerapi.vercel.app/notifications/device'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      if (response.statusCode == 200) {
        print('✅ Notification sent successfully');
      } else {
        print('❌ Failed to send notification: ${response.body}');
      }
    } catch (e) {
      print('🚫 Error sending notification: $e');
    }
  }
//   Future<void> initiateCall(String receiverId, String senderId) async {
//   final response = await http.post(
//     Uri.parse("https://lifemanagerapi.vercel.app/jitsi/start-call"),
//     headers: {"Content-Type": "application/json"},
//     body: jsonEncode({
//       "senderId": senderId,
//       "receiverId": receiverId,
//       "type": "video"  // or "audio"
//     }),
//   );

//   final body = jsonDecode(response.body);
//   if (body['success']) {
//     final roomName = body['room'];
//     // Optional: directly join here (for caller)
//     joinJitsiCall(roomName);
//   } else {
//     print("Call failed: ${body['error']}");
//   }
// }

//-------------------------------------------------------this is jitsi --------------------------|
  // Future<void> initiateCall(
  //     String receiverId, String senderId, String type) async {
  //   try {
  //     final response = await http.post(
  //       Uri.parse("https://lifemanagerapi.vercel.app/jitsi/start-call"),
  //       headers: {"Content-Type": "application/json"},
  //       body: jsonEncode({
  //         "senderId": senderId,
  //         "receiverId": receiverId,
  //         "type": type, // or "audio"
  //       }),
  //     );

  //     if (response.statusCode == 200) {
  //       final body = jsonDecode(response.body);
  //       if (body['success']) {
  //         final roomName = body['room'];
  //         joinJitsiCall(roomName);
  //       } else {
  //         print("Call failed: ${body['error']}");
  //       }
  //     } else {
  //       print("❌ Server Error: ${response.statusCode} — ${response.body}");
  //     }
  //   } catch (e) {
  //     print("🚫 initiateCall exception: $e");
  //   }
  // }

  // void joinJitsiCall(String room) {
  //   final jitsiMeet = JitsiMeet();
  //   final options = JitsiMeetConferenceOptions(
  //     serverURL: "https://meet.jit.si",
  //     room: room,
  //     userInfo: JitsiMeetUserInfo(displayName: "Caller"),
  //   );
  //   jitsiMeet.join(options);
  // }

//-------------------------------------------------------this is jitsi --------------------------|

  // Future<void> sendNotification(String token, String message) async {
  //   try {
  //     final jsonString = await rootBundle.loadString(
  //         'assets/keys/life-manager-a2130-firebase-adminsdk-1uytl-c15fc6182e.json');
  //     final serviceAccount =
  //         ServiceAccountCredentials.fromJson(json.decode(jsonString));

  //     final httpClient = await clientViaServiceAccount(
  //       serviceAccount,
  //       ['https://www.googleapis.com/auth/firebase.messaging'],
  //     );

  //     final url = Uri.parse(
  //         'https://fcm.googleapis.com/v1/projects/life-manager-a2130/messages:send');

  //     final payload = {
  //       'message': {
  //         'token': token,
  //         'notification': {
  //           'title': 'New Message',
  //           'body': message,
  //         },
  //         'data': {
  //           'click_action': 'FLUTTER_NOTIFICATION_CLICK',
  //         },
  //       },
  //     };

  //     final response = await httpClient.post(
  //       url,
  //       headers: {'Content-Type': 'application/json'},
  //       body: jsonEncode(payload),
  //     );

  //     if (response.statusCode == 200) {
  //       print('Notification sent successfully!');
  //     } else {
  //       print('Failed to send notification: ${response.body}');
  //     }

  //     httpClient.close();
  //   } catch (e) {
  //     print('Error sending notification: $e');
  //   }
  // }
  // Future<void> _sendNotification(String token, String message) async {
  //   try {
  //     // Load the service account file
  //     final serviceAccountFilePath =
  //         'assets/keys/life-manager-a2130-firebase-adminsdk-1uytl-c15fc6182e.json';
  //     final serviceAccountJson =
  //         File(serviceAccountFilePath).readAsStringSync();
  //     final credentials = ServiceAccountCredentials.fromJson(
  //       json.decode(serviceAccountJson),
  //     );

  //     // Obtain an authenticated HTTP client
  //     final httpClient = await clientViaServiceAccount(
  //       credentials,
  //       ['https://www.googleapis.com/auth/firebase.messaging'],
  //     );

  //     // Firebase Messaging API URL
  //     final url = Uri.parse(
  //         'https://fcm.googleapis.com/v1/projects/life-manager-a2130/messages:send');

  //     // Construct the notification payload
  //     final payload = {
  //       'message': {
  //         'token': token,
  //         'notification': {
  //           'title': 'New Message',
  //           'body': message,
  //         },
  //         'data': {
  //           'click_action': 'FLUTTER_NOTIFICATION_CLICK',
  //           'chatId': widget.recipientId,
  //         },
  //       },
  //     };

  //     // Send the request
  //     final response = await httpClient.post(
  //       url,
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: jsonEncode(payload),
  //     );

  //     if (response.statusCode == 200) {
  //       print('Notification sent successfully!');
  //     } else {
  //       print('Failed to send notification: ${response.body}');
  //     }

  //     // Close the HTTP client
  //     httpClient.close();
  //   } catch (e) {
  //     print('Error sending notification: $e');
  //   }
  // }

  // Future<void> _sendNotification(String token, String message) async {
  //   try {
  //     final serverKey =
  //         'YOUR_SERVER_KEY_HERE'; // Replace with your FCM server key
  //     final url = Uri.parse('https://fcm.googleapis.com/fcm/send');

  //     final response = await http.post(
  //       url,
  //       headers: {
  //         'Content-Type': 'application/json',
  //         'Authorization': 'key=$serverKey',
  //       },
  //       body: jsonEncode({
  //         'to': token,
  //         'notification': {
  //           'title': 'New Message',
  //           'body': message,
  //           'sound': 'default',
  //         },
  //         'data': {
  //           'click_action': 'FLUTTER_NOTIFICATION_CLICK',
  //           'chatId': widget.recipientId,
  //         },
  //       }),
  //     );

  //     if (response.statusCode == 200) {
  //       print('Notification sent successfully!');
  //     } else {
  //       print('Failed to send notification: ${response.body}');
  //     }
  //   } catch (e) {
  //     print('Error sending notification: $e');
  //   }
  // }

  // Future<void> _startRecording() async {
  //   Directory tempDir = await getTemporaryDirectory();
  //   String tempPath = '${tempDir.path}/voice_message.aac';
  //   _recordingFilePath = tempPath;

  //   // await _audioRecorder.startRecorder(toFile: _recordingFilePath);
  //   // setState(() {
  //   //   _isRecording = true; // Update the recording state
  //   // });
  //   _isRecording = true;
  // }

  // Future<void> _stopRecordingAndSend() async {
  //   // String? recordedFilePath = await _audioRecorder.stopRecorder();
  //   // setState(() {
  //   //   _isRecording = false; // Update the recording state
  //   // });
  //   _isRecording = false;

  //   if (recordedFilePath != null) {
  //     File audioFile = File(recordedFilePath);
  //     String fileName = '${DateTime.now().millisecondsSinceEpoch}.aac';
  //     TaskSnapshot snapshot = await _storage
  //         .ref()
  //         .child('voice_messages/$fileName')
  //         .putFile(audioFile);
  //     String downloadUrl = await snapshot.ref.getDownloadURL();

  //     await _firestore.collection('messages').add({
  //       'chatId': _getChatId(),
  //       'from': currentUser!.uid,
  //       'to': widget.recipientId,
  //       'message': downloadUrl,
  //       'messageType': 'audio',
  //       'status': 'sent',
  //       'timestamp': FieldValue.serverTimestamp(),
  //     });

  //     await _firestore.collection('chats').doc(_getChatId()).set({
  //       'participants': [currentUser!.uid, widget.recipientId],
  //       'lastMessage': 'Voice message',
  //       'timestamp': FieldValue.serverTimestamp(),
  //     }, SetOptions(merge: true));
  //   }
  // }

  // Future<void> _togglePlayAudio(String audioUrl) async {
  //   if (_isPlaying && _currentPlayingUrl == audioUrl) {
  //     await _audioPlayer.pause();
  //   } else {
  //     if (_currentPlayingUrl != audioUrl) {
  //       await _audioPlayer.stop();
  //     }
  //     _currentPlayingUrl = audioUrl;
  //     await _audioPlayer.play(UrlSource(audioUrl));
  //     setState(() {
  //       _isPlaying = true;
  //     });
  //   }
  // }

  // Future<void> _sendImage() async {
  //   final pickedFile = await _imagePicker.pickImage(
  //       source: ImageSource.gallery); // Use pickImage instead of getImage

  //   if (pickedFile != null) {
  //     File imageFile = File(pickedFile.path);
  //     String fileName =
  //         '${DateTime.now().millisecondsSinceEpoch}.png'; // Save as PNG or change to the appropriate format
  //     TaskSnapshot snapshot =
  //         await _storage.ref().child('images/$fileName').putFile(imageFile);
  //     String downloadUrl = await snapshot.ref.getDownloadURL();

  //     await _firestore.collection('messages').add({
  //       'chatId': _getChatId(),
  //       'from': currentUser!.uid,
  //       'to': widget.recipientId,
  //       'message': downloadUrl,
  //       'messageType': 'image',
  //       'status': 'sent',
  //       'timestamp': FieldValue.serverTimestamp(),
  //     });

  //     await _firestore.collection('chats').doc(_getChatId()).set({
  //       'participants': [currentUser!.uid, widget.recipientId],
  //       'lastMessage': 'Image message',
  //       'timestamp': FieldValue.serverTimestamp(),
  //     }, SetOptions(merge: true));
  //   }
  // }

  // Future<void> _sendImage() async {
  //   final pickedFile =
  //       await _imagePicker.pickImage(source: ImageSource.gallery);

  //   if (pickedFile != null) {
  //     File imageFile = File(pickedFile.path);

  //     // Read image file as bytes
  //     Uint8List imageBytes = await imageFile.readAsBytes();

  //     // Decode image and resize it
  //     img.Image? decodedImage = img.decodeImage(imageBytes);
  //     if (decodedImage != null) {
  //       // Reduce size while keeping quality (adjust width/height as needed)
  //       img.Image resizedImage = img.copyResize(decodedImage, width: 800);

  //       // Compress image (lower quality for better size reduction)
  //       Uint8List compressedImage = img.encodeJpg(resizedImage, quality: 85);

  //       // Save compressed image to a temporary file
  //       File compressedFile = File('${imageFile.path}_compressed.jpg');
  //       await compressedFile.writeAsBytes(compressedImage);

  //       // Upload the compressed image
  //       String fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
  //       TaskSnapshot snapshot = await _storage
  //           .ref()
  //           .child('images/$fileName')
  //           .putFile(compressedFile);
  //       String downloadUrl = await snapshot.ref.getDownloadURL();

  //       // Save message to Firestore
  //       await _firestore.collection('messages').add({
  //         'chatId': _getChatId(),
  //         'from': currentUser!.uid,
  //         'to': widget.recipientId,
  //         'message': downloadUrl,
  //         'messageType': 'image',
  //         'status': 'sent',
  //         'timestamp': FieldValue.serverTimestamp(),
  //       });

  //       // Update last message in chat
  //       await _firestore.collection('chats').doc(_getChatId()).set({
  //         'participants': [currentUser!.uid, widget.recipientId],
  //         'lastMessage': 'Image message',
  //         'timestamp': FieldValue.serverTimestamp(),
  //       }, SetOptions(merge: true));
  //     }
  //   }
  // }
  Future<void> _sendImage() async {
    final pickedFile =
        await _imagePicker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      File imageFile = File(pickedFile.path);

      // Read image file as bytes
      Uint8List imageBytes = await imageFile.readAsBytes();

      // Check if the image size is less than 120 KB
      if (imageBytes.lengthInBytes < 120 * 1024) {
        // If the image is smaller than 120 KB, upload as is
        String fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
        TaskSnapshot snapshot =
            await _storage.ref().child('images/$fileName').putFile(imageFile);
        String downloadUrl = await snapshot.ref.getDownloadURL();

        // Save message to Firestore
        await _firestore.collection('messages').add({
          'chatId': _getChatId(),
          'from': currentUser!.uid,
          'to': widget.recipientId,
          'message': downloadUrl,
          'messageType': 'image',
          'status': 'sent',
          'timestamp': FieldValue.serverTimestamp(),
        });

        // Update last message in chat
        await _firestore.collection('chats').doc(_getChatId()).set({
          'participants': [currentUser!.uid, widget.recipientId],
          'lastMessage': 'Image message',
          'timestamp': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      } else {
        // If the image is larger than 120 KB, resize and compress it
        img.Image? decodedImage = img.decodeImage(imageBytes);
        if (decodedImage != null) {
          // Resize the image (adjust width as needed)
          img.Image resizedImage = img.copyResize(decodedImage, width: 800);

          // Compress the image
          Uint8List compressedImage = img.encodeJpg(resizedImage, quality: 85);

          // Save compressed image to a temporary file
          File compressedFile = File('${imageFile.path}_compressed.jpg');
          await compressedFile.writeAsBytes(compressedImage);

          // Upload the compressed image
          String fileName = '${DateTime.now().millisecondsSinceEpoch}.jpg';
          TaskSnapshot snapshot = await _storage
              .ref()
              .child('images/$fileName')
              .putFile(compressedFile);
          String downloadUrl = await snapshot.ref.getDownloadURL();

          // Save message to Firestore
          await _firestore.collection('messages').add({
            'chatId': _getChatId(),
            'from': currentUser!.uid,
            'to': widget.recipientId,
            'message': downloadUrl,
            'messageType': 'image',
            'status': 'sent',
            'timestamp': FieldValue.serverTimestamp(),
          });

          // Update last message in chat
          await _firestore.collection('chats').doc(_getChatId()).set({
            'participants': [currentUser!.uid, widget.recipientId],
            'lastMessage': 'Image message',
            'timestamp': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));
        }
      }
    }
  }

  void _navigateToUserProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UserProfileScreen(userId: widget.recipientId),
      ),
    );
  }

  final Map<String, bool> _hoverStates = {};
  String _formatLastSeen(DateTime lastSeen) {
    final now = DateTime.now();
    final difference = now.difference(lastSeen);

    if (difference.inSeconds < 10) {
      return 'just now';
    } else if (difference.inSeconds < 60) {
      return '${difference.inSeconds} seconds ago';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} ${difference.inMinutes == 1 ? "minute" : "minutes"} ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} ${difference.inHours == 1 ? "hour" : "hours"} ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} ${difference.inDays == 1 ? "day" : "days"} ago';
    } else if (difference.inDays < 30) {
      final weeks = (difference.inDays / 7).floor();
      return '$weeks ${weeks == 1 ? "week" : "weeks"} ago';
    } else {
      final months = (difference.inDays / 30).floor();
      return '$months ${months == 1 ? "month" : "months"} ago';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: _navigateToUserProfile, // Navigate to the profile screen
          child: Row(
            children: [
              CircleAvatar(
                backgroundImage: recipientProfileUrl.isNotEmpty
                    ? CachedNetworkImageProvider(recipientProfileUrl)
                    : null,
                radius: 18.0,
                child: recipientProfileUrl.isEmpty
                    ? const Icon(
                        Icons.person) // Default icon if profile image is empty
                    : null,
              ),
              const SizedBox(width: 10.0),
              Expanded(
                child: StreamBuilder<DocumentSnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('users')
                      .doc(widget.recipientId)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return const Text(
                        'Loading...',
                        style: TextStyle(fontSize: 12.0),
                      );
                    }

                    try {
                      final user =
                          snapshot.data!.data() as Map<String, dynamic>?;
                      if (user == null) {
                        return const Text(
                          'User not found',
                          style: TextStyle(fontSize: 12.0),
                        );
                      }

                      final bool isDisabled = user['isDisabled'] ?? false;
                      final String displayName =
                          isDisabled ? 'Organize User' : widget.recipientName;

                      final Timestamp? lastSeenTimestamp =
                          user['lastSeen'] as Timestamp?;
                      final DateTime? lastSeen = lastSeenTimestamp?.toDate();

                      bool isOnline = false;

// Use lastSeen to determine online status
                      if (lastSeen != null) {
                        final difference = DateTime.now().difference(lastSeen);
                        if (difference.inSeconds < 301) {
                          isOnline = true;
                        }
                      }

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            displayName,
                            style: const TextStyle(fontSize: 18.0),
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            isDisabled
                                ? 'Offline' // Always show "Offline" for disabled users
                                : isOnline
                                    ? 'Online'
                                    : lastSeen != null
                                        ? 'Last seen: ${_formatLastSeen(lastSeen)}'
                                        : 'Offline',
                            style: const TextStyle(fontSize: 12.0),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      );
                    } catch (e) {
                      return const Text(
                        'Status unavailable',
                        style: TextStyle(fontSize: 12.0),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _buildMessageList(),
            ),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.image),
                    onPressed: () async {
                      // Fetch recipient data from Firestore
                      DocumentSnapshot recipientSnapshot = await _firestore
                          .collection('users')
                          .doc(widget.recipientId)
                          .get();

                      if (recipientSnapshot.exists) {
                        Map<String, dynamic>? recipientData =
                            recipientSnapshot.data() as Map<String, dynamic>?;

                        // Check if isDisabled exists and is true
                        if (recipientData != null &&
                            (recipientData['isDisabled'] == true)) {
                          // User is disabled, do nothing
                          return;
                        }
                      }

                      // If user is not disabled, send image
                      _sendImage();
                    },
                    color: const Color.fromARGB(255, 98, 123, 233),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _messageController,
                      maxLines: 6, // Allows the TextField to grow vertically
                      minLines: 1, // Minimum height of the TextField
                      cursorColor: const Color.fromARGB(
                          255, 98, 123, 233), // Blue cursor color
                      decoration: InputDecoration(
                        labelText: 'Type your message...',
                        labelStyle: const TextStyle(
                          color: const Color.fromARGB(255, 98, 123, 233),
                        ), // Blue label color
                        floatingLabelStyle: const TextStyle(
                          color: const Color.fromARGB(255, 98, 123, 233),
                        ), // Blue color for floating label when focused
                        hintText:
                            'Enter your message...', // Optional: A hint text that appears when the field is empty
                        hintStyle: const TextStyle(
                            color: const Color.fromARGB(
                                255, 98, 123, 233)), // Hint text color
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(
                              12), // Rounded corners for the border
                          borderSide: const BorderSide(
                              color: const Color.fromARGB(255, 98, 123, 233),
                              width: 1.0), // Blue border color and thickness
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: const Color.fromARGB(
                                255, 98, 123, 233), // Blue border when focused
                            width: 2.0, // Thicker border when focused
                          ),
                          borderRadius: BorderRadius.circular(
                              12), // Rounded corners when focused
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: const Color.fromARGB(255, 98, 123,
                                233), // Blue border when not focused
                            width: 1.0, // Thinner border when not focused
                          ),
                          borderRadius: BorderRadius.circular(
                              12), // Rounded corners when not focused
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 12.0,
                            horizontal: 16.0), // Padding inside the TextField
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.send,
                      color: Color.fromARGB(255, 98, 123, 233),
                    ),
                    onPressed: () async {
                      String message =
                          _messageController.text.trim(); // Remove spaces

                      if (message.isNotEmpty) {
                        // Fetch recipient data from Firestore
                        DocumentSnapshot recipientSnapshot = await _firestore
                            .collection('users')
                            .doc(widget.recipientId)
                            .get();

                        if (recipientSnapshot.exists) {
                          Map<String, dynamic>? recipientData =
                              recipientSnapshot.data() as Map<String, dynamic>?;

                          // Check if isDisabled exists and is true
                          if (recipientData != null &&
                              (recipientData['isDisabled'] == true)) {
                            // If user is disabled, do nothing
                            return;
                          }
                        }

                        // If user is not disabled, send message
                        _sendMessage(message);
                      }

                      _messageController.clear(); // Clear input field
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<bool>? timestampFuture;

  Widget _buildMessageList() {
    final chatId = currentUser!.uid.compareTo(widget.recipientId) < 0
        ? '${currentUser!.uid}_${widget.recipientId}'
        : '${widget.recipientId}_${currentUser!.uid}';

    return Column(
      children: [
        Expanded(
          child: StreamBuilder<QuerySnapshot>(
            stream: _firestore
                .collection('messages')
                .where('chatId', isEqualTo: chatId)
                .orderBy('timestamp', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                    child: CircularProgressIndicator(color: Colors.blueAccent));
              }

              if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              }

              if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                return const Center(child: Text('No messages yet.'));
              }

              final messages = snapshot.data!.docs;
              DateTime? lastTimestamp;
              return ListView.builder(
                reverse: true,
                itemCount: messages.length,
                itemBuilder: (context, index) {
                  final messageData = messages[index];
                  final messageText = messageData['message'];
                  final senderId = messageData['from'];
                  final isMe = messageData['from'] == currentUser!.uid;
                  final messageType = messageData['messageType'] ?? 'text';
                  final messageStatus = messageData['status'] ?? 'sending';

                  final messageMap = messageData.data() as Map<String, dynamic>;

                  final reactions = messageMap.containsKey('reactions') &&
                          messageMap['reactions'] is Map
                      ? Map<String, String>.from(messageMap['reactions'])
                      : {};
                  // final timestamp = (messageData['timestamp'] as Timestamp)
                  //     .toDate()
                  //     .toLocal();

                  final messageId = messageData.id;

                  return Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 4.0, horizontal: 8.0),
                    child: GestureDetector(
                      onLongPress: () {
                        _showMessageOptions(messageId, chatId, senderId);
                      },
                      child: Stack(
                        children: [
                          Align(
                            alignment: isMe
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: Container(
                              decoration: BoxDecoration(
                                // color: isMe
                                //     ? Colors.blueAccent
                                //     : Colors.grey.shade400,

                                color: _darkMode
                                    ? (isMe
                                        ? const Color.fromARGB(255, 98, 123,
                                            233) // Blue for the current user
                                        : Colors.grey[
                                            900]!) // Darker grey for other users
                                    : (isMe
                                        ? const Color.fromARGB(255, 98, 123,
                                            233) // Blue for the current user
                                        : Colors.grey[200]!),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              // padding: const EdgeInsets.all(5.0),
                              padding: const EdgeInsets.only(
                                  left: 2.0, right: 5.0, top: 2.0, bottom: 6.0),

                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      if (messageType == 'text')
                                        _buildTextMessage(messageData, isMe),
                                      if (messageType == 'image')
                                        _buildImageMessage(messageData, isMe),
                                      if (messageType == 'image')
                                        const SizedBox(width: 5.0),
                                      _buildMessageTimestamp(
                                          messageData, messages),
                                    ],
                                  ),
                                  // const SizedBox(height: 5.0),
                                  // _buildMessageTimestamp(messageData),
                                ],
                              ),
                            ),
                          ),
                          if (_hoverStates[messageId] == true)
                            Positioned(
                              right: isMe ? -40 : null,
                              left: isMe ? null : -40,
                              top: 0,
                              child: _buildEmojiReactionMenu(messageId),
                            ),
                          Positioned(
                            bottom: -20,
                            right: isMe ? 12 : null,
                            left: isMe ? null : 12,
                            child: Text(
                              messageData['status'] == 'seen' ? 'Seen' : 'Sent',
                            ),
                          ),
                          if (reactions.isNotEmpty)
                            Positioned(
                              right: isMe ? 42 : null,
                              left: isMe ? null : 12,
                              bottom: -2,
                              child: GestureDetector(
                                onTap: () => _loadReactions(messageId),
                                child: Row(
                                  children: reactions.entries.map((entry) {
                                    final emoji = entry.value;

                                    return Padding(
                                      padding:
                                          const EdgeInsets.only(right: 4.0),
                                      child: Text(
                                        emoji,
                                        style: TextStyle(
                                          fontSize:
                                              14.0, // Increase font size for better visibility
                                          fontWeight: FontWeight
                                              .bold, // Make the emoji bolder
                                          color: Colors.amber
                                              .shade700, // Use a vibrant color for the emoji
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _deleteMessage(String messageId, String chatId) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Message',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this message? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      try {
        // Delete the message
        await _firestore.collection('messages').doc(messageId).delete();

        // Query the most recent message (excluding the one being deleted)
        final recentMessagesSnapshot = await _firestore
            .collection('messages')
            .where('chatId', isEqualTo: chatId)
            .orderBy('timestamp', descending: true)
            .limit(1)
            .get();

        if (recentMessagesSnapshot.docs.isNotEmpty) {
          final lastMessage = recentMessagesSnapshot.docs.first.data();

          // Determine the message to show in the chat document
          String displayMessage = lastMessage['message'];
          if (lastMessage['messageType'] == 'image') {
            displayMessage = 'Image Message';
          }

          // Update the chat document with the new last message
          await _firestore.collection('chats').doc(chatId).update({
            'lastMessage': displayMessage,
            'timestamp': lastMessage['timestamp'],
            'messageType': lastMessage['messageType'],
            'status': lastMessage['status'],
            'from': lastMessage['from'],
          });
        } else {
          // If no messages remain, clear the lastMessage field in the chat document
          await _firestore.collection('chats').doc(chatId).update({
            'lastMessage': FieldValue.delete(),
            'timestamp': FieldValue.delete(),
            'messageType': FieldValue.delete(),
            'status': FieldValue.delete(),
          });
        }
      } catch (e) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(content: Text('Error deleting message: $e')),
        // );
      }
    }
  }

  void _showMessageOptions(String messageId, chatId, String senderId) {
    // Show message options like Edit, Delete, or React
    String currentUserId = FirebaseAuth.instance.currentUser!.uid;
    showModalBottomSheet(
      context: context,
      backgroundColor: _darkMode
          ? Colors.black87
          : Colors.white, // Background color of the modal bottom sheet
      builder: (BuildContext context) {
        return ListView(children: <Widget>[
          // Option to delete message
          if (senderId == currentUserId)
            ListTile(
              leading: Icon(Icons.delete,
                  color: _darkMode ? Colors.white : Colors.black),
              title: Text(
                'Delete Message',
                style: TextStyle(
                  color: _darkMode ? Colors.white : Colors.black,
                ),
              ),
              onTap: () {
                Navigator.pop(context);
                _deleteMessage(messageId, chatId);
              },
            ),
          ListTile(
            title: Row(
              mainAxisAlignment: MainAxisAlignment
                  .spaceBetween, // Ensure space between emojis and + icon
              children: [
                // Emojis list
                Wrap(
                  spacing: 8.0, // Space between emojis
                  runSpacing: 4.0, // Space between rows
                  children: [
                    ...['❤️', '😂', '😮', '😢', '👍'].map((emoji) {
                      return GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _reactToMessage(messageId, emoji); // Handle reaction
                        },
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8.0),
                          child: Text(
                            emoji,
                            style: const TextStyle(fontSize: 25),
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                ),

                // "+" icon at the end, aligned with emojis
                IconButton(
                  icon: Icon(Icons.add, size: 25),
                  onPressed: () {
                    Navigator.pop(context);
                    _moreReaction(
                        messageId); // Call the _moreReaction function on tap
                  },
                ),
              ],
            ),
          ),
        ]);
      },
    );
  }

  void _moreReaction(String messageId) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true, // Makes the modal adjust to keyboard height
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.0)),
      ),
      backgroundColor: Colors.white,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
            left: 16.0,
            right: 16.0,
            bottom: MediaQuery.of(context).viewInsets.bottom +
                16.0, // Adjust for keyboard
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'React to this message',
                  style: TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 10),
                Divider(
                  color: Colors.grey.shade300,
                  thickness: 1.5,
                ),
                const SizedBox(height: 10),
                EmojiPicker(
                  onEmojiSelected: (Category? category, Emoji emoji) {
                    Navigator.pop(context);
                    _reactToMessage(
                        messageId, emoji.emoji); // Handle emoji reaction
                  },
                  config: Config(),
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16.0,
                      vertical: 10.0,
                    ),
                  ),
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, color: Colors.white),
                  label: const Text(
                    'Close',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildMessageTimestamp(
      DocumentSnapshot messageData, List<DocumentSnapshot> allMessages) {
    final isMe = messageData['from'] == currentUser!.uid;
    final timestamp = messageData['timestamp'] != null
        ? (messageData['timestamp'] as Timestamp).toDate().toLocal()
        : null;

    if (timestamp == null) return const SizedBox.shrink();

    final now = DateTime.now();
    final difference = now.difference(timestamp);

    String formattedTimestamp;
    if (difference.inHours < 24) {
      // If within the last 24 hours, show time
      formattedTimestamp = DateFormat('HH:mm').format(timestamp);
    } else if (difference.inDays < 7) {
      // If within the last week, show weekday
      formattedTimestamp =
          '${DateFormat('EEE').format(timestamp)} at${DateFormat('\nHH:mm').format(timestamp)}';
    } else {
      // If older than a week, show date
      formattedTimestamp =
          DateFormat('MMM d\nHH:mm').format(timestamp); // Example: "Jan 12"
    }

    // Get message status
    final messageStatus = messageData['status'] ?? 'sent';

    // Find the last message received from the recipient
    DateTime? lastReceivedMessageTimestamp;
    for (var msg in allMessages) {
      if (msg['from'] != currentUser!.uid && msg['to'] == currentUser!.uid) {
        final receivedTimestamp = (msg['timestamp'] as Timestamp).toDate();
        if (lastReceivedMessageTimestamp == null ||
            receivedTimestamp.isAfter(lastReceivedMessageTimestamp)) {
          lastReceivedMessageTimestamp = receivedTimestamp;
        }
      }
    }

    final shouldShowTicks = isMe &&
        lastReceivedMessageTimestamp != null &&
        timestamp.isAfter(lastReceivedMessageTimestamp);

    return Column(
      crossAxisAlignment:
          isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        // Timestamp section
        Text(
          formattedTimestamp,
          style: TextStyle(
            fontSize: 8.0,
            color: isMe
                ? (_darkMode
                    ? Colors.white70
                    : const Color.fromARGB(123, 255, 255, 255))
                : (_darkMode
                    ? Colors.white70
                    : const Color.fromARGB(82, 19, 18, 18)),
          ),
        ),
        if (shouldShowTicks) // Show ticks only if the message meets the condition
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Single tick for sent
              if (messageStatus == 'sent')
                Icon(Icons.check,
                    size: 8.0, color: const Color.fromARGB(255, 255, 255, 255)),
              if (messageStatus == 'sent')
                Icon(Icons.check,
                    size: 8.0, color: const Color.fromARGB(255, 255, 255, 255)),
              // Double ticks for seen
              if (messageStatus == 'seen')
                Row(
                  children: [
                    Icon(Icons.check,
                        size: 8.0,
                        color: const Color.fromARGB(255, 0, 255, 157)),
                    Icon(Icons.check,
                        size: 8.0,
                        color: const Color.fromARGB(255, 0, 255, 157)),
                  ],
                ),
            ],
          ),
      ],
    );
  }

  Widget _buildTextMessage(DocumentSnapshot messageData, bool isMe) {
    final messageText =
        messageData['message'] ?? ''; // Add a fallback for null or empty

    return Align(
      alignment: isMe
          ? Alignment.centerRight
          : Alignment.centerLeft, // Align messages based on sender
      child: Container(
        padding: const EdgeInsets.symmetric(
            vertical: 7.0, horizontal: 12.0), // Adjusted padding for better UI
        constraints: const BoxConstraints(
            maxWidth: 250), // Set a max width for message bubble
        decoration: BoxDecoration(
          color: _darkMode
              ? (isMe
                  ? const Color.fromARGB(
                      255, 98, 123, 233) // Blue for the current user
                  : Colors.grey[900]!) // Darker grey for other users
              : (isMe
                  ? const Color.fromARGB(
                      255, 98, 123, 233) // Blue for the current user
                  : Colors.grey[200]!),
          borderRadius: BorderRadius.circular(22.0), // Rounded bubble effect
          boxShadow: [
            // BoxShadow(
            //   color: Colors.black.withOpacity(0.1), // Subtle shadow effect
            //   blurRadius: 5,
            //   offset: const Offset(2, 2), // Slight offset for 3D effect
            // ),
          ],
        ),
        child: Text(
          messageText,
          style: TextStyle(
            color: _darkMode
                ? const Color.fromARGB(255, 238, 237, 237)
                : (isMe ? Colors.white : Colors.black), // Handle dark mode

            // color: isMe ? Colors.white : Colors.black, // Text color based on sender
            fontSize: 16.0, // Adjustable font size
            fontWeight: FontWeight.w400, // Slight boldness for visibility
            height: 1.2, // Line height for better spacing
          ),
          // overflow: TextOverflow.ellipsis, // Prevent overflow with ellipsis
          // maxLines: 5, // Limit the number of lines (adjust as needed)
        ),
      ),
    );
  }

  Widget _buildEmojiReactionMenu(String messageId) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8.0),
        boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4.0)],
      ),
      child: Row(
        children: emojiList.map((emoji) {
          return IconButton(
            icon: Text(emoji, style: const TextStyle(fontSize: 24.0)),
            onPressed: () {
              _reactToMessage(messageId, emoji);
              // Hide emoji menu after selecting an emoji
              setState(() {
                _isEmojiMenuVisible = true;
              });
            },
          );
        }).toList(),
      ),
    );
  }

  void _reactToMessage(String messageId, String emoji) async {
    try {
      await _firestore.collection('messages').doc(messageId).set({
        'reactions': {
          currentUser!.uid:
              emoji, // Each user can have one reaction per message
        }
      }, SetOptions(merge: true));

      // After reacting, update the reactions displayed on the screen
      // _loadReactions(messageId);
    } catch (e) {
      // print("Failed to react to message: $e");
    }
  }

  void _showReactionList(String messageId, Map<String, String> reactions) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: reactions.entries.map((entry) {
              final userId = entry.key;
              final reaction = entry.value;

              // return ListTile(
              //   leading: CircleAvatar(
              //     backgroundImage: NetworkImage(_getUserProfileImage(
              //         userId)), // Fetch user's profile image
              //   ),
              //   title: Text(_getUserName(userId)), // Fetch user's name
              //   subtitle: Text(reaction),
              //   onTap: () {
              //     if (userId == currentUser!.uid) {
              //       _showDeleteReactionConfirmation(messageId, userId);
              //     }
              //   },
              // );
              return ListTile(
                leading: FutureBuilder<String?>(
                  future: _getUserProfileImage(
                      userId), // Fetch user's profile image
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const CircleAvatar(
                        child: CircularProgressIndicator(
                            color:
                                Colors.blueAccent), // Placeholder while loading
                      );
                    } else if (snapshot.hasError ||
                        snapshot.data == null ||
                        snapshot.data!.isEmpty) {
                      return const CircleAvatar(
                        child: Icon(Icons.person), // Fallback avatar
                      );
                    } else {
                      return CircleAvatar(
                        backgroundImage: NetworkImage(snapshot.data!),
                      );
                    }
                  },
                ),
                title: FutureBuilder<String?>(
                  future: _getUserName(userId), // Fetch user's name
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Text(
                          "Loading..."); // Placeholder while loading
                    } else if (snapshot.hasError ||
                        snapshot.data == null ||
                        snapshot.data!.isEmpty) {
                      return const Text("Unknown User"); // Fallback name
                    } else {
                      return Text(snapshot.data!);
                    }
                  },
                ),
                subtitle: Text(reaction),
                onTap: () {
                  if (userId == currentUser!.uid) {
                    _showDeleteReactionConfirmation(messageId, userId);
                  }
                },
              );
            }).toList(), // Convert the entries to a list
          ),
        );
      },
    );
  }

  void _loadReactions(String messageId) async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('messages')
          .doc(messageId)
          .get();
      if (doc.exists) {
        Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
        Map<String, String> reactions =
            Map<String, String>.from(data['reactions'] ?? {});

        // Show the updated reactions list
        _showReactionList(messageId, reactions);
      }
    } catch (e) {
      // print('Error loading reactions: $e');
    }
  }

  void _showDeleteReactionConfirmation(String messageId, String userId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Row(
            children: [
              const Icon(Icons.warning_rounded, color: Colors.red, size: 28),
              const SizedBox(width: 10),
              const Text(
                "Delete Reaction?",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                "Are you sure you want to delete your reaction? This action cannot be undone.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ],
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.grey[300],
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () => Navigator.of(context).pop(),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).pop();
                _deleteReaction(messageId, userId);
                // Navigator.of(context).pop(); // Close the confirmation dialog
              },
              child: const Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  // void _showDeleteReactionConfirmation(String messageId, String userId) {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: const Text("Delete Reaction"),
  //         content: const Text("Are you sure you want to delete your reaction?"),
  //         actions: [
  //           TextButton(
  //             onPressed: () => Navigator.of(context).pop(),
  //             child: const Text("Cancel"),
  //           ),
  //           TextButton(
  //             onPressed: () {
  //               _deleteReaction(messageId, userId);
  //               Navigator.of(context).pop(); // Close the confirmation dialog
  //             },
  //             child: const Text("Delete"),
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  void _deleteReaction(String messageId, String userId) async {
    try {
      await _firestore.collection('messages').doc(messageId).update({
        'reactions.$userId': FieldValue.delete(),
      });

      // After deleting, update the reactions displayed on the screen
      // _loadReactions(messageId);
    } catch (e) {
      // print("Failed to delete reaction: $e");
    }
  }

  Future<String?> _getUserProfileImage(String userId) async {
    try {
      // Fetch user's profile image from Firestore or any other data source
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .get();
      return doc.data()?['profileImageUrl'] ??
          ''; // Ensure field matches your Firestore schema
    } catch (e) {
      // print("Error fetching profile image: $e");
      return null; // Handle errors gracefully
    }
  }

  Future<String?> _getUserName(String userId) async {
    try {
      // Fetch user's name from Firestore or any other data source
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .get();
      return doc.data()?['name'] ??
          'Unknown User'; // Ensure field matches your Firestore schema
    } catch (e) {
      // print("Error fetching user name: $e");
      return 'Unknown User'; // Provide fallback value
    }
  }

  Widget _buildImageMessage(DocumentSnapshot messageData, bool isMe) {
    final imageUrl = messageData['message'];

    return Container(
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        color: isMe ? Colors.blue : Colors.grey[300],
        borderRadius: BorderRadius.circular(15.0),
      ),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FullScreenImageViewer(imageUrl: imageUrl),
            ),
          );
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15.0),
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            width: 200,
            height: 200,
            fit: BoxFit.cover,
            placeholder: (context, url) => Container(
              width: 200,
              height: 200,
              alignment: Alignment.center,
              child: CircularProgressIndicator(color: Colors.blueAccent),
            ),
            errorWidget: (context, url, error) => Container(
              width: 200,
              height: 200,
              color: Colors.grey[300],
              alignment: Alignment.center,
              child:
                  Icon(Icons.image_not_supported, color: Colors.grey, size: 50),
            ),
          ),
        ),
      ),
    );
  }
}
