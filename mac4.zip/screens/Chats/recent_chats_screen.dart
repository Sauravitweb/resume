import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:organize/constants/routes.dart';
import 'package:organize/screens/Chats/friend_request_screen.dart';
import 'package:startapp_sdk/startapp.dart';
import 'package:organize/services/friend_request_service.dart';
import 'message_screen.dart'; // Import the MessageScreen file
// Import the FriendRequestScreen file
import 'package:organize/services/settings_service.dart';
import 'package:cached_network_image/cached_network_image.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

class RecentChatsScreen extends StatefulWidget {
  const RecentChatsScreen({super.key});

  @override
  _RecentChatsScreenState createState() => _RecentChatsScreenState();
}

class _RecentChatsScreenState extends State<RecentChatsScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final User? currentUser = FirebaseAuth.instance.currentUser;
  List<DocumentSnapshot> suggestedFriends = [];
  List<DocumentSnapshot> filteredFriends = [];
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();

  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchSettings();

    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/9932493005', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       // print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  @override
  void dispose() {
    super.dispose();
  }

  final settingsService = SettingsService();
  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
      });
    } catch (error) {
      // print("Error fetching settings: $error");
    }
  }

  bool _darkMode = false;

  Future<void> _fetchSuggestedFriends() async {
    // Fetch friends or users who are not the current user
    QuerySnapshot snapshot = await _firestore
        .collection('users')
        .where(FieldPath.documentId, isNotEqualTo: currentUser!.uid)
        .get();

    // Get existing chats to exclude users already in chats
    QuerySnapshot chatsSnapshot = await _firestore
        .collection('chats')
        .where('participants', arrayContains: currentUser!.uid)
        .get();

    List<String> alreadyInChat = [];
    for (var chat in chatsSnapshot.docs) {
      final participants =
          chat['participants'] as List<dynamic>; // Ensure it's dynamic
      alreadyInChat.addAll(
          participants.where((id) => id != currentUser!.uid).cast<String>());
    }

    // Filter suggested friends
    suggestedFriends = snapshot.docs.where((user) {
      return !alreadyInChat.contains(user.id);
    }).toList();

    filteredFriends = suggestedFriends; // Initialize filteredFriends
    setState(() {});
  }

  void _filterFriends(String query) {
    if (query.isEmpty) {
      setState(() {
        filteredFriends =
            suggestedFriends; // Reset to suggested friends if search query is empty
      });
    } else {
      setState(() {
        filteredFriends = suggestedFriends.where((user) {
          final userName =
              user['name'].toString().toLowerCase(); // Ensure it's a string
          return userName.contains(query.toLowerCase());
        }).toList();
      });
    }
  }

  void _startChat(String recipientId, String recipientName) {
    // Navigate to the message screen with the selected friend
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MessageScreen(
          recipientId: recipientId,
          recipientName: recipientName,
        ),
      ),
    );
  }

  // Method to send a friend request
  // void _sendFriendRequest(String userId, String userName) {
  //   if (_sentRequests.contains(userId)) {
  //     // Friend request already sent
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Friend request already sent to $userName')),
  //     );
  //   } else {
  //     // Send friend request
  //     setState(() {
  //       _sentRequests.add(userId); // Mark as sent
  //     });

  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Friend request sent to $userName')),
  //     );
  //   }
  // }

  Future<void> _sendFriendRequest(String userId) async {
    try {
      await _firestore.collection('friend_requests').add({
        'from': currentUser!.uid,
        'to': userId,
        'status': 'pending',
        'timestamp': FieldValue.serverTimestamp(),
      });
    } catch (e) {
      // print('Error sending friend request: $e');
    }
  }

  Future<void> _removeFriendRequest(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection('friend_requests')
          .where('from', isEqualTo: currentUser!.uid)
          .where('to', isEqualTo: userId)
          .where('status', isEqualTo: 'pending')
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final requestId = querySnapshot.docs.first.id;
        await _firestore.collection('friend_requests').doc(requestId).delete();
      }
    } catch (e) {
      // print('Error removing friend request: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Chats',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        //  backgroundColor: _darkMode ? Colors.black : Colors.white,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.person_add,
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => FriendRequestScreen()),
              );
            },
          ),

//           IconButton(
//             icon: Icon(Icons.person_3),
//             onPressed: () {
//               Navigator.push(
//   context,
//   MaterialPageRoute(builder: (context) => SuggestedFriendsScreen()),
// );

//             },
//           ),
          IconButton(
            icon: const Icon(
              Icons.search,
            ),
            onPressed: () async {
              setState(() {
                _isSearching = !_isSearching;
                if (_isSearching) {
                  _fetchSuggestedFriends();
                } else {
                  _searchController.clear();
                  filteredFriends = [];
                }
              });
            },
          ),
          // IconButton(
          //   icon: FutureBuilder<DocumentSnapshot>(
          //     future:
          //         _firestore.collection('users').doc(currentUser!.uid).get(),
          //     builder: (context, snapshot) {
          //       if (snapshot.connectionState == ConnectionState.waiting) {
          //         return const CircleAvatar(child: CircularProgressIndicator(color: Colors.blueAccent));
          //       }
          //       if (snapshot.hasError || !snapshot.hasData) {
          //         return const CircleAvatar(child: Icon(Icons.person));
          //       }

          //       final userData = snapshot.data!.data() as Map<String, dynamic>;
          //       final profileImageUrl = userData['profileImageUrl'] ?? '';

          //       return CircleAvatar(
          //         backgroundImage: profileImageUrl.isNotEmpty
          //             ? NetworkImage(profileImageUrl)
          //             : null,
          //         child:
          //             profileImageUrl.isEmpty ? const Icon(Icons.person) : null,
          //       );
          //     },
          //   ),
          //   onPressed: () {
          //     Navigator.pushNamed(context, '/profile');
          //   },
          // ),

          IconButton(
            icon: FutureBuilder<DocumentSnapshot>(
              future:
                  _firestore.collection('users').doc(currentUser!.uid).get(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const CircleAvatar(
                      child:
                          CircularProgressIndicator(color: Colors.blueAccent));
                }
                if (snapshot.hasError || !snapshot.hasData) {
                  return const CircleAvatar(child: Icon(Icons.person));
                }

                final userData = snapshot.data!.data() as Map<String, dynamic>;
                final profileImageUrl = userData['profileImageUrl'] ?? '';

                return CircleAvatar(
                  backgroundImage: profileImageUrl.isNotEmpty
                      ? CachedNetworkImageProvider(profileImageUrl)
                      : null,
                  child:
                      profileImageUrl.isEmpty ? const Icon(Icons.person) : null,
                );
              },
            ),
            onPressed: () {
              Navigator.pushNamed(context, profileRoute);
            },
          ),
        ],
      ),
      body: currentUser == null
          ? const Center(child: Text('User not logged in'))
          : Column(
              children: [
                //     _buildNavigationCard(
                //   title: 'Global Chat',
                //   subtitle: 'Chat Globally',
                //   onTap: () => Navigator.pushNamed(context, '/chat'),
                // ),
                if (_isSearching)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: _searchController,
                      // decoration: InputDecoration(
                      //   labelText: 'Search Friends',
                      //   border: OutlineInputBorder(),
                      //   prefixIcon: Icon(Icons.search),
                      // ),

                      cursorColor: Colors.blue, // Blinking cursor color
                      decoration: InputDecoration(
                        labelText: 'Search Friends',
                        labelStyle: const TextStyle(
                            color: Colors.blue), // Label color when not focused
                        floatingLabelStyle: const TextStyle(
                            color: Colors.blue), // Label color when focused
                        border: OutlineInputBorder(
                          borderRadius:
                              BorderRadius.circular(12.0), // Rounded corners
                        ),
                        prefixIcon: const Icon(
                          Icons.search,
                          color: Colors.blue,
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 12.0), // Reduces height
                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: Colors.blue,
                              width: 2.0), // Blue border when focused
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                              color: Colors.blue,
                              width: 1.0), // Blue border when not focused
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),

                      onChanged: _filterFriends,
                    ),
                  ),
                if (_isSearching) ...[
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      'Suggested Friends',
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: filteredFriends.length,
                      itemBuilder: (context, index) {
                        final user = filteredFriends[index];
                        final userData = user.data() as Map<String, dynamic>?;

                        if (userData == null) {
                          return const SizedBox.shrink(); // Skip null user data
                        }

                        final userId =
                            userData.containsKey('id') ? userData['id'] : null;
                        final isDisabled = userData['isDisabled'] ??
                            false; // Default to false if missing

                        if (userId == null || isDisabled) {
                          return const SizedBox
                              .shrink(); // Skip disabled or deleted accounts
                        }

                        final userName = userData['name'] ?? 'Unknown User';
                        final profileImageUrl =
                            userData['profileImageUrl'] ?? '';

                        return StreamBuilder<QuerySnapshot>(
                          stream: _firestore
                              .collection('friend_requests')
                              .where('from', isEqualTo: currentUser!.uid)
                              .where('to', isEqualTo: userId)
                              .snapshots(),
                          builder: (context, requestSnapshot) {
                            if (!requestSnapshot.hasData) {
                              return const SizedBox.shrink();
                            }

                            final requests = requestSnapshot.data!.docs;
                            String iconStatus = 'send';
                            bool isRequestPending = false;
                            bool isRequestAccepted = false;

                            if (requests.isNotEmpty) {
                              final request = requests.first;
                              final status = request['status'];

                              if (status == 'pending') {
                                iconStatus = 'pending';
                                isRequestPending = true;
                              } else if (status == 'accepted') {
                                iconStatus = 'accepted';
                                isRequestAccepted = true;
                              }
                            }

                            return ListTile(
                              leading: CircleAvatar(
                                backgroundImage: profileImageUrl.isNotEmpty
                                    ? NetworkImage(profileImageUrl)
                                    : null,
                                child: profileImageUrl.isEmpty
                                    ? const Icon(Icons.person)
                                    : null,
                              ),
                              title: Text(
                                userName,
                                style: TextStyle(
                                    color:
                                        _darkMode ? Colors.white : Colors.black,
                                    fontWeight: FontWeight.bold),
                              ),
                              trailing: IconButton(
                                icon: iconStatus == 'send'
                                    ? Icon(Icons.person_add,
                                        color: _darkMode
                                            ? Colors.white
                                            : Colors.black)
                                    : iconStatus == 'pending'
                                        ? Icon(Icons.pending,
                                            color: _darkMode
                                                ? Colors.yellow
                                                : Colors.orange)
                                        : Icon(Icons.check_circle,
                                            color: _darkMode
                                                ? Colors.green
                                                : Colors.blue),
                                onPressed: () async {
                                  if (iconStatus == 'send') {
                                    await _sendFriendRequest(userId);
                                  } else if (iconStatus == 'accepted') {
                                    await _removeFriendRequest(userId);
                                  }
                                },
                              ),
                              onTap: () {
                                _startChat(userId, userName);
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),

                  // Expanded(
                  //   child: ListView.builder(
                  //     itemCount: filteredFriends.length,
                  //     itemBuilder: (context, index) {
                  //       final user = filteredFriends[index];
                  //       final userName = user['name'] ?? 'Unknown User';
                  //       final profileImageUrl = user['profileImageUrl'] ?? '';
                  //       // final userId =
                  //       //     user.containsKey('id') ? user['id'] : null;

                  //       // if (userId == null) {
                  //       //   return const SizedBox
                  //       //       .shrink(); // Skip deleted accounts
                  //       // }
                  //       final userData = user.data()
                  //           as Map<String, dynamic>?; // Cast snapshot data
                  //       final userId =
                  //           userData != null && userData.containsKey('id')
                  //               ? userData['id']
                  //               : null;

                  //       if (userId == null) {
                  //         return const SizedBox
                  //             .shrink(); // Skip deleted accounts
                  //       }
                  //       return StreamBuilder<QuerySnapshot>(
                  //         stream: _firestore
                  //             .collection('friend_requests')
                  //             .where('from', isEqualTo: currentUser!.uid)
                  //             .where('to', isEqualTo: userId)
                  //             .snapshots(),
                  //         builder: (context, requestSnapshot) {
                  //           if (!requestSnapshot.hasData) {
                  //             return const SizedBox.shrink();
                  //           }

                  //           final requests = requestSnapshot.data!.docs;
                  //           String iconStatus = 'send';
                  //           bool isRequestPending = false;
                  //           bool isRequestAccepted = false;

                  //           if (requests.isNotEmpty) {
                  //             final request = requests.first;
                  //             final status = request['status'];

                  //             if (status == 'pending') {
                  //               iconStatus = 'pending';
                  //               isRequestPending = true;
                  //             } else if (status == 'accepted') {
                  //               iconStatus = 'accepted';
                  //               isRequestAccepted = true;
                  //             }
                  //           }

                  //           return ListTile(
                  //             leading: CircleAvatar(
                  //               backgroundImage: profileImageUrl.isNotEmpty
                  //                   ? NetworkImage(profileImageUrl)
                  //                   : null,
                  //               child: profileImageUrl.isEmpty
                  //                   ? const Icon(Icons.person)
                  //                   : null,
                  //             ),
                  //             title: Text(
                  //               userName,
                  //               style: TextStyle(
                  //                   color:
                  //                       _darkMode ? Colors.white : Colors.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             trailing: IconButton(
                  //               icon: iconStatus == 'send'
                  //                   ? Icon(Icons.person_add,
                  //                       color: _darkMode
                  //                           ? Colors.white
                  //                           : Colors.black)
                  //                   : iconStatus == 'pending'
                  //                       ? Icon(Icons.pending,
                  //                           color: _darkMode
                  //                               ? Colors.yellow
                  //                               : Colors.orange)
                  //                       : Icon(Icons.check_circle,
                  //                           color: _darkMode
                  //                               ? Colors.green
                  //                               : Colors.blue),
                  //               onPressed: () async {
                  //                 if (iconStatus == 'send') {
                  //                   await _sendFriendRequest(userId);
                  //                 } else if (iconStatus == 'accepted') {
                  //                   await _removeFriendRequest(userId);
                  //                 }
                  //               },
                  //             ),
                  //             onTap: () {
                  //               _startChat(userId, userName);
                  //             },
                  //           );
                  //         },
                  //       );
                  //     },
                  //   ),
                  // ),

                  // Expanded(
                  //   child: ListView.builder(
                  //     itemCount: filteredFriends.length,
                  //     itemBuilder: (context, index) {
                  //       final user = filteredFriends[index];
                  //       final userName = user['name'] ?? 'Unknown User';
                  //       final profileImageUrl = user['profileImageUrl'] ?? '';
                  //       final userId =
                  //           user['id']; // Assuming user.id is available

                  //       return StreamBuilder<QuerySnapshot>(
                  //         stream: _firestore
                  //             .collection('friend_requests')
                  //             .where('from',
                  //                 isEqualTo: currentUser!
                  //                     .uid) // Filter by sender (current user)
                  //             .where('to',
                  //                 isEqualTo:
                  //                     userId) // Filter by recipient (user)
                  //             .snapshots(), // Use stream for real-time updates
                  //         builder: (context, requestSnapshot) {
                  //           if (!requestSnapshot.hasData) {
                  //             return const SizedBox
                  //                 .shrink(); // Loading or empty state
                  //           }

                  //           final requests = requestSnapshot.data!.docs;
                  //           String iconStatus =
                  //               'send'; // Default to 'send request' icon
                  //           bool isRequestPending = false;
                  //           bool isRequestAccepted = false;

                  //           if (requests.isNotEmpty) {
                  //             final request = requests.first;
                  //             final status = request['status'];

                  //             if (status == 'pending') {
                  //               iconStatus = 'pending'; // Pending request
                  //               isRequestPending = true;
                  //             } else if (status == 'accepted') {
                  //               iconStatus = 'accepted'; // Accepted request
                  //               isRequestAccepted = true;
                  //             }
                  //           }

                  //           return ListTile(
                  //             leading: CircleAvatar(
                  //               backgroundImage: profileImageUrl.isNotEmpty
                  //                   ? NetworkImage(profileImageUrl)
                  //                   : null,
                  //               child: profileImageUrl.isEmpty
                  //                   ? const Icon(Icons.person)
                  //                   : null,
                  //             ),
                  //             title: Text(
                  //               userName,
                  //               style: TextStyle(
                  //                   color:
                  //                       _darkMode ? Colors.white : Colors.black,
                  //                   fontWeight: FontWeight.bold),
                  //             ),
                  //             // SizedBox(height: 4.0),

                  //             trailing: IconButton(
                  //               // icon: iconStatus == 'send'
                  //               //     ? Icon(Icons.person_add)
                  //               //     : iconStatus == 'pending'
                  //               //         ? Icon(Icons.pending)
                  //               //         : Icon(Icons.check_circle),
                  //               icon: iconStatus == 'send'
                  //                   ? Icon(
                  //                       Icons.person_add,
                  //                       color: _darkMode
                  //                           ? Colors.white
                  //                           : Colors
                  //                               .black, // Adapt color for dark mode
                  //                     )
                  //                   : iconStatus == 'pending'
                  //                       ? Icon(
                  //                           Icons.pending,
                  //                           color: _darkMode
                  //                               ? Colors.yellow
                  //                               : Colors
                  //                                   .orange, // Example dark/light colors
                  //                         )
                  //                       : Icon(
                  //                           Icons.check_circle,
                  //                           color: _darkMode
                  //                               ? Colors.green
                  //                               : Colors
                  //                                   .blue, // Example dark/light colors
                  //                         ),

                  //               onPressed: () async {
                  //                 if (iconStatus == 'send') {
                  //                   // Send friend request
                  //                   await _sendFriendRequest(userId);
                  //                 } else if (iconStatus == 'pending') {
                  //                   // Do nothing or show pending
                  //                 } else if (iconStatus == 'accepted') {
                  //                   // Remove friend (or do other necessary actions)
                  //                   await _removeFriendRequest(userId);
                  //                 }
                  //               },
                  //             ),
                  //             onTap: () {
                  //               _startChat(userId, userName);
                  //             },
                  //           );
                  //         },
                  //       );
                  //     },
                  //   ),
                  // ),

//                   Expanded(
//   child: ListView.builder(
//     itemCount: filteredFriends.length,
//     itemBuilder: (context, index) {
//       final user = filteredFriends[index];
//       final userData = user.data() as Map<String, dynamic>?; // Explicitly cast to a Map

//       // Ensure userData is not null
//       final userName = (userData != null && userData.containsKey('name'))
//           ? userData['name']
//           : 'Unnamed User';
//       final profileImageUrl = (userData != null && userData.containsKey('profileImageUrl'))
//           ? userData['profileImageUrl']
//           : '';

//       return ListTile(
//         leading: CircleAvatar(
//           backgroundImage: profileImageUrl.isNotEmpty
//               ? NetworkImage(profileImageUrl)
//               : null, // No image if URL is empty
//           child: profileImageUrl.isEmpty
//               ? Icon(Icons.person, color: Colors.grey) // Default icon for missing image
//               : null,
//         ),
//         title: Text(
//           userName,
//           style: TextStyle(color: userData != null && userData.containsKey('name') ? Colors.black : Colors.grey),
//         ), // Grey text if name is missing
//         trailing: IconButton(
//           icon: Icon(Icons.person_add),
//           onPressed: () {
//             // Implement logic to send friend request
//             _sendFriendRequest(user.id, userName); // Example: Add this method to handle requests
//           },
//         ),
//         onTap: () {
//           _startChat(user.id, userName); // Pass default name if unavailable
//         },
//       );
//     },
//   ),
// )
//  Expanded(
//         child: ListView.builder(
//           itemCount: filteredFriends.length,
//           itemBuilder: (context, index) {
//             final user = filteredFriends[index];
//             final userData = user.data() as Map<String, dynamic>?; // Explicitly cast to a Map

//             // Ensure userData is not null
//             final userName = (userData != null && userData.containsKey('name'))
//                 ? userData['name']
//                 : 'Unnamed User';
//             final profileImageUrl = (userData != null && userData.containsKey('profileImageUrl'))
//                 ? userData['profileImageUrl']
//                 : '';

//             bool isFriendRequestSent = _sentRequests.contains(user.id);

//             return ListTile(
//               leading: CircleAvatar(
//                 backgroundImage: profileImageUrl.isNotEmpty
//                     ? NetworkImage(profileImageUrl)
//                     : null, // No image if URL is empty
//                 child: profileImageUrl.isEmpty
//                     ? Icon(Icons.person, color: Colors.grey) // Default icon for missing image
//                     : null,
//               ),
//               title: Text(
//                 userName,
//                 style: TextStyle(color: userData != null && userData.containsKey('name') ? Colors.black : Colors.grey),
//               ), // Grey text if name is missing
//               trailing: IconButton(
//                 icon: Icon(isFriendRequestSent ? Icons.person_add_disabled : Icons.person_add),
//                 onPressed: () {
//                   _sendFriendRequest(user.id, userName); // Add this method to handle requests
//                 },
//               ),
//               onTap: () {
//                 _startChat(user.id, userName); // Pass default name if unavailable
//               },
//             );
//           },
//         ),
//       ),
                ],
                // Expanded(
                //   child: StreamBuilder<QuerySnapshot>(
                //     stream: _firestore
                //         .collection('chats')
                //         .where('participants', arrayContains: currentUser!.uid)
                //         .snapshots(),
                //     builder: (context, snapshot) {
                //       if (snapshot.connectionState == ConnectionState.waiting) {
                //         return const Center(child: CircularProgressIndicator(color: Colors.blueAccent));
                //       }

                //       if (snapshot.hasError) {
                //         return Center(child: Text('Error: ${snapshot.error}'));
                //       }

                //       if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                //         return const Center(
                //             child: Text('No recent chats found.'));
                //       }

                //       final chats = snapshot.data!.docs;
                //       return ListView.builder(
                //         itemCount: chats.length,
                //         itemBuilder: (context, index) {
                //           final chat = chats[index];
                //           final participants =
                //               chat['participants'] as List<dynamic>;
                //           final otherUserId = participants.firstWhere(
                //               (id) => id != currentUser!.uid,
                //               orElse: () => null);

                //           if (otherUserId == null) {
                //             return const ListTile(
                //                 title: Text('No other participant found.'));
                //           }

                //           return FutureBuilder<DocumentSnapshot>(
                //             future: _firestore
                //                 .collection('users')
                //                 .doc(otherUserId)
                //                 .get(),
                //             builder: (context, userSnapshot) {
                //               if (userSnapshot.connectionState ==
                //                   ConnectionState.waiting) {
                //                 return const ListTile(
                //                     title: Text('Loading user info...'));
                //               }

                //               if (userSnapshot.hasError ||
                //                   !userSnapshot.hasData) {
                //                 return const ListTile(
                //                     title: Text('Error loading user info.'));
                //               }

                //               final user = userSnapshot.data!;
                //               final userName = user['name'] ?? 'Unknown User';
                //               final profileImageUrl =
                //                   user['profileImageUrl'] ?? '';

                //               return ListTile(
                //                 leading: CircleAvatar(
                //                   radius: 30,
                //                   backgroundImage: profileImageUrl.isNotEmpty
                //                       ? NetworkImage(profileImageUrl)
                //                       : null,
                //                   child: profileImageUrl.isEmpty
                //                       ? Icon(
                //                           Icons.person,
                //                           color: _darkMode
                //                               ? Colors.white
                //                               : Colors.black,
                //                         )
                //                       : null,
                //                 ),
                //                 title: Text(
                //                   userName,
                //                   style: TextStyle(
                //                       color: _darkMode
                //                           ? const Color.fromARGB(
                //                               240, 255, 255, 255)
                //                           : Colors.black,
                //                       fontWeight: FontWeight.w500,
                //                       letterSpacing: 0.6),
                //                 ),
                //                 subtitle: Text(
                //                   chat['lastMessage'] ?? 'No message available',
                //                   style: TextStyle(
                //                       fontSize: 14,
                //                       fontWeight: FontWeight.w600,
                //                       color: _darkMode
                //                           ? const Color.fromARGB(
                //                               122, 255, 255, 255)
                //                           : Colors.black),
                //                   maxLines: 1, // Restricts to one line
                //                   overflow: TextOverflow.ellipsis,
                //                 ),
                //                 //  Text(
                //                 //       chat['timestamp'] != null
                //                 //           ? (chat['timestamp'] as Timestamp)
                //                 //               .toDate()
                //                 //               .toLocal()
                //                 //               .toString()
                //                 //               .split(' ')[1]
                //                 //               .substring(0, 5)
                //                 //           : '',
                //                 //       style: TextStyle(fontSize: 12.0, color: _darkMode ? Colors.white70 : Colors.black54, height: 0.2),
                //                 //     ),
                //                 trailing: Column(
                //                   mainAxisAlignment: MainAxisAlignment
                //                       .center, // Centers the timestamp vertically
                //                   children: [
                //                     Text(
                //                       chat['timestamp'] != null
                //                           ? (chat['timestamp'] as Timestamp)
                //                               .toDate()
                //                               .toLocal()
                //                               .toString()
                //                               .split(' ')[1]
                //                               .substring(0,
                //                                   5) // Extracts the time in HH:mm format
                //                           : '',
                //                       style: TextStyle(
                //                         fontSize: 12.0,
                //                         color: _darkMode
                //                             ? Colors.white70
                //                             : Colors
                //                                 .black54, // Softer color for timestamp
                //                         height:
                //                             1.2, // Adjusted for better line spacing
                //                       ),
                //                     ),
                //                     // Text(
                //                     //   chat['timestamp'] != null
                //                     //       ? DateFormat('MMM dd\nHH:mm').format(
                //                     //           (chat['timestamp'] as Timestamp)
                //                     //               .toDate()
                //                     //               .toLocal())
                //                     //       : '',
                //                     //   style: TextStyle(
                //                     //     fontSize: 12.0,
                //                     //     color: _darkMode
                //                     //         ? Colors.white70
                //                     //         : Colors
                //                     //             .black54, // Softer color for timestamp
                //                     //     height:
                //                     //         1.2, // Adjusted for better line spacing
                //                     //   ),
                //                     // ),
                //                   ],
                //                 ),

                //                 onTap: () {
                //                   _startChat(otherUserId, userName);
                //                 },
                //               );
                //             },
                //           );
                //         },
                //       );
                //     },
                //   ),
                // ),
                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: _firestore
                        .collection('chats')
                        .where('participants', arrayContains: currentUser!.uid)
                        .orderBy('timestamp',
                            descending: true) // Order by timestamp descending
                        .snapshots(),
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(
                            child: CircularProgressIndicator(
                                color: Colors.blueAccent));
                      }

                      if (snapshot.hasError) {
                        return Center(child: Text('Error: ${snapshot.error}'));
                      }

                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(
                            child: Text('No recent chats found.'));
                      }

                      final chats = snapshot.data!.docs;
                      return ListView.builder(
                        itemCount: chats.length,
                        itemBuilder: (context, index) {
                          final chat = chats[index];
                          final participants =
                              chat['participants'] as List<dynamic>;
                          final otherUserId = participants.firstWhere(
                            (id) => id != currentUser!.uid,
                            orElse: () => null,
                          );

                          if (otherUserId == null) {
                            return const ListTile(
                                title: Text('No other participant found.'));
                          }

                          // return FutureBuilder<DocumentSnapshot>(
                          //   future: _firestore
                          //       .collection('users')
                          //       .doc(otherUserId)
                          //       .get(),
                          //   builder: (context, userSnapshot) {
                          //     if (userSnapshot.connectionState ==
                          //         ConnectionState.waiting) {
                          //       return const ListTile(
                          //           title: Text('Loading user info...'));
                          //     }

                          //     if (userSnapshot.hasError ||
                          //         !userSnapshot.hasData) {
                          //       return const ListTile(
                          //           title: Text('Error loading user info.'));
                          //     }

                          //     final user = userSnapshot.data!;
                          //     final userName = user['name'] ?? 'Unknown User';
                          //     final profileImageUrl =
                          //         user['profileImageUrl'] ?? '';

                          //     return ListTile(
                          //       leading: CircleAvatar(
                          //         radius: 30,
                          //         backgroundImage: profileImageUrl.isNotEmpty
                          //             ? CachedNetworkImageProvider(
                          //                 profileImageUrl)
                          //             : null,
                          //         child: profileImageUrl.isEmpty
                          //             ? Icon(
                          //                 Icons.person,
                          //                 color: _darkMode
                          //                     ? Colors.white
                          //                     : Colors.black,
                          //               )
                          //             : null,
                          //       ),
                          //       title: Text(
                          //         userName,
                          //         style: TextStyle(
                          //           color: _darkMode
                          //               ? const Color.fromARGB(
                          //                   240, 255, 255, 255)
                          //               : Colors.black,
                          //           fontWeight: (chat['status'] == 'sent' &&
                          //                   chat['from'] != currentUser!.uid)
                          //               ? FontWeight.w900
                          //               : FontWeight.w500,
                          //           letterSpacing: 0.6,
                          //         ),
                          //       ),
                          //       subtitle: Text(
                          //         chat['lastMessage'] ?? 'No message available',
                          //         style: TextStyle(
                          //           fontSize: 14,
                          //           fontWeight: (chat['status'] == 'sent' &&
                          //                   chat['from'] != currentUser!.uid)
                          //               ? FontWeight.w900
                          //               : FontWeight.w400,
                          //           color: _darkMode
                          //               ? (chat['status'] == 'sent' &&
                          //                       chat['from'] !=
                          //                           currentUser!.uid)
                          //                   ? Colors.white
                          //                   : const Color.fromARGB(
                          //                       122, 255, 255, 255)
                          //               : (chat['status'] == 'sent' &&
                          //                       chat['from'] !=
                          //                           currentUser!.uid)
                          //                   ? Colors.black
                          //                   : Colors.black,
                          //         ),
                          //         maxLines: 1,
                          //         overflow: TextOverflow.ellipsis,
                          //       ),
                          //       trailing: Column(
                          //         mainAxisAlignment: MainAxisAlignment.center,
                          //         children: [
                          //           Text(
                          //             chat['timestamp'] != null
                          //                 ? (chat['timestamp'] as Timestamp)
                          //                     .toDate()
                          //                     .toLocal()
                          //                     .toString()
                          //                     .split(' ')[1]
                          //                     .substring(0, 5)
                          //                 : '',
                          //             style: TextStyle(
                          //               fontWeight: (chat['status'] == 'sent' &&
                          //                       chat['from'] !=
                          //                           currentUser!.uid)
                          //                   ? FontWeight.w900
                          //                   : FontWeight.w400,
                          //               fontSize: 12.0,
                          //               color: _darkMode
                          //                   ? (chat['status'] == 'sent' &&
                          //                           chat['from'] !=
                          //                               currentUser!.uid)
                          //                       ? Colors.white
                          //                       : Colors.white70
                          //                   : (chat['status'] == 'sent' &&
                          //                           chat['from'] !=
                          //                               currentUser!.uid)
                          //                       ? Colors.black
                          //                       : Colors.black54,
                          //               height: 1.2,
                          //             ),
                          //           ),
                          //         ],
                          //       ),
                          //       onTap: () {
                          //         _startChat(otherUserId, userName);
                          //       },
                          //     );

                          //     // return ListTile(
                          //     //   leading: CircleAvatar(
                          //     //     radius: 30,
                          //     //     backgroundImage: profileImageUrl.isNotEmpty
                          //     //         ? NetworkImage(profileImageUrl)
                          //     //         : null,
                          //     //     child: profileImageUrl.isEmpty
                          //     //         ? Icon(
                          //     //             Icons.person,
                          //     //             color: _darkMode
                          //     //                 ? Colors.white
                          //     //                 : Colors.black,
                          //     //           )
                          //     //         : null,
                          //     //   ),
                          //     //   title: Text(
                          //     //     userName,
                          //     //     style: TextStyle(
                          //     //       color: _darkMode
                          //     //           ? const Color.fromARGB(
                          //     //               240, 255, 255, 255)
                          //     //           : Colors.black,
                          //     //       fontWeight: FontWeight.w500,
                          //     //       letterSpacing: 0.6,
                          //     //     ),
                          //     //   ),
                          //     //   subtitle: Text(
                          //     //     chat['lastMessage'] ?? 'No message available',
                          //     //     style: TextStyle(
                          //     //       fontSize: 14,
                          //     //       fontWeight: FontWeight.w600,
                          //     //       color: _darkMode
                          //     //           ? const Color.fromARGB(
                          //     //               122, 255, 255, 255)
                          //     //           : Colors.black,
                          //     //     ),
                          //     //     maxLines: 1,
                          //     //     overflow: TextOverflow.ellipsis,
                          //     //   ),
                          //     //   trailing: Column(
                          //     //     mainAxisAlignment: MainAxisAlignment.center,
                          //     //     children: [
                          //     //       Text(
                          //     //         chat['timestamp'] != null
                          //     //             ? (chat['timestamp'] as Timestamp)
                          //     //                 .toDate()
                          //     //                 .toLocal()
                          //     //                 .toString()
                          //     //                 .split(' ')[1]
                          //     //                 .substring(0, 5)
                          //     //             : '',
                          //     //         style: TextStyle(
                          //     //           fontSize: 12.0,
                          //     //           color: _darkMode
                          //     //               ? Colors.white70
                          //     //               : Colors.black54,
                          //     //           height: 1.2,
                          //     //         ),
                          //     //       ),
                          //     //     ],
                          //     //   ),
                          //     //   onTap: () {
                          //     //     _startChat(otherUserId, userName);
                          //     //   },
                          //     // );
                          //   },
                          // );
                          return FutureBuilder<DocumentSnapshot>(
                            future: _firestore
                                .collection('users')
                                .doc(otherUserId)
                                .get(),
                            builder: (context, userSnapshot) {
                              if (userSnapshot.connectionState ==
                                  ConnectionState.waiting) {
                                return const ListTile(
                                    title: Text('Loading user info...'));
                              }

                              if (userSnapshot.hasError ||
                                  !userSnapshot.hasData ||
                                  !userSnapshot.data!.exists) {
                                return const ListTile(
                                    title: Text('Error loading user info.'));
                              }

                              final userData = userSnapshot.data!.data()
                                      as Map<String, dynamic>? ??
                                  {};

                              // Properly handle isDisabled flag
                              final bool isDisabled =
                                  userData.containsKey('isDisabled')
                                      ? (userData['isDisabled'] as bool)
                                      : false;

                              // If the user is disabled, use default values
                              final String userName = isDisabled
                                  ? 'Organize User'
                                  : (userData['name'] ?? 'Unknown User');
                              final String profileImageUrl = isDisabled
                                  ? ''
                                  : (userData['profileImageUrl'] ?? '');

                              return ListTile(
                                leading: CircleAvatar(
                                  radius: 30,
                                  backgroundImage: profileImageUrl.isNotEmpty
                                      ? CachedNetworkImageProvider(
                                          profileImageUrl)
                                      : null,
                                  child: profileImageUrl.isEmpty
                                      ? Icon(
                                          Icons.person,
                                          color: _darkMode
                                              ? Colors.white
                                              : Colors.black,
                                        )
                                      : null,
                                ),
                                title: Text(
                                  userName,
                                  style: TextStyle(
                                    color:
                                        _darkMode ? Colors.white : Colors.black,
                                    fontWeight: (chat['status'] == 'sent' &&
                                            chat['from'] != currentUser!.uid)
                                        ? FontWeight.w900
                                        : FontWeight.w500,
                                    letterSpacing: 0.6,
                                  ),
                                ),
                                subtitle: Text(
                                  chat['lastMessage'] ?? 'No message available',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: (chat['status'] == 'sent' &&
                                            chat['from'] != currentUser!.uid)
                                        ? FontWeight.w900
                                        : FontWeight.w400,
                                    color: _darkMode
                                        ? (chat['status'] == 'sent' &&
                                                chat['from'] !=
                                                    currentUser!.uid)
                                            ? Colors.white
                                            : Colors.white70
                                        : (chat['status'] == 'sent' &&
                                                chat['from'] !=
                                                    currentUser!.uid)
                                            ? Colors.black
                                            : Colors.black54,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                trailing: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      chat['timestamp'] != null
                                          ? (chat['timestamp'] as Timestamp)
                                              .toDate()
                                              .toLocal()
                                              .toString()
                                              .split(' ')[1]
                                              .substring(0, 5)
                                          : '',
                                      style: TextStyle(
                                        fontWeight: (chat['status'] == 'sent' &&
                                                chat['from'] !=
                                                    currentUser!.uid)
                                            ? FontWeight.w900
                                            : FontWeight.w400,
                                        fontSize: 12.0,
                                        color: _darkMode
                                            ? (chat['status'] == 'sent' &&
                                                    chat['from'] !=
                                                        currentUser!.uid)
                                                ? Colors.white
                                                : Colors.white70
                                            : (chat['status'] == 'sent' &&
                                                    chat['from'] !=
                                                        currentUser!.uid)
                                                ? Colors.black
                                                : Colors.black54,
                                        height: 1.2,
                                      ),
                                    ),
                                  ],
                                ),
                                onTap: () {
                                  _startChat(otherUserId, userName);
                                },
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
                bannerAd != null
                    ? Padding(
                        padding: const EdgeInsets.all(12),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.purple.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: StartAppBanner(bannerAd!),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
                // if (_isAdLoaded)
                //   SizedBox(
                //     height: _bannerAd.size.height.toDouble(),
                //     width: _bannerAd.size.width.toDouble(),
                //     child: AdWidget(ad: _bannerAd),
                //   ),
                // if (_isAdLoaded)
                //   Padding(
                //     padding: const EdgeInsets.symmetric(
                //         vertical: 8.0, horizontal: 16.0),
                //     child: Container(
                //       decoration: BoxDecoration(
                //         borderRadius: BorderRadius.circular(12),
                //         boxShadow: [
                //           BoxShadow(
                //             color: Colors.black.withOpacity(0.1),
                //             blurRadius: 6,
                //             spreadRadius: 2,
                //             offset: const Offset(0, 3),
                //           ),
                //         ],
                //       ),
                //       child: ClipRRect(
                //         borderRadius: BorderRadius.circular(12),
                //         child: SizedBox(
                //           height: _bannerAd.size.height.toDouble(),
                //           width: _bannerAd.size.width.toDouble(),
                //           child: AdWidget(ad: _bannerAd),
                //         ),
                //       ),
                //     ),
                //   ),
              ],
            ),
    );
  }

  /// **Helper function to check and decrypt messages**
  // Future<String> _decryptLastMessage(String message) async {
  //   if (message.contains(':')) {
  //     // Check if it's encrypted (IV:CipherText format)
  //     try {
  //       return await EncryptionHelper.decryptData(message);
  //     } catch (e) {
  //       print("Decryption error: $e");
  //       return message; // If decryption fails, show the raw message
  //     }
  //   } else {
  //     return message; // Return plain text as-is
  //   }
  // }
  //this down
  // Future<String> _decryptLastMessage(String message) async {
  //   if (message.contains(':')) {
  //     // Check if it's encrypted (IV:CipherText format)
  //     try {
  //       // Create an instance of EncryptionHelper
  //       EncryptionHelper encryptionHelper = EncryptionHelper();
  //       return await encryptionHelper
  //           .decryptMessage(message as Map<String, String>);
  //     } catch (e) {
  //       print("Decryption error: $e");
  //       return message; // If decryption fails, show the raw message
  //     }
  //   } else {
  //     return message; // Return plain text as-is
  //   }
  // }
}
