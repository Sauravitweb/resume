import 'package:flutter/material.dart';
import 'package:organize/screens/Social/activity_tracking_screen.dart';
import 'package:organize/screens/Social/social_management_screen.dart';
import 'package:organize/utilities/build_navigation_card.dart';
import 'package:startapp_sdk/startapp.dart';
import 'package:organize/services/event_service.dart';
import 'package:organize/services/notification_service.dart';

class Event {
  final String title;
  final DateTime dateTime;
  final String location;

  Event({required this.title, required this.dateTime, required this.location});
}

class SocialScreen extends StatefulWidget {
  const SocialScreen({super.key});

  @override
  _SocialScreenState createState() => _SocialScreenState();
}

class _SocialScreenState extends State<SocialScreen> {
  final EventService _eventService = EventService();
  final NotificationService _notificationService = NotificationService();

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
  }

  // void _initializeBannerAd() {
  //   _bannerAd = BannerAd(
  //     adUnitId:
  //         'ca-app-pub-9437673525104730/3584782555', // Replace with real Ad Unit ID
  //     size: AdSize.banner,
  //     request: const AdRequest(),
  //     listener: BannerAdListener(
  //       onAdLoaded: (ad) {
  //         setState(() {
  //           _isAdLoaded = true;
  //         });
  //       },
  //       onAdFailedToLoad: (ad, error) {
  //         // debugPrint('Ad failed to load: $error');
  //         ad.dispose();
  //       },
  //     ),
  //   );
  //   _bannerAd.load();
  // }

  Future<void> createSocialEvent(Event event, List<String> invitees) async {
    await _eventService.createEvent(
        event.title, event.dateTime, event.location, invitees);
    await scheduleEventReminder(event);
  }

  Future<void> scheduleEventReminder(Event event) async {
    await _notificationService.scheduleDailyNotification(
      'Event Reminder',
      '${event.title} is happening soon!',
      TimeOfDay.fromDateTime(event.dateTime.subtract(const Duration(hours: 1))),
    );
  }

  @override
  void dispose() {
    // _bannerAd.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Social Management',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Column(
                  children: [
                    NavigationCard(
                      title: 'Social Events',
                      subtitle: 'Manage upcoming social events.',
                      icon: Icons.event,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const SocialManagementScreen(),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                    NavigationCard(
                      title: 'Activity Tracking',
                      subtitle: 'Track social activities and interactions.',
                      icon: Icons.trending_up,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                const ActivityTrackingScreen(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
            bannerAd != null
                ? Padding(
                    padding: const EdgeInsets.all(12),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.purple.withOpacity(0.1),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: StartAppBanner(bannerAd!),
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}
