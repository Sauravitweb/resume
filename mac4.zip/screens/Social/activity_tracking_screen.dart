import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:startapp_sdk/startapp.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

class Activity {
  String id; // Non-final field
  String title; // Non-final field
  String category; // Non-final field
  final DateTime date; //immutable

  final String userId; //immutabele

  Activity({
    required this.id, // Required parameter
    required this.title,
    required this.category,
    required this.date,
    required this.userId,
  });

  // Factory method to create an Activity from Firestore document
  factory Activity.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Activity(
      id: doc.id, // Get the document ID
      title: data['title'] ?? '',
      category: data['category'] ?? '',
      date: data['date'] != null
          ? (data['date'] as Timestamp).toDate()
          : DateTime.now(), // Handle null value
      userId: data['userId'] ?? '',
    );
  }

  // Method to convert an Activity instance to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'category': category,
      'date': Timestamp.fromDate(date),
      'userId': userId,
    };
  }

  // Optional: Add setter methods for title and category if needed
  void setTitle(String newTitle) {
    title = newTitle;
  }

  void setCategory(String newCategory) {
    category = newCategory;
  }
}

// The ActivityTrackingScreen class remains unchanged
class ActivityTrackingScreen extends StatefulWidget {
  const ActivityTrackingScreen({super.key});

  @override
  _ActivityTrackingScreenState createState() => _ActivityTrackingScreenState();
}

class _ActivityTrackingScreenState extends State<ActivityTrackingScreen> {
  final List<Activity> _activities = []; // List to store activities
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  DateTime _selectedDate = DateTime.now();
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchActivities();

    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/6297334479', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       // print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  Future<void> _fetchActivities() async {
    try {
      final user = FirebaseAuth.instance.currentUser; // Get the logged-in user
      if (user == null) {
        return; // If no user is logged in, return early
      }

      final snapshot = await _firestore
          .collection('activities')
          .where('userId',
              isEqualTo: user.uid) // Fetch activities for this user
          .get();

      setState(() {
        _activities.clear();
        _activities
            .addAll(snapshot.docs.map((doc) => Activity.fromFirestore(doc)));
        _isLoading = false;
      });
    } catch (e) {
      // // Handle error (e.g., show a snackbar)
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error fetching activities: $e')),
      // );
    }
  }

  bool _isLoading = true;
  Future<void> _addActivity(String title, String category) async {
    final currentUser =
        FirebaseAuth.instance.currentUser; // Get the logged-in user
    if (currentUser == null) return;
    final newActivity = Activity(
      id: '', // Will be generated in Firestore
      title: title,
      category: category,
      date: _selectedDate,
      userId: currentUser.uid,
    );

    try {
      DocumentReference docRef =
          await _firestore.collection('activities').add(newActivity.toMap());

      // Create a new Activity with the generated ID
      newActivity.id = docRef.id;

      // Refresh activities after adding
      setState(() {
        _activities.add(newActivity);
      });
    } catch (e) {
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error adding activity: $e')),
      // );
    }
  }

  Future<void> _deleteActivity(String id) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Event',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this event? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      try {
        await _firestore.collection('activities').doc(id).delete();
        setState(() {
          _activities.removeWhere((activity) => activity.id == id);
        });
      } catch (e) {}
    }
  }

  Future<void> _updateActivity(Activity activity) async {
    final titleController = TextEditingController(text: activity.title);
    String? selectedCategory = activity.category;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Edit Activity',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleController,
                style: const TextStyle(color: Colors.black),
                decoration: InputDecoration(
                  labelText: 'Title',
                  labelStyle: const TextStyle(color: Colors.grey),
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 15, horizontal: 10),
                ),
              ),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(
                dropdownColor: Colors.white,
                value: selectedCategory,
                hint: const Text('Select Category'),
                decoration: InputDecoration(
                  focusedBorder: const OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.blueAccent),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey.shade400),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                items: const ['Exercise', 'Work', 'Leisure', 'Others']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                      value: value, child: Text(value));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedCategory = value;
                  });
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'Update Activity',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty || selectedCategory == null) {
                  return; // Handle error appropriately
                }
                try {
                  _firestore.collection('activities').doc(activity.id).update({
                    'title': titleController.text,
                    'category': selectedCategory,
                    'date': Timestamp.fromDate(activity.date),
                  });
                  activity.setTitle(titleController.text);
                  activity.setCategory(selectedCategory!);
                  Navigator.of(ctx).pop();
                  setState(() {}); // Refresh UI
                } catch (e) {
                  // ScaffoldMessenger.of(context).showSnackBar(
                  //   SnackBar(content: Text('Error updating activity: $e')),
                  // );
                }
              },
            ),
          ],
        );
      },
    );
  }

  void _showAddActivityDialog() {
    final titleController = TextEditingController();
    String? selectedCategory;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Add New Activity',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  style:
                      const TextStyle(color: Colors.black), // Black text color
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  dropdownColor: Colors.white,
                  value: selectedCategory,
                  hint: const Text('Select Category'),
                  decoration: InputDecoration(
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    'Exercise', // Broad category
                    'Gym', // Subcategory
                    'Running',
                    'Yoga',
                    'Work', // Broad category
                    'Coding',
                    'Study',
                    'Meeting',
                    'Leisure', // Broad category
                    'Movie',
                    'Music',
                    'Travel',
                    'Food',
                    'Coffee',
                    'Others'
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value;
                    });
                  },
                ),
                ListTile(
                  tileColor: Colors.white,
                  title: const Text(
                    "Select Date",
                    style: TextStyle(color: Colors.black),
                  ),
                  subtitle: Text(
                    '${_selectedDate.day}/${_selectedDate.month}/${_selectedDate.year}',
                    style: TextStyle(color: Colors.black),
                  ),
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                      barrierColor: Colors.white,
                      context: context,
                      initialDate: _selectedDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    );
                    if (pickedDate != null && pickedDate != _selectedDate) {
                      setState(() {
                        _selectedDate = pickedDate;
                      });
                    }
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black, // Black text color
              ),
              child: const Text(
                'Add Activity',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty || selectedCategory == null) {
                  return; // Handle error appropriately
                }
                _addActivity(titleController.text, selectedCategory!);
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.blueAccent,
        elevation: 0,
        title: const Text(
          'Track Activities',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        centerTitle: true,
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent))
          : Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.blueAccent, Colors.lightBlueAccent],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(6),
                      bottomRight: Radius.circular(6),
                    ),
                  ),
                  padding: const EdgeInsets.all(10.0),
                  child: Text(
                    'Total Activities: ${_activities.length}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      height: 0.5,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Expanded(
                  child: _activities.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.sports_score,
                                size: 100,
                                color: Colors.blueAccent.withOpacity(0.6),
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                'No activities yet!',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                  // color: Colors.black54,
                                ),
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                'Tap the "+" icon to add your first activity.',
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: _activities.length,
                          itemBuilder: (context, index) {
                            final activity = _activities[index];
                            return Card(
                              color: Theme.of(context).cardColor,
                              margin: const EdgeInsets.symmetric(vertical: 8.0),
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.all(12.0),
                                leading: CircleAvatar(
                                  backgroundColor:
                                      _getCategoryColor(activity.category)
                                          .withOpacity(0.2),
                                  child: FaIcon(
                                    _getCategoryIcon(activity.category),
                                    color: _getCategoryColor(activity.category),
                                  ),
                                ),
                                title: Text(
                                  activity.title,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    // color: Theme.of(context).textTheme,
                                  ),
                                ),
                                subtitle: Text(
                                  'Category: ${activity.category}\nDate: ${activity.date.day}/${activity.date.month}/${activity.date.year}',
                                  style: Theme.of(context)
                                      .listTileTheme
                                      .subtitleTextStyle,
                                ),
                                trailing: PopupMenuButton<String>(
                                  icon: const Icon(Icons.more_vert),
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      _updateActivity(activity);
                                    } else if (value == 'delete') {
                                      _deleteActivity(activity.id);
                                    }
                                  },
                                  itemBuilder: (context) {
                                    return [
                                      const PopupMenuItem<String>(
                                        value: 'edit',
                                        child: Text('Edit'),
                                      ),
                                      const PopupMenuItem<String>(
                                        value: 'delete',
                                        child: Text('Delete'),
                                      ),
                                    ];
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                ),
                bannerAd != null
                    ? Padding(
                        padding: const EdgeInsets.all(12),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.purple.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: StartAppBanner(bannerAd!),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),
      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 60), // Adjust this value as needed
        child: FloatingActionButton(
          onPressed: _showAddActivityDialog,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Activity',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase().trim()) {
      // Health & Fitness
      case 'exercise':
      case 'workout':
      case 'gym':
        return FontAwesomeIcons.dumbbell;
      case 'running':
      case 'jogging':
        return FontAwesomeIcons.personRunning;
      case 'yoga':
      case 'meditation':
        return FontAwesomeIcons.om;

      // Work & Productivity
      case 'work':
      case 'office':
      case 'meeting':
        return FontAwesomeIcons.laptop;
      case 'study':
      case 'learning':
        return FontAwesomeIcons.graduationCap;
      case 'coding':
      case 'programming':
        return FontAwesomeIcons.code;

      // Leisure & Entertainment
      case 'leisure':
      case 'relax':
        return FontAwesomeIcons.solidSmile;
      case 'movie':
      case 'tv':
        return FontAwesomeIcons.film;
      case 'music':
        return FontAwesomeIcons.music;
      case 'travel':
        return FontAwesomeIcons.plane;

      // Food & Dining
      case 'food':
      case 'dining':
        return FontAwesomeIcons.utensils;
      case 'coffee':
      case 'tea':
        return FontAwesomeIcons.mugHot;

      // Defaults
      case 'others':
      case 'misc':
        return FontAwesomeIcons.plus;
      default:
        return FontAwesomeIcons.questionCircle; // Unknown category
    }
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase().trim()) {
      // Exercise & Fitness
      case 'exercise':
        return Colors.green.shade600; // Vibrant green
      case 'gym':
        return Colors.green.shade400; // Lighter green
      case 'running':
        return Colors.lightGreen.shade600;
      case 'yoga':
        return Colors.teal.shade400; // Calm teal for yoga

      // Work & Productivity
      case 'work':
        return Colors.blue.shade700; // Professional blue
      case 'coding':
        return Colors.indigo.shade600; // Deep indigo
      case 'study':
        return Colors.blue.shade400; // Soft blue
      case 'meeting':
        return Colors.blueAccent.shade400;

      // Leisure & Lifestyle
      case 'leisure':
        return Colors.orange.shade600; // Warm orange
      case 'movie':
        return Colors.amber.shade600; // Golden
      case 'music':
        return Colors.deepOrange.shade400;
      case 'travel':
        return Colors.cyan.shade600; // Fresh cyan
      case 'food':
        return Colors.red.shade400; // Appetizing red
      case 'coffee':
        return Colors.brown.shade400; // Coffee brown

      // Default
      case 'others':
        return Colors.purple.shade400; // Distinct purple
      default:
        return Colors.grey.shade500; // Neutral fallback
    }
  }
}
