// }
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:organize/services/notification_service.dart';
import 'package:startapp_sdk/startapp.dart';
import 'package:timezone/data/latest_all.dart' as tz;

// Event model
class Event {
  final String id;
  final String title;
  final DateTime dateTime;
  final String location;
  final String userId;

  Event({
    required this.id,
    required this.title,
    required this.dateTime,
    required this.location,
    required this.userId,
  });

  // Factory method to create an Event from Firestore document
  factory Event.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Event(
      id: doc.id,
      title: data['title'] ?? '',
      dateTime: (data['dateTime'] is Timestamp)
          ? (data['dateTime'] as Timestamp).toDate()
          : DateTime.now(),
      location: data['location'] ?? '',
      userId: data['userId'] ?? '',
    );
  }

  // Method to convert an Event to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'dateTime': Timestamp.fromDate(dateTime),
      'location': location,
      'userId': userId,
    };
  }
}

// Main screen for social management
class SocialManagementScreen extends StatefulWidget {
  const SocialManagementScreen({Key? key}) : super(key: key);

  @override
  _SocialManagementScreenState createState() => _SocialManagementScreenState();
}

class _SocialManagementScreenState extends State<SocialManagementScreen> {
  final List<Event> _events = []; // List to store events
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  // late BannerAd _bannerAd;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  // bool _isAdLoaded = false;
  final FlutterLocalNotificationsPlugin _notificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final NotificationService _notificationService = NotificationService();
  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchEvents();
    _initializeNotifications();

    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/3367084658', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       // print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  Future<void> _initializeNotifications() async {
    tz.initializeTimeZones();

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings settings =
        InitializationSettings(android: androidSettings);

    await _notificationsPlugin.initialize(settings);
  }

  Future<void> _addEvent(
      String title, DateTime dateTime, String location) async {
    final currentUser = _auth.currentUser;
    if (currentUser == null) return;

    final newEventMap = {
      'title': title,
      'dateTime': Timestamp.fromDate(dateTime),
      'location': location,
      'userId': currentUser.uid,
    };

    DocumentReference docRef =
        await _firestore.collection('events').add(newEventMap);
    final newEvent = Event(
      id: docRef.id,
      title: title,
      dateTime: dateTime,
      location: location,
      userId: currentUser.uid,
    );

    setState(() {
      _events.add(newEvent);
    });

    // Schedule Notification
    final duration = dateTime.difference(DateTime.now());
    // final duration = reminderDateTime!.toLocal();

    if (duration.inSeconds > 0) {
      Future.delayed(duration, () {
        _notificationService.showNotification(
          'Event Reminder: $title',
          'Your event at $location is scheduled for ${DateFormat('yyyy-MM-dd HH:mm').format(dateTime)}',
        );
      });
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _fetchEvents() async {
    try {
      User? userId =
          FirebaseAuth.instance.currentUser; // Get the logged-in user's ID
      if (userId == null) return;

      final snapshot = await _firestore
          .collection('events')
          .where('userId', isEqualTo: userId.uid) // Fetch events for this user
          .get();

      setState(() {
        _events.clear();
        for (var doc in snapshot.docs) {
          _events.add(Event.fromFirestore(doc));
        }
      });
    } catch (e) {
      _showError('Error fetching events: $e');
    }
  }


  Future<void> _deleteEvent(String id) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Event',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this event? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      try {
        await _firestore.collection('events').doc(id).delete();
        setState(() {
          _events.removeWhere((event) => event.id == id);
        });
      } catch (e) {
        _showError('Error deleting event: $e');
      }
    }
  }

  void _showEditEventDialog(String eventId) {
    final titleController = TextEditingController();
    final locationController = TextEditingController();
    DateTime? selectedDate; // Initialize selectedDate as nullable

    // Fetch event data from Firestore
    FirebaseFirestore.instance
        .collection('events')
        .doc(eventId)
        .get()
        .then((eventSnapshot) {
      if (eventSnapshot.exists) {
        final event = eventSnapshot.data()!;

        // Pre-populate fields with event data
        titleController.text = event['title'];
        locationController.text = event['location'];
        selectedDate = (event['dateTime'] as Timestamp).toDate();

        showDialog(
          context: context,
          builder: (ctx) {
            return AlertDialog(
              backgroundColor: Colors.white,
              title: const Text(
                'Edit Event',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: Colors.black87,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Title Input Field
                    TextField(
                      controller: titleController,
                      style: const TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                        labelText: 'Title',
                        labelStyle: const TextStyle(color: Colors.grey),
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.blueAccent),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.shade400),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 15, horizontal: 10),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Location Input Field
                    TextField(
                      controller: locationController,
                      style: const TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                        labelText: 'Location',
                        labelStyle: const TextStyle(color: Colors.grey),
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.blueAccent),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.shade400),
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 15, horizontal: 10),
                      ),
                    ),
                    const SizedBox(height: 10),

                    // Date and Time Selection
                    GestureDetector(
                      onTap: () async {
                        final pickedDate = await showDatePicker(
                          context: context,
                          initialDate: selectedDate ?? DateTime.now(),
                          firstDate: DateTime(1900), // Allow past dates
                          lastDate: DateTime(2100),
                        );

                        if (pickedDate != null) {
                          final pickedTime = await showTimePicker(
                            context: context,
                            initialTime: TimeOfDay.fromDateTime(
                                selectedDate ?? DateTime.now()),
                          );

                          if (pickedTime != null) {
                            setState(() {
                              selectedDate = DateTime(
                                pickedDate.year,
                                pickedDate.month,
                                pickedDate.day,
                                pickedTime.hour,
                                pickedTime.minute,
                              );
                            });
                          }
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          'Selected Date & Time: ${getFormattedDateTime(selectedDate ?? DateTime.now())}',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: Colors.grey,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black,
                  ),
                  child: const Text(
                    'Save Changes',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  onPressed: () async {
                    // Validate inputs
                    if (titleController.text.isEmpty ||
                        locationController.text.isEmpty ||
                        selectedDate == null) {
                      _showError('Please fill in all fields.');
                      return;
                    }

                    try {
                      // Update the event in Firestore
                      await FirebaseFirestore.instance
                          .collection('events')
                          .doc(
                              eventId) // Pass the event ID to update the specific event
                          .update({
                        'title': titleController.text.trim(),
                        'location': locationController.text.trim(),
                        'dateTime': Timestamp.fromDate(selectedDate!),
                      });
                      _fetchEvents(); // Fetch updated events from Firestore
                      Navigator.of(context).pop(); // Close the dialog
                    } catch (e) {
                      _showError('Error updating event: $e');
                    }
                  },
                ),
              ],
            );
          },
        );
      } else {
        _showError('Event not found.');
      }
    }).catchError((e) {
      _showError('Error fetching event: $e');
    });
  }

  void _showAddEventDialog() {
    final titleController = TextEditingController();
    final locationController = TextEditingController();
    DateTime selectedDateTime =
        DateTime.now(); // Initialize with current date and time

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white, // Light background for dialog
          title: const Text(
            'Add New Event',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title Input Field
                TextField(
                  controller: titleController,
                  style:
                      const TextStyle(color: Colors.black), // Black text color
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Location Input Field
                TextField(
                  controller: locationController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Location',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Date and Time Selection
                GestureDetector(
                  onTap: () async {
                    // Date picker logic
                    final pickedDate = await showDatePicker(
                      context: context,
                      initialDate: selectedDateTime,
                      firstDate: DateTime.now(),
                      lastDate: DateTime(2100),
                    );

                    if (pickedDate != null) {
                      final pickedTime = await showTimePicker(
                        context: context,
                        initialTime: TimeOfDay.fromDateTime(selectedDateTime),
                      );

                      if (pickedTime != null) {
                        setState(() {
                          selectedDateTime = DateTime(
                            pickedDate.year,
                            pickedDate.month,
                            pickedDate.day,
                            pickedTime.hour,
                            pickedTime.minute,
                          );
                        });
                      }
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Selected Date & Time: ${getFormattedDateTime(selectedDateTime)}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'Add Event',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty ||
                    locationController.text.isEmpty) {
                  return; // Optionally show an error here
                }
                _addEvent(
                  titleController.text,
                  selectedDateTime,
                  locationController.text,
                );
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }


  String getFormattedDateTime(DateTime dateTime) {
    return "${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}";
  }
  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Social Events',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
           ),
        centerTitle: true,
        // backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        children: [
          Expanded(
            child: _events.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.event_note,
                          size: 100,
                          color: Colors.blueAccent.withOpacity(0.6),
                        ),
                        const SizedBox(height: 20),
                        const Text(
                          'No Events Yet!',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 15),
                        const Text(
                          'Tap the "+" button to add your first event.',
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _events.length,
                    itemBuilder: (context, index) {
                      final event = _events[index];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        // decoration: BoxDecoration(
                        //   // color: Colors.white,
                        //   borderRadius: BorderRadius.circular(10),
                        //   // boxShadow: [
                        //   //   BoxShadow(
                        //   //     color: Colors.black.withOpacity(0.1),
                        //   //     blurRadius: 5,
                        //   //     offset: const Offset(0, 3),
                        //   //   ),
                        //   // ],
                        // ),
                        // margin: const EdgeInsets.symmetric(vertical: 8.0),
                        elevation: 4,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 20, vertical: 10),
                          title: Text(
                            event.title,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 18),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Location: ${event.location}\nDate: ${event.dateTime.day}/${event.dateTime.month}/${event.dateTime.year}',
                                style: Theme.of(context)
                                    .listTileTheme
                                    .subtitleTextStyle,
                              ),
                            ],
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') {
                                _showEditEventDialog(event.id);
                              } else if (value == 'delete') {
                                _deleteEvent(event.id);
                              }
                            },
                            itemBuilder: (context) => [
                              const PopupMenuItem(
                                value: 'edit',
                                child: Text('Edit'),
                              ),
                              const PopupMenuItem(
                                value: 'delete',
                                child: Text('Delete'),
                              ),
                            ],
                            icon: const Icon(Icons.more_vert),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
          // if (_isAdLoaded)
          //   SizedBox(
          //     height: _bannerAd.size.height.toDouble(),
          //     width: _bannerAd.size.width.toDouble(),
          //     child: AdWidget(ad: _bannerAd),
          //   ),
          // if (_isAdLoaded)
          //   Padding(
          //     padding:
          //         const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
          //     child: Container(
          //       decoration: BoxDecoration(
          //         borderRadius: BorderRadius.circular(12),
          //         boxShadow: [
          //           BoxShadow(
          //             color: Colors.black.withOpacity(0.1),
          //             blurRadius: 6,
          //             spreadRadius: 2,
          //             offset: const Offset(0, 3),
          //           ),
          //         ],
          //       ),
          //       child: ClipRRect(
          //         borderRadius: BorderRadius.circular(12),
          //         child: SizedBox(
          //           height: _bannerAd.size.height.toDouble(),
          //           width: _bannerAd.size.width.toDouble(),
          //           child: AdWidget(ad: _bannerAd),
          //         ),
          //       ),
          //     ),
          //   ),
        ],
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: _showAddEventDialog,
      //   backgroundColor: Colors.blueAccent,
      //   tooltip: 'Add Event',
      //   child: const Icon(Icons.add),
      // ),
      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 60), // Adjust this value as needed
        child: FloatingActionButton(
          onPressed: _showAddEventDialog,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Event',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}
