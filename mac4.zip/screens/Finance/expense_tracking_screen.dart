import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:organize/constants/routes.dart';
import 'package:startapp_sdk/startapp.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

class Expense {
  String id;
  final String title;
  final double amount;
  final DateTime date;
  final String category;
  final String userId;

  Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
    required this.userId,
  });

  factory Expense.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return Expense(
      id: doc.id,
      title: data['title'] ?? '',
      amount: data['amount'] ?? 0.0,
      date: (data['date'] as Timestamp).toDate(),
      category: data['category'] ?? '',
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'amount': amount,
      'date': Timestamp.fromDate(date),
      'category': category,
      'userId': userId,
    };
  }
}

class ExpenseTrackingScreen extends StatefulWidget {
  const ExpenseTrackingScreen({super.key});

  @override
  _ExpenseTrackingScreenState createState() => _ExpenseTrackingScreenState();
}

class _ExpenseTrackingScreenState extends State<ExpenseTrackingScreen> {
  final List<Expense> _expenses = [];
  double _totalExpenses = 0.0;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isLoading = false;

  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchExpenses();
    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/5884634454', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  Future<void> _fetchExpenses() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final snapshot = await _firestore
          .collection('expenses')
          .where('userId', isEqualTo: user.uid)
          .get();

      setState(() {
        _expenses.clear();
        _totalExpenses = 0.0;
        for (var doc in snapshot.docs) {
          Expense expense = Expense.fromFirestore(doc);
          _expenses.add(expense);
          _totalExpenses += expense.amount;
        }
      });
    } catch (e) {
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error fetching expenses: $e')),
      // );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _addExpense(String title, double amount, String category) async {
    final currentUser = FirebaseAuth.instance.currentUser;
    final newExpense = Expense(
      id: '',
      title: title,
      amount: amount,
      date: DateTime.now(),
      category: category,
      userId: currentUser!.uid,
    );

    try {
      DocumentReference docRef =
          await _firestore.collection('expenses').add(newExpense.toMap());
      newExpense.id = docRef.id;

      setState(() {
        _expenses.add(newExpense);
        _totalExpenses += newExpense.amount;
      });
    } catch (e) {
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error adding expense: $e')),
      // );
    }
  }

  Future<void> _deleteExpense(String id) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Expense',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this expense? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      // Show a loading indicator while the expense is being deleted
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(color: Colors.blueAccent),
        ),
      );

      try {
        await _firestore.collection('expenses').doc(id).delete();
        setState(() {
          _expenses.removeWhere((expense) => expense.id == id);
          _totalExpenses =
              _expenses.fold(0.0, (sum, expense) => sum + expense.amount);
        });
      } catch (e) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   const SnackBar(
        //     content: Text('Failed to delete the expense. Please try again.'),
        //     backgroundColor: Colors.red,
        //   ),
        // );
      } finally {
        Navigator.of(context).pop(); // Close the loading indicator
      }
    }
  }

  void _editExpense(Expense expense) {
    final titleController = TextEditingController(text: expense.title);
    final amountController =
        TextEditingController(text: expense.amount.toString());
    String? selectedCategory = expense.category;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Edit Expense',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title Input Field
                TextField(
                  controller: titleController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Amount Input Field
                TextField(
                  controller: amountController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),

                // Category Dropdown
                DropdownButtonFormField<String>(
                  dropdownColor: Colors.white,
                  value: selectedCategory,
                  hint: const Text('Select Category'),
                  decoration: InputDecoration(
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    'Food',
                    'Transportation',
                    'Entertainment',
                    'Others',
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'Update Expense',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty ||
                    amountController.text.isEmpty ||
                    selectedCategory == null) {
                  return;
                }
                _updateExpense(
                  expense.id,
                  titleController.text,
                  double.parse(amountController.text),
                  selectedCategory!,
                );
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showAddExpenseDialog() {
    final titleController = TextEditingController();
    final amountController = TextEditingController();
    String? selectedCategory;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white, // Light background for dialog
          title: const Text(
            'Add New Expense',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title Input Field
                TextField(
                  controller: titleController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Amount Input Field
                TextField(
                  controller: amountController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),

                // Category Dropdown
                DropdownButtonFormField<String>(
                  dropdownColor: Colors.white,
                  value: selectedCategory,
                  hint: const Text('Select Category'),
                  decoration: InputDecoration(
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    'Food',
                    'Transportation',
                    'Entertainment',
                    'Others',
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'Add Expense',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty ||
                    amountController.text.isEmpty ||
                    selectedCategory == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please fill all fields')),
                  );
                  return;
                }
                _addExpense(
                  titleController.text,
                  double.parse(amountController.text),
                  selectedCategory!,
                );
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _updateExpense(
    String id,
    String title,
    double amount,
    String category,
  ) async {
    final updatedExpense = Expense(
      id: id,
      title: title,
      amount: amount,
      date: DateTime.now(),
      category: category,
      userId: FirebaseAuth.instance.currentUser!.uid,
    );

    try {
      await _firestore
          .collection('expenses')
          .doc(id)
          .update(updatedExpense.toMap());

      setState(() {
        final index = _expenses.indexWhere((expense) => expense.id == id);
        if (index != -1) {
          _expenses[index] = updatedExpense;
          _totalExpenses =
              _expenses.fold(0.0, (sum, expense) => sum + expense.amount);
        }
      });
    } catch (e) {
      // ScaffoldMessenger.of(context).showSnackBar(
      //   SnackBar(content: Text('Error updating expense: $e')),
      // );
    }
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: const Text(
      //     'Track Expenses',
      //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
      //   ),
      //   centerTitle: true,
      //   // backgroundColor: Colors.blueAccent,
      // ),
      appBar: AppBar(
        title: const Text(
          'Track Expenses',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.account_balance,
              color: Colors.blueAccent,
            ), // You can change the icon as needed
            onPressed: () {
              Navigator.pushNamed(context, financeOverviewRoute);
            },
          ),
        ],
      ),

      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent))
          : Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.blueAccent, Colors.lightBlueAccent],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(24),
                      bottomRight: Radius.circular(24),
                    ),
                  ),
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Total Expenses: \$${_totalExpenses.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: _expenses.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.money_off,
                                size: 100,
                                color: Colors.blueAccent.withOpacity(0.6),
                              ),
                              const SizedBox(height: 20),
                              const Text(
                                'No Expenses Yet!',
                                style: TextStyle(
                                    fontSize: 22, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 15),
                              const Text(
                                'Tap the "+" button to add your first expense.',
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _expenses.length,
                          itemBuilder: (context, index) {
                            final expense = _expenses[index];
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 10),
                              // decoration: BoxDecoration(
                              //   // color: Colors.white,
                              //   borderRadius: BorderRadius.circular(10),
                              //   // boxShadow: [
                              //   //   BoxShadow(
                              //   //     color: Colors.black.withOpacity(0.1),
                              //   //     blurRadius: 5,
                              //   //     offset: const Offset(0, 3),
                              //   //   ),
                              //   // ],
                              // ),
                              // margin: const EdgeInsets.symmetric(vertical: 8.0),
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 10),
                                leading: FaIcon(
                                  _getCategoryIcon(expense.category),
                                  size: 30,
                                  color: _getCategoryColor(expense.category),
                                ),
                                title: Text(
                                  expense.title,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                    // color: Colors.black87,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Amount: \$${expense.amount.toStringAsFixed(2)}\n${expense.date.day}/${expense.date.month}/${expense.date.year}',
                                      // style: const TextStyle(
                                      //   // color: Colors.grey,
                                      //   fontWeight: FontWeight.bold,
                                      //   fontSize: 14,
                                      //   height: 1.2,
                                      //   // Larger and darker to emphasize amount
                                      // ),
                                      style: Theme.of(context)
                                          .listTileTheme
                                          .subtitleTextStyle,
                                    ),
                                    // Text(
                                    //   '${expense.date.day}/${expense.date.month}/${expense.date.year}',
                                    //   style: const TextStyle(
                                    //     color: Colors.grey,
                                    //     fontWeight: FontWeight.bold,
                                    //     fontSize: 14, // Slightly smaller and muted color for date
                                    //   ),
                                    // ),
                                  ],
                                ),
                                trailing: PopupMenuButton<String>(
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      _editExpense(expense);
                                    } else if (value == 'delete') {
                                      _deleteExpense(expense.id);
                                    }
                                  },
                                  itemBuilder: (context) => [
                                    const PopupMenuItem(
                                      value: 'edit',
                                      child: Text('Edit'),
                                    ),
                                    const PopupMenuItem(
                                      value: 'delete',
                                      child: Text('Delete'),
                                    ),
                                  ],
                                  icon: const Icon(Icons.more_vert),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                bannerAd != null
                    ? Padding(
                        padding: const EdgeInsets.all(12),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.purple.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: StartAppBanner(bannerAd!),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),

      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 60), // Adjust this value as needed
        child: FloatingActionButton(
          onPressed: _showAddExpenseDialog,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Expense',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return Colors.green;
      case 'transportation':
        return Colors.blue;
      case 'entertainment':
        return Colors.orange;
      case 'others':
      default:
        return Colors.grey;
    }
  }

// Helper method to get FontAwesome icon based on category
  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return FontAwesomeIcons.utensils; // Food
      case 'transportation':
        return FontAwesomeIcons.car; // Transportation
      case 'entertainment':
        return FontAwesomeIcons.ticket; // Entertainment
      case 'others':
      default:
        return FontAwesomeIcons.cogs; // Others
    }
  }
}
