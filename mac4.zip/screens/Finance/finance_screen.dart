import 'package:flutter/material.dart';
import 'package:organize/constants/routes.dart';
import 'package:organize/utilities/build_navigation_card.dart';
import 'package:startapp_sdk/startapp.dart';

// import 'package:google_mobile_ads/google_mobile_ads.dart';

class FinanceScreen extends StatefulWidget {
  const FinanceScreen({super.key});

  @override
  _FinanceScreenState createState() => _FinanceScreenState();
}

class _FinanceScreenState extends State<FinanceScreen> {
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;
  // late WebViewController _webViewController;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Finance Management',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: Column(
                  children: [
                    NavigationCard(
                      title: 'Finance Overview',
                      subtitle: 'Your Finance Overview',
                      onTap: () {
                        Navigator.of(context).pushNamed(financeOverviewRoute);
                      },
                      icon: Icons.account_balance,
                    ),
                    NavigationCard(
                      title: 'Expense Tracking',
                      subtitle: 'Track your daily expenses.',
                      onTap: () {
                        Navigator.of(context).pushNamed(expenseRoute);
                      },
                      icon: Icons.attach_money,
                    ),
                    const SizedBox(height: 20),
                    NavigationCard(
                      title: 'Budget Management',
                      subtitle: 'Manage your budget.',
                      onTap: () {
                        Navigator.of(context).pushNamed(budgetRoute);
                      },
                      icon: Icons.pie_chart,
                    ),
                    const SizedBox(height: 20),
                    NavigationCard(
                      title: 'Financial Goals',
                      subtitle: 'Set and track your financial goals.',
                      onTap: () {
                        Navigator.of(context).pushNamed(financialGoalRoute);
                      },
                      icon: Icons.track_changes,
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
            bannerAd != null
                ? Padding(
                    padding: const EdgeInsets.all(12),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.purple.withOpacity(0.1),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                        child: StartAppBanner(bannerAd!),
                      ),
                    ),
                  )
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}
