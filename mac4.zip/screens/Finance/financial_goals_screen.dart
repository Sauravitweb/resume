import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:startapp_sdk/startapp.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

class FinancialGoal {
  String id;
  String goal;
  double amount;
  double progress;
  DateTime targetDate;
  String userId;

  FinancialGoal({
    required this.id,
    required this.goal,
    required this.amount,
    required this.progress,
    required this.targetDate,
    required this.userId,
  });

  factory FinancialGoal.fromFirestore(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return FinancialGoal(
      id: doc.id,
      goal: data['goal'] ?? '',
      amount: data['amount'] ?? 0.0,
      progress: data['progress'] ?? 0.0,
      targetDate: (data['targetDate'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'goal': goal,
      'amount': amount,
      'progress': progress,
      'targetDate': Timestamp.fromDate(targetDate),
      'userId': userId,
    };
  }
}

class FinancialGoalsScreen extends StatefulWidget {
  const FinancialGoalsScreen({Key? key}) : super(key: key);

  @override
  _FinancialGoalsScreenState createState() => _FinancialGoalsScreenState();
}

class _FinancialGoalsScreenState extends State<FinancialGoalsScreen> {
  final List<FinancialGoal> _goals = [];
  final _goalController = TextEditingController();
  final _amountController = TextEditingController();
  final _progressController = TextEditingController();
  DateTime? _selectedDate;
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchGoals();

    // _bannerAd = BannerAd(
    //   adUnitId:
    //       'ca-app-pub-9437673525104730/2862885296', // 🔴 Replace with your real Ad Unit ID
    //   size: AdSize.banner,
    //   request: AdRequest(),
    //   listener: BannerAdListener(
    //     onAdLoaded: (ad) {
    //       setState(() {
    //         _isAdLoaded = true;
    //       });
    //     },
    //     onAdFailedToLoad: (ad, error) {
    //       print('Ad failed to load: $error');
    //       ad.dispose();
    //     },
    //   ),
    // );

    // _bannerAd.load();
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  Future<void> _fetchGoals() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return;

      final snapshot = await _firestore
          .collection('financialGoals')
          .where('userId', isEqualTo: user.uid)
          .get();

      setState(() {
        _goals.clear();
        for (var doc in snapshot.docs) {
          _goals.add(FinancialGoal.fromFirestore(doc));
        }
      });
    } catch (e) {
      _showError('Error fetching goals: $e');
    }
  }

  Future<void> _addGoal() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        _showError('You must be logged in to add a goal.');
        return;
      }

      if (_goalController.text.isEmpty ||
          _amountController.text.isEmpty ||
          _selectedDate == null) {
        _showError('Please fill in all fields.');
        return;
      }

      final newGoal = FinancialGoal(
        id: DateTime.now().toString(),
        goal: _goalController.text.trim(),
        amount: double.parse(_amountController.text.trim()),
        progress: 0.0,
        targetDate: _selectedDate!,
        userId: currentUser.uid,
      );

      await _firestore.collection('financialGoals').add(newGoal.toMap());
      await _fetchGoals();

      _goalController.clear();
      _amountController.clear();
      _selectedDate = null;

      // ScaffoldMessenger.of(context).showSnackBar(
      //   const SnackBar(content: Text('Goal added successfully!')),
      // );
    } catch (e) {
      _showError('Error adding goal: $e');
    }
  }

  void _showGoalDialog({
    required String title,
    required VoidCallback onConfirm,
    FinancialGoal? goal,
  }) {
    // Initialize controllers with existing goal data if provided
    if (goal != null) {
      _goalController.text = goal.goal;
      _amountController.text = goal.amount.toString();
      _progressController.text = goal.progress.toString();
      _selectedDate = goal.targetDate;
    } else {
      _goalController.clear();
      _amountController.clear();
      _progressController.clear();
      _selectedDate = null;
    }
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white, // Set the background color to white
          title:
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          content: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _buildTextFormField(
                    controller: _goalController,
                    labelText: 'Goal',
                    keyboardType: TextInputType.text,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a goal';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 10),
                  _buildTextFormField(
                    controller: _amountController,
                    labelText: 'Amount',
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter an amount';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 10),
                  if (goal != null)
                    _buildTextFormField(
                      controller: _progressController,
                      labelText: 'Progress',
                      keyboardType: TextInputType.number,
                    ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    style: _customButtonStyle(),
                    onPressed: () async {
                      final pickedDate = await showDatePicker(
                        context: ctx,
                        initialDate: _selectedDate ?? DateTime.now(),
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2101),
                      );

                      if (pickedDate != null) {
                        setState(() {
                          _selectedDate = pickedDate;
                        });
                      }
                    },
                    child: Text(
                      _selectedDate == null
                          ? 'Select Target Date'
                          : 'Selected: ${_selectedDate!.toLocal()}'
                              .split(' ')[0],
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment
                        .spaceBetween, // Distribute space between buttons
                    children: [
                      TextButton(
                        style: _customButtonStyle(),
                        child: const Text('Cancel',
                            style: TextStyle(color: Colors.white)),
                        onPressed: () => Navigator.of(ctx).pop(),
                      ),
                      const SizedBox(
                          width: 10), // Add spacing between the buttons
                      ElevatedButton(
                        style: _customButtonStyle(),
                        child: Text(goal == null ? 'Add Goal' : 'Update Goal'),
                        onPressed: () {
                          // Check if fields are valid
                          if (_goalController.text.isEmpty ||
                              _amountController.text.isEmpty) {
                            // Show error message if fields are invalid
                            ScaffoldMessenger.of(ctx).showSnackBar(
                              const SnackBar(
                                  content: Text(
                                      'Please fill in all required fields')),
                            );
                            return;
                          }
                          onConfirm();
                          // Navigator.of(ctx).pop();
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String labelText,
    required TextInputType keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle: const TextStyle(color: Colors.black), // Label text color
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
      ),
      style: const TextStyle(color: Colors.black), // Input text color
      validator: validator,
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required TextInputType keyboardType,
  }) {
    return TextFormField(
      controller: controller,

      style:
          const TextStyle(color: Colors.black), // Set the text color to black
      decoration: InputDecoration(
        labelText: labelText,
        labelStyle:
            const TextStyle(color: Colors.blue), // Set label color to blue
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(8), // Rounded corners for the input field
          borderSide: const BorderSide(color: Colors.blue), // Border color
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(
              color: Colors.blueAccent, width: 2), // Focused border color
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(
              color: Colors.blue, width: 1), // Enabled border color
        ),
        contentPadding: const EdgeInsets.symmetric(
            vertical: 15, horizontal: 10), // Add padding inside the text field
      ),
      keyboardType: keyboardType,
    );
  }

  void _showAddGoalDialog() {
    _showGoalDialog(
      title: 'Add New Financial Goal',
      onConfirm: () {
        if (_goalController.text.isEmpty ||
            _amountController.text.isEmpty ||
            _selectedDate == null) {
          _showError('Please fill in all fields.');
          return;
        }

        _addGoal();
        Navigator.of(context).pop();
      },
    );
  }

  void _showEditGoalDialog(FinancialGoal goal) {
    _showGoalDialog(
      title: 'Edit Financial Goal',
      goal: goal,
      onConfirm: () async {
        if (_goalController.text.isEmpty ||
            _amountController.text.isEmpty ||
            _progressController.text.isEmpty ||
            _selectedDate == null) {
          _showError('Please fill in all fields.');
          return;
        }

        try {
          await _firestore.collection('financialGoals').doc(goal.id).update({
            'goal': _goalController.text.trim(),
            'amount': double.parse(_amountController.text.trim()),
            'progress': double.parse(_progressController.text.trim()),
            'targetDate': Timestamp.fromDate(_selectedDate!),
          });
          _fetchGoals();

          // Navigator.of(ctx).pop();
          Navigator.of(context).pop();
        } catch (e) {
          _showError('Error updating goal: $e');
        }
      },
    );
  }

  ButtonStyle _customButtonStyle() {
    return ButtonStyle(
      foregroundColor:
          WidgetStateProperty.all(Colors.white), // White text color
      backgroundColor: WidgetStateProperty.all(
          const Color.fromARGB(235, 64, 77, 196)), // Black background color
      shape: WidgetStateProperty.all<RoundedRectangleBorder>(
        RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0), // Rounded corners
          side: const BorderSide(
            color: Colors.grey, // Subtle grey border
            width: 1.0, // Thin border
          ),
        ),
      ),
      padding: WidgetStateProperty.all(
        const EdgeInsets.symmetric(
            vertical: 12.0, horizontal: 20.0), // Standard padding
      ),
      elevation: WidgetStateProperty.all(5.0), // Reduced shadow for minimalism
      textStyle: WidgetStateProperty.all(
        const TextStyle(
          fontSize: 16.0, // Standard font size
          fontWeight: FontWeight.w500, // Medium weight
        ),
      ),
    );
  }

  Future<void> _deleteGoal(String id) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Goal',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this goal? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      // Show a loading indicator while the goal is being deleted
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(color: Colors.blueAccent),
        ),
      );

      try {
        await _firestore.collection('financialGoals').doc(id).delete();
        _fetchGoals();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to delete goal. Please try again.'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        Navigator.of(context).pop(); // Close the loading indicator
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.blueAccent,
        title: const Text('Financial Goals',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        centerTitle: true,
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.add_circle, color: Color.fromARGB(255, 255, 255, 255)),
        //     onPressed: _showAddGoalDialog,
        //   ),
        // ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _goals.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.show_chart_outlined,
                            size: 80,
                            color: Colors.blueAccent.withOpacity(0.6)),
                        const SizedBox(height: 16),
                        const Text(
                          'No financial goals yet!',
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Colors.black54),
                        ),
                        const SizedBox(height: 10),
                        const Text('Tap the "+" icon to add your first goal.',
                            style:
                                TextStyle(fontSize: 14, color: Colors.black45)),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _goals.length,
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 16),
                    itemBuilder: (context, index) {
                      final goal = _goals[index];
                      return Card(
                        color: Theme.of(context).cardColor ?? Colors.white,
                        elevation: 4,
                        margin: const EdgeInsets.only(bottom: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                goal.goal,
                                style: const TextStyle(
                                    fontSize: 20, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'Amount: \$${goal.amount.toStringAsFixed(2)}',
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                              Text(
                                'Target Date: ${goal.targetDate.day}/${goal.targetDate.month}/${goal.targetDate.year}',
                                style: const TextStyle(
                                    fontSize: 14, fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 12),
                              Stack(
                                children: [
                                  Container(
                                    height: 24,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      color: Colors.grey[300],
                                    ),
                                  ),
                                  AnimatedContainer(
                                    duration: const Duration(milliseconds: 500),
                                    height: 24,
                                    width: MediaQuery.of(context).size.width *
                                        (goal.progress / 100),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10),
                                      gradient: LinearGradient(
                                        colors: goal.progress > 75
                                            ? [Colors.green, Colors.lightGreen]
                                            : goal.progress > 50
                                                ? [Colors.yellow, Colors.orange]
                                                : [
                                                    Colors.red,
                                                    Colors.deepOrange
                                                  ],
                                      ),
                                    ),
                                  ),
                                  Positioned.fill(
                                    child: Center(
                                      child: Text(
                                        '${goal.progress.toStringAsFixed(0)}%',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 14,
                                          color: Colors.black,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  PopupMenuButton<String>(
                                    icon: const Icon(Icons.more_vert),
                                    onSelected: (value) {
                                      if (value == 'edit') {
                                        _showEditGoalDialog(goal);
                                      } else if (value == 'delete') {
                                        _deleteGoal(goal.id);
                                      }
                                    },
                                    itemBuilder: (BuildContext context) {
                                      return [
                                        const PopupMenuItem<String>(
                                          value: 'edit',
                                          child: Text('Edit'),
                                        ),
                                        const PopupMenuItem<String>(
                                          value: 'delete',
                                          child: Text('Delete'),
                                        ),
                                      ];
                                    },
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 60), // Adjust this value as needed
        child: FloatingActionButton(
          onPressed: _showAddGoalDialog,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Goal',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}
