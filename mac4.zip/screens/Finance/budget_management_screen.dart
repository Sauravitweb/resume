import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:organize/constants/routes.dart';
import 'package:startapp_sdk/startapp.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

// Budget model
class Budget {
  final String id;
  final String title;
  final double amount;
  final DateTime date;
  final String category;
  final String userId;

  Budget({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
    required this.userId,
  });

  // Factory method to create a Budget from Firestore document
  factory Budget.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Budget(
      id: doc.id,
      title: data['title'] ?? '',
      amount: (data['amount'] as num?)?.toDouble() ?? 0.0,
      date: (data['date'] is String)
          ? DateTime.parse(data['date']) // Parse string to DateTime
          : (data['date'] as Timestamp)
              .toDate(), // Convert Timestamp to DateTime
      category: data['category'] ?? '',
      userId: data['userId'] ?? '',
    );
  }

  // Method to convert a Budget to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'amount': amount,
      'date': Timestamp.fromDate(date), // Store as Timestamp
      'category': category,
      'userId': userId,
    };
  }
}

// Main screen for budget management
class BudgetManagementScreen extends StatefulWidget {
  const BudgetManagementScreen({Key? key}) : super(key: key);

  @override
  _BudgetManagementScreenState createState() => _BudgetManagementScreenState();
}

class _BudgetManagementScreenState extends State<BudgetManagementScreen> {
  final List<Budget> _budgets = []; // List to store budgets
  double _totalBudgets = 0.0;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isLoading = true; // Flag to show a loading indicator
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    _fetchBudgets();
  }

  Future<void> _fetchBudgets() async {
    try {
      final user = FirebaseAuth.instance.currentUser; // Get the logged-in user
      if (user == null) {
        return; // If no user is logged in, return early
      }

      final snapshot = await _firestore
          .collection('budgets')
          .where('userId', isEqualTo: user.uid) // Fetch budgets for this user
          .get();

      setState(() {
        _budgets.clear();
        _totalBudgets = 0.0;
        for (var doc in snapshot.docs) {
          Budget budget = Budget.fromFirestore(doc);
          _budgets.add(budget);
          _totalBudgets += budget.amount;
        }
        _isLoading = false; // Data loaded, stop loading indicator
      });
    } catch (e) {
      _showError('Error fetching budgets: $e');
    }
  }

  Future<void> _addBudget(String title, double amount, String category) async {
    final user = FirebaseAuth.instance.currentUser;
    final newBudgetMap = {
      'title': title,
      'amount': amount,
      'date': Timestamp.fromDate(DateTime.now()), // Store as Timestamp
      'category': category,
      'userId': user!.uid,
    };

    try {
      DocumentReference docRef =
          await _firestore.collection('budgets').add(newBudgetMap);
      final currentUser = FirebaseAuth.instance.currentUser;
      // Create a new budget with the ID from Firestore
      final newBudget = Budget(
        id: docRef.id,
        title: title,
        amount: amount,
        date: DateTime.now(),
        category: category,
        userId: currentUser!.uid,
      );

      setState(() {
        _budgets.add(newBudget);
        _totalBudgets += newBudget.amount;
      });
    } catch (e) {
      _showError('Error adding budget: $e');
    }
  }

  Future<void> _updateBudget(
      String id, String title, double amount, String category) async {
    try {
      await _firestore.collection('budgets').doc(id).update({
        'title': title,
        'amount': amount,
        'category': category,
      });

      setState(() {
        final updatedBudgetIndex =
            _budgets.indexWhere((budget) => budget.id == id);
        if (updatedBudgetIndex != -1) {
          _budgets[updatedBudgetIndex] = Budget(
            id: id,
            title: title,
            amount: amount,
            date: DateTime.now(),
            category: category,
            userId: _budgets[updatedBudgetIndex].userId,
          );
          _totalBudgets =
              _budgets.fold(0.0, (sum, budget) => sum + budget.amount);
        }
      });
    } catch (e) {
      _showError('Error updating budget: $e');
    }
  }

  Future<void> _deleteBudget(String id) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          backgroundColor: Colors.white,
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.red, size: 30),
              SizedBox(width: 10),
              Text(
                'Delete Budget',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
            ],
          ),
          content: const Text(
            'Are you sure you want to delete this budget? This action cannot be undone.',
            style: TextStyle(
              fontSize: 16,
              color: Colors.black87,
            ),
          ),
          actionsAlignment: MainAxisAlignment.spaceAround,
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(false),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                textStyle: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text('Delete'),
              onPressed: () => Navigator.of(context).pop(true),
            ),
          ],
        );
      },
    );

    if (shouldDelete == true) {
      // Show a loading indicator while the budget is being deleted
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(color: Colors.blueAccent),
        ),
      );

      try {
        await _firestore.collection('budgets').doc(id).delete();
        setState(() {
          _budgets.removeWhere((budget) => budget.id == id);
          _totalBudgets =
              _budgets.fold(0.0, (sum, budget) => sum + budget.amount);
        });
      } catch (e) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   const SnackBar(
        //     content: Text('Failed to delete the budget. Please try again.'),
        //     backgroundColor: Colors.red,
        //   ),
        // );
      } finally {
        Navigator.of(context).pop(); // Close the loading indicator
      }
    }
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _showAddBudgetDialog() {
    final titleController = TextEditingController();
    final amountController = TextEditingController();
    String? selectedCategory;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white, // Light background for dialog
          title: const Text(
            'Add New Budget',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title Input Field
                TextField(
                  controller: titleController,
                  style:
                      const TextStyle(color: Colors.black), // Black text color
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Amount Input Field
                TextField(
                  controller: amountController,
                  style:
                      const TextStyle(color: Colors.black), // Black text color
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),

                // Category Dropdown
                DropdownButtonFormField<String>(
                  dropdownColor: Colors.white,
                  value: selectedCategory,
                  hint: const Text('Select Category'),
                  decoration: InputDecoration(
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    'Groceries',
                    'Rent',
                    'Utilities',
                    'Entertainment',
                    'Savings'
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black, // Black text color
              ),
              child: const Text(
                'Add Budget',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty ||
                    amountController.text.isEmpty ||
                    selectedCategory == null) {
                  return;
                }
                _addBudget(
                  titleController.text,
                  double.parse(amountController.text),
                  selectedCategory!,
                );
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showEditBudgetDialog(Budget budget) {
    final titleController = TextEditingController(text: budget.title);
    final amountController =
        TextEditingController(text: budget.amount.toString());
    String? selectedCategory = budget.category;

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: Colors.white,
          title: const Text(
            'Edit Budget',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 18,
              color: Colors.black87,
            ),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title Input Field
                TextField(
                  controller: titleController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                ),
                const SizedBox(height: 10),

                // Amount Input Field
                TextField(
                  controller: amountController,
                  style: const TextStyle(color: Colors.black),
                  decoration: InputDecoration(
                    labelText: 'Amount',
                    labelStyle: const TextStyle(color: Colors.grey),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                        vertical: 15, horizontal: 10),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 10),

                // Category Dropdown
                DropdownButtonFormField<String>(
                  dropdownColor: Colors.white,
                  value: selectedCategory,
                  hint: const Text('Select Category'),
                  decoration: InputDecoration(
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.blueAccent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.grey.shade400),
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  items: const [
                    'Groceries',
                    'Rent',
                    'Utilities',
                    'Entertainment',
                    'Savings'
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.black,
              ),
              child: const Text(
                'Update Budget',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                if (titleController.text.isEmpty ||
                    amountController.text.isEmpty ||
                    selectedCategory == null) {
                  return;
                }
                _updateBudget(
                  budget.id,
                  titleController.text,
                  double.parse(amountController.text),
                  selectedCategory!,
                );
                Navigator.of(ctx).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.blueAccent,
        elevation: 0,
        title: const Text(
          'Budget Management',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(
              Icons.account_balance,
              color: Colors.blueAccent,
            ), // You can change the icon as needed
            onPressed: () {
              Navigator.pushNamed(context, financeOverviewRoute);
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent))
          : Column(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.blueAccent, Colors.lightBlueAccent],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(24),
                      bottomRight: Radius.circular(24),
                    ),
                  ),
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Total Budgets: \$${_totalBudgets.toStringAsFixed(2)}',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: _budgets.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.wallet_travel,
                                size: 100,
                                color: Colors.blueAccent.withOpacity(0.6),
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                'No budgets yet!',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w600,
                                  // color: Colors.black54,
                                ),
                              ),
                              const SizedBox(height: 10),
                              const Text(
                                'Tap the "+" icon to add your first budget.',
                                style: TextStyle(fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          itemCount: _budgets.length,
                          itemBuilder: (context, index) {
                            final budget = _budgets[index];
                            return Card(
                              //  color: Colors.white,
                              margin: const EdgeInsets.symmetric(vertical: 8.0),
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.all(12.0),
                                leading: CircleAvatar(
                                  backgroundColor:
                                      _getCategoryColor(budget.category)
                                          .withOpacity(0.2),
                                  child: FaIcon(
                                    FontAwesomeIcons.wallet,
                                    color: _getCategoryColor(budget.category),
                                  ),
                                ),
                                title: Text(
                                  budget.title,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    // color: Colors.black87,
                                  ),
                                ),
                                subtitle: Text(
                                  'Amount: \$${budget.amount.toStringAsFixed(2)}\nCategory: ${budget.category}',
                                  style: Theme.of(context)
                                      .listTileTheme
                                      .subtitleTextStyle,
                                ),
                                trailing: PopupMenuButton<String>(
                                  icon: const Icon(Icons.more_vert),
                                  onSelected: (value) {
                                    if (value == 'edit') {
                                      _showEditBudgetDialog(budget);
                                    } else if (value == 'delete') {
                                      _deleteBudget(budget.id);
                                    }
                                  },
                                  itemBuilder: (context) {
                                    return [
                                      const PopupMenuItem<String>(
                                        value: 'edit',
                                        child: Text('Edit'),
                                      ),
                                      const PopupMenuItem<String>(
                                        value: 'delete',
                                        child: Text('Delete'),
                                      ),
                                    ];
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                ),
                bannerAd != null
                    ? Padding(
                        padding: const EdgeInsets.all(12),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AnimatedContainer(
                            duration: Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.purple.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: StartAppBanner(bannerAd!),
                          ),
                        ),
                      )
                    : const SizedBox.shrink(),
              ],
            ),
      floatingActionButton: Padding(
        padding:
            const EdgeInsets.only(bottom: 60), // Adjust this value as needed
        child: FloatingActionButton(
          onPressed: _showAddBudgetDialog,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Budget',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  @override
  void dispose() {
    //_bannerAd.dispose(); //this
    super.dispose();
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'utilities':
        return Colors.green;
      case 'entertainment':
        return Colors.redAccent;
      case 'groceries':
        return Colors.orange;
      case 'savings':
        return Colors.blue;
      case 'rent':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }
}
