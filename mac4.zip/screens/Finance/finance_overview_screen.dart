import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
// import 'package:fl_chart/fl_chart.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:startapp_sdk/startapp.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';

class FinanceOverviewScreen extends StatefulWidget {
  const FinanceOverviewScreen({super.key});

  @override
  _FinanceOverviewScreenState createState() => _FinanceOverviewScreenState();
}

class _FinanceOverviewScreenState extends State<FinanceOverviewScreen> {
  double netAmount = 0;
  // List<FlSpot> budgetData = [];
  // List<FlSpot> expenseData = [];
  Map<String, double> budgets = {};
  Map<String, double> expenses = {};
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });

    // _fetchChartData();
    _calculateNetAmount();
    _fetchCategoryData();
  }

  final String? userId = FirebaseAuth.instance.currentUser?.uid;

  Future<void> _calculateNetAmount() async {
    double totalBudget = await _getTotalAmount('budgets');
    double totalExpense = await _getTotalAmount('expenses');
    setState(() {
      netAmount = totalBudget - totalExpense;
    });
  }

  @override
  void dispose() {
    // _bannerAd.dispose(); //this
    super.dispose();
  }

  Future<double> _getTotalAmount(String collection) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection(collection)
        .where('userId', isEqualTo: userId)
        .get();

    // return snapshot.docs
    //     .fold(0, (sum, doc) => sum + (doc['amount'] as num).toDouble());
    return snapshot.docs.fold<double>(
      0.0,
      (sum, doc) => sum + (doc['amount'] as num).toDouble(),
    );
  }

  Future<double> _getAmountByDate(String collection, DateTime date) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection(collection)
        .where('userId', isEqualTo: userId)
        // .where('date', isEqualTo: date.toIso8601String().substring(0, 10))
        // .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(date))
        .get();

    // return snapshot.docs.fold(0, (sum, doc) => sum + (doc['amount'] as num).toDouble());
    return snapshot.docs.fold<double>(
      0.0,
      (sum, doc) => sum + (doc['amount'] as num).toDouble(),
    );
  }

  Future<void> _fetchCategoryData() async {
    await _fetchCategoryAmount('budgets', budgets);
    await _fetchCategoryAmount('expenses', expenses);
  }

  Future<void> _fetchCategoryAmount(
      String collection, Map<String, double> categoryMap) async {
    QuerySnapshot snapshot = await FirebaseFirestore.instance
        .collection(collection)
        .where('userId', isEqualTo: userId)
        .get();

    categoryMap.clear();
    for (var doc in snapshot.docs) {
      String category = doc['category'];
      double amount = (doc['amount'] as num).toDouble();
      categoryMap[category] = (categoryMap[category] ?? 0) + amount;
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Finance Overview',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.blueAccent, Colors.lightBlueAccent],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(24),
                        bottomRight: Radius.circular(24),
                      ),
                    ),
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'Total: ${netAmount.isNegative ? "- \$" : "\$"}${netAmount.abs().toStringAsFixed(2)}',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 6,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: _buildOverviewSection("Budget Overview", budgets),
                  ),
                  Container(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 6,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: _buildOverviewSection("Expense Overview", expenses),
                  ),
                ],
              ),
            ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  double _buildNetAmount() {
    return netAmount;
  }

  Widget _buildOverviewSection(String title, Map<String, double> categoryData) {
    return Card(
      elevation: 3,
      color: Colors.white, // Card remains white always
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      child: Theme(
        data: ThemeData(
          dividerColor: Colors.transparent, // Hide dividers
          splashColor:
              Colors.transparent, // Prevent ripple effect from changing color
        ),
        child: ExpansionTile(
          initiallyExpanded: true,
          backgroundColor: Colors.white, // ExpansionTile background fixed
          collapsedBackgroundColor: Colors.white, // Always white when collapsed
          title: Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black, // Text is always black
            ),
          ),
          iconColor: Colors.black, // Icon color is always black
          textColor: Colors.black, // Text inside ExpansionTile is black
          childrenPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          children: categoryData.keys.map((category) {
            return Card(
              margin: EdgeInsets.symmetric(vertical: 4, horizontal: 6),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              color: Colors.white, // Ensure inner cards are also always white
              child: ExpansionTile(
                backgroundColor:
                    Colors.white, // Ensure expansion tile inside remains white
                collapsedBackgroundColor: Colors.white,
                iconColor: Colors.black,
                textColor: Colors.black,
                title: Text(
                  category,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.black, // Category text is always black
                  ),
                ),
                trailing: Text(
                  "\$${categoryData[category]?.toStringAsFixed(2) ?? '0.00'}",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.green, // Keep amount color green
                  ),
                ),
                childrenPadding:
                    EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                children: [
                  FutureBuilder(
                    future: FirebaseFirestore.instance
                        .collection(
                            title.contains("Budget") ? 'budgets' : 'expenses')
                        .where('userId', isEqualTo: userId)
                        .where('category', isEqualTo: category)
                        .get(),
                    builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                      if (!snapshot.hasData) {
                        return Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Center(
                              child: CircularProgressIndicator(
                                  color: Colors.blueAccent)),
                        );
                      }

                      return Column(
                        children: snapshot.data!.docs.map((doc) {
                          return ListTile(
                            contentPadding: EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            title: Text(
                              doc['title'],
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.black, // ListTile title is black
                              ),
                            ),
                            subtitle: Text(
                              (doc['date'] as Timestamp)
                                  .toDate()
                                  .toLocal()
                                  .toString()
                                  .split(' ')[0],
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  color: Colors
                                      .black54), // Subtitle is slightly dimmed black
                            ),
                            trailing: Text(
                              "\$${doc['amount'].toStringAsFixed(2)}",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.redAccent, // Expenses in red
                              ),
                            ),
                          );
                        }).toList(),
                      );
                    },
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
