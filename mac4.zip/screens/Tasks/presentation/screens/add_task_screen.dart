import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:hive/hive.dart';
import 'package:organize/constants/task_constants.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:organize/shared/widgets/build_text_field.dart';
import 'package:organize/screens/Tasks/services/notification_service.dart';
import 'package:organize/shared/widgets/category_dropdown.dart';
import 'package:organize/shared/widgets/reminder_button.dart';
import 'package:organize/shared/widgets/save_task_utils.dart';

import 'package:organize/services/task_service.dart';
import 'package:organize/screens/Tasks/data/hive/task_hive_service.dart';

class AddTaskScreen extends StatefulWidget {
  final TaskService taskService;
  final TaskHiveService taskHiveService;

  const AddTaskScreen({
    required this.taskService,
    required this.taskHiveService,
    Key? key,
  }) : super(key: key);

  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  String _selectedCategory = 'Home';
  String _selectedPriority = 'Medium';
  DateTime? _reminderDateTime;
  bool _isSaved = false;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController();
    descriptionController = TextEditingController();
  }

  // Future<void> _saveTask() async {
  //   if (titleController.text.trim().isEmpty) {
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       const SnackBar(
  //         content: Text(
  //           'Title cannot be empty',
  //         ),
  //       ),
  //     );
  //     return;
  //   }

  //   final user = FirebaseAuth.instance.currentUser;
  //   final newTask = Task(
  //     id: DateTime.now().millisecondsSinceEpoch.toString(),
  //     title: titleController.text.trim(),
  //     description: descriptionController.text.trim(),
  //     // dueDate: DateTime.now().add(const Duration(minutes: 1)),
  //     dueDate:
  //         _reminderDateTime ?? DateTime.now().add(const Duration(hours: 1)),
  //     priority: _selectedPriority,
  //     isCompleted: false,
  //     category: _selectedCategory,
  //     userId: user?.uid ?? 'offline_user', // Default user ID for offline
  //     reminderDateTime: _reminderDateTime,
  //     updatedAt: DateTime.now(),
  //   );
  //   scheduleNotification(newTask, context, _reminderDateTime);
  //   try {
  //     Navigator.pop(context);
  //     if (user != null) {
  //       await widget.taskService.addTask(newTask);
  //       await widget.taskService.syncTasks();
  //     }

  //     await widget.taskHiveService.addTask(newTask);
  //   } catch (error) {
  //     final box = await Hive.box<Task>('tasks');
  //     box.put(newTask.id, newTask);
  //   }

  //   if (mounted) {
  //     Navigator.pop(context, true); // Pop back and pass success status
  //   }
  // }

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.blueAccent,
        title: const Text(
          'Add Task',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Task Title Field

              buildInputCard(
                controller: titleController,
                label: 'Task Title',
                maxLines: null,
                keyboardType: TextInputType.multiline,
                autoFocus: true,
              ),
              const SizedBox(height: 4),

              // Task Description Field

              buildInputCard(
                controller: descriptionController,
                label: 'Task Discription',
                keyboardType: TextInputType.multiline,
                maxLines: null,
              ),
              const SizedBox(height: 16),

              CustomDropdown(
                items: categories,
                label: 'Category',
                selectedValue: _selectedCategory,
                onChanged: (newValue) {
                  setState(() {
                    _selectedCategory = newValue;
                  });
                },
              ),
              const SizedBox(height: 16),

              CustomDropdown(
                items: priorities,
                label: 'Priority',
                selectedValue: _selectedPriority,
                onChanged: (newValue) {
                  setState(() {
                    _selectedPriority = newValue;
                  });
                },
              ),
              const SizedBox(height: 16),

              ReminderButton(
                reminderDateTime: _reminderDateTime,
                onDateTimeSelected: (dateTime) {
                  setState(() {
                    _reminderDateTime = dateTime;
                  });
                },
              ),
              const SizedBox(height: 20),

              // Save Task Button
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    saveOrEditTask(
                      context: context,
                      isEdit: false,
                      taskService: widget.taskService,
                      taskHiveService: widget.taskHiveService,
                      titleController: titleController,
                      descriptionController: descriptionController,
                      selectedCategory: _selectedCategory,
                      selectedPriority: _selectedPriority,
                      reminderDateTime: _reminderDateTime,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(
                        255, 4, 87, 182), // Button background
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: 16), // Add padding for better UI
                  ),
                  child: const Text(
                    'Save Task',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white, // Text color
                      fontWeight: FontWeight.bold, // Bold text for emphasis
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
