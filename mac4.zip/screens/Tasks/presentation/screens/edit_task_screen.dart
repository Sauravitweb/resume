import 'package:flutter/material.dart';
import 'package:organize/constants/task_constants.dart';
import 'package:organize/screens/Tasks/data/hive/task_hive_service.dart';
import 'package:organize/shared/widgets/build_text_field.dart';
import 'package:organize/shared/widgets/category_dropdown.dart';
import 'package:organize/shared/widgets/reminder_button.dart';
import 'package:organize/shared/widgets/save_task_utils.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:organize/services/task_service.dart';

class EditTaskScreen extends StatefulWidget {
  final TaskService taskService;
  final Task task;
  final TaskHiveService taskHiveService;

  const EditTaskScreen(
      {required this.taskService,
      required this.task,
      Key? key,
      required this.taskHiveService})
      : super(key: key);

  @override
  _EditTaskScreenState createState() => _EditTaskScreenState();
}

class _EditTaskScreenState extends State<EditTaskScreen> {
  String _selectedCategory = 'Home';
  String _selectedPriority = 'Medium';
  DateTime? _reminderDateTime;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController(text: widget.task.title);
    descriptionController =
        TextEditingController(text: widget.task.description);
    _selectedCategory = widget.task.category;
    _selectedPriority = widget.task.priority;
    _reminderDateTime = widget
        .task.reminderDateTime; // Assuming you have this in your Task model
  }

  Color bordercolor = const Color.fromARGB(255, 58, 56, 70);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Task',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildInputCard(
                controller: titleController,
                label: 'Task Title',
                maxLines: null,
                keyboardType: TextInputType.multiline,
                autoFocus: true,
              ),
              const SizedBox(height: 4),

              // Task Description Field

              buildInputCard(
                controller: descriptionController,
                label: 'Task Discription',
                keyboardType: TextInputType.multiline,
                maxLines: null,
              ),

              const SizedBox(
                height: 16,
              ),

              CustomDropdown(
                items: categories,
                label: 'Category',
                selectedValue: _selectedCategory,
                onChanged: (newValue) {
                  setState(() {
                    _selectedCategory = newValue;
                  });
                },
              ),
              const SizedBox(height: 16),
              CustomDropdown(
                items: priorities,
                label: 'Priority',
                selectedValue: _selectedPriority,
                onChanged: (newValue) {
                  setState(() {
                    _selectedPriority = newValue;
                  });
                },
              ),
              const SizedBox(height: 16),

          
              ReminderButton(
                reminderDateTime: _reminderDateTime,
                onDateTimeSelected: (dateTime) {
                  setState(() {
                    _reminderDateTime = dateTime;
                  });
                },
              ),
              const SizedBox(height: 20),

              // Save Changes Button
              Center(
                child: ElevatedButton(
                  onPressed: () async
          
                      {
                    await saveOrEditTask(
                      context: context,
                      isEdit: true,
                      taskService: widget.taskService,
                      taskHiveService: widget.taskHiveService,
                      titleController: titleController,
                      descriptionController: descriptionController,
                      selectedCategory: _selectedCategory,
                      selectedPriority: _selectedPriority,
                      reminderDateTime: _reminderDateTime,
                      existingTask: widget.task,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(
                        255, 4, 87, 182), // Button background
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(
                        vertical: 12, horizontal: 16), // Added padding
                  ),
                  child: const Text(
                    'Save Changes',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white, // Text color
                      fontWeight: FontWeight.bold, // Bold text
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
