import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:organize/services/settings_service.dart';
import 'package:organize/services/task_service.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';

class RecycleBinScreen extends StatefulWidget {
  const RecycleBinScreen({super.key});

  @override
  _RecycleBinScreenState createState() => _RecycleBinScreenState();
}

class _RecycleBinScreenState extends State<RecycleBinScreen> {
  final TaskService _taskService = TaskService();
  String? _userId;

  @override
  void initState() {
    super.initState();
    _fetchSettings();
    _getUserId();
  }

  final SettingsService settingsService = SettingsService();
  bool _isLoading = true;

  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
        _isLoading = false; // Stop loading
      });
    } catch (error) {
      // print("Error fetching settings: $error");
      setState(() {
        _isLoading = false; // Stop loading even on error
      });
    }
  }

  bool _darkMode = false;

  // Fetch user ID
  Future<void> _getUserId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        _userId = user.uid;
      });
    }
  }

  Color _getPriorityColor(String? priority) {
    switch (priority) {
      case 'High':
        return Colors.redAccent;
      case 'Medium':
        return Colors.orangeAccent;
      case 'Low':
        return Colors.greenAccent;
      default:
        return Colors.blueGrey;
    }
  }

  Widget _buildRecycleBinTaskTile(Task task) {
    return Card(
      // duration: const Duration(milliseconds: 200),
      // curve: Curves.easeInOut,

      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),

      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),

      color: Theme.of(context).cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        // onTap: () => _navigateToTaskDetails(task), // Adjust as needed
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Priority Indicator
              Container(
                width: 10,
                height: 40,
                decoration: BoxDecoration(
                  color: _getPriorityColor(task.priority),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              const SizedBox(width: 15),
              // Task Details Section
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.title,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                    ),
                    Text(
                      task.description,
                      style: Theme.of(context)
                          .listTileTheme
                          .subtitleTextStyle
                          ?.copyWith(
                            fontWeight: FontWeight.w800,
                            fontSize: 12,

                            // color: Color.fromARGB(221, 255, 255, 255),
                          ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'Due: ${task.dueDate.toLocal().toString().split(' ')[0] ?? "Unknown"}',
                      style: Theme.of(context)
                          .listTileTheme
                          .subtitleTextStyle
                          ?.copyWith(
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                          ),
                    ),
                  ],
                ),
              ),
              // Buttons for Actions
              Row(
                children: [
                  // Restore Task Icon
                  IconButton(
                    icon: const Icon(Icons.restore,
                        color: Colors.green, size: 25),
                    onPressed: () async {
                      await _taskService.restoreTask(task.id);
                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   const SnackBar(content: Text('Task restored')),
                      // );
                    },
                  ),
                  const SizedBox(height: 3),
                  // Permanently Delete Task Icon
                  IconButton(
                    icon: const Icon(Icons.delete_forever,
                        color: Colors.redAccent, size: 27),
                    onPressed: () async {
                      bool? shouldDelete = await showDialog<bool>(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: const Text('Confirm Deletion'),
                            content: const Text(
                                'Are you sure you want to permanently delete this task?',
                                style: TextStyle(color: Colors.black87)),
                            actions: <Widget>[
                              TextButton(
                                onPressed: () =>
                                    Navigator.of(context).pop(false),
                                child: const Text('Cancel',
                                    style: TextStyle(color: Colors.black)),
                              ),
                              TextButton(
                                onPressed: () =>
                                    Navigator.of(context).pop(true),
                                child: const Text('Delete',
                                    style: TextStyle(color: Colors.redAccent)),
                              ),
                            ],
                          );
                        },
                      );
                      if (shouldDelete == true) {
                        await _taskService.deletedTask(task.id);
                        // ScaffoldMessenger.of(context).showSnackBar(
                        //   const SnackBar(
                        //       content: Text('Task permanently deleted')),
                        // );
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // backgroundColor: Colors.blueAccent,
        title: const Text(
          'Recycle Bin',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent))
          : _userId == null
              ? const Center(
                  child: CircularProgressIndicator(color: Colors.blueAccent))
              : StreamBuilder<List<Task>>(
                  stream: _taskService.recyclegetUserTasks(_userId!,
                      showDeleted: true),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(
                          child: CircularProgressIndicator(
                              color: Colors.blueAccent));
                    }
                    if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return const Center(
                        child: Text(
                          'No deleted tasks',
                          style: TextStyle(fontSize: 16),
                        ),
                      );
                    }

                    List<Task> deletedTasks = snapshot.data!;

                    return ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      itemCount: deletedTasks.length,
                      itemBuilder: (context, index) {
                        return _buildRecycleBinTaskTile(deletedTasks[index]);
                      },
                    );
                  },
                ),
    );
  }
}
