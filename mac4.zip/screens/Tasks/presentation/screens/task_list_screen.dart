import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:organize/constants/task_constants.dart';
import 'package:organize/screens/Tasks/providers/task_provider.dart';
import 'package:organize/services/notification_service.dart';
import 'package:organize/services/settings_service.dart';
import 'package:startapp_sdk/startapp.dart';
import 'package:provider/provider.dart';
// import 'package:share_plus/share_plus.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:organize/services/task_service.dart';

import 'edit_task_screen.dart';
import 'add_task_screen.dart';
import 'recyclebin_screen.dart'; // Assuming a separate screen for the recycle bin
import 'package:permission_handler/permission_handler.dart';
import 'package:organize/screens/Tasks/data/hive/task_hive_service.dart';

class TaskListScreen extends StatefulWidget {
  const TaskListScreen({super.key});

  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  final TaskService _taskService = TaskService();
  final TaskHiveService _taskHiveService = TaskHiveService();
  // final AIService _aiService = AIService();
  String _selectedPriority = 'All';
  String? _userId;
  bool _showCompletedTasks = false;

  String _selectedCategory = 'All';
  late NotificationService _notificationService;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      print("Failed to load banner: $error");
    });
    _fetchSettings();
    _getUserId();
    _notificationService = NotificationService();
    _notificationService.requestPermission();
    requestExactAlarmPermission();
  }

  //  bool _isLoading = true;
  final settingsService = SettingsService();
  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
      });
    } catch (error) {}
  }

  bool _darkMode = false;
  @override
  void dispose() {
    super.dispose();
  }

  Future<void> requestExactAlarmPermission() async {
    if (await Permission.scheduleExactAlarm.isDenied) {
      await Permission.scheduleExactAlarm.request();
    }
  }

  Future<void> _getUserId() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        _userId = user.uid;
      });
    }
  }

  Widget _buildCombinedTabsBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      height: 120, // Height = sum of both bars
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildPriorityTabs(),
          const SizedBox(height: 10),
          Flexible(child: _buildCategoryBox()),
          const SizedBox(height: 5),
        ],
      ),
    );
  }

  Widget _buildPriorityTabs() {
    final taskProvider = Provider.of<TaskProvider>(context);
    final List<String> priorities = [
      'All',
      'High',
      'Medium',
      'Low',
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: priorities.map((priority) {
        final isSelected =
            _selectedPriority == priority; // Check if the tab is selected
        return ElevatedButton(
          style: ElevatedButton.styleFrom(
            foregroundColor: isSelected
                ? (_darkMode
                    ? Colors.white
                    : Colors.white) // Adjust based on dark mode
                : (_darkMode
                    ? Colors.white
                    : Colors.black), // Adjust based on dark mode
            // White text when selected
            backgroundColor: isSelected
                ? getPriorityColor(priority)
                : _darkMode
                    ? const Color.fromARGB(255, 0, 0, 0)
                    : Colors.white, // Dynamic background
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50),
            ),
            elevation: isSelected ? 4 : 1,
            // padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          ),
          onPressed: () {
            taskProvider.setPriorityFilter(priority);
            _selectedPriority = taskProvider.selectedPriority;
          },
          child: Text(priority),
        );
      }).toList(),
    );
  }

  Widget _buildCategoryBox() {
    final taskProvider = Provider.of<TaskProvider>(context);
    final List<String> categories = [
      'All',
      'Home',
      'Work',
      'Personal',
      'Shopping',
      'Office',
      'School',
      'College',
      'Others'
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: categories.map((category) {
          final isSelected =
              _selectedCategory == category; // Use the selected state
          return Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 4.0), // Add spacing between buttons
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                foregroundColor: isSelected
                    ? (_darkMode
                        ? Colors.white
                        : Colors.white) // Adjust based on dark mode
                    : (_darkMode ? Colors.white : Colors.black),
                backgroundColor: isSelected
                    ? const Color.fromARGB(150, 0, 187, 212)
                    : _darkMode
                        ? const Color.fromARGB(255, 0, 0, 0)
                        : Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                elevation: isSelected ? 4 : 1,
              ),
              onPressed: () {
                taskProvider.setCategoryFilter(category);
                _selectedCategory = taskProvider.selectedCategory;
              },
              child: Text(category),
            ),
          );
        }).toList(),
      ),
    );
  }

  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     appBar: AppBar(
  //       title: const Text('Tasks',
  //           style: TextStyle(
  //             fontSize: 22,
  //             fontWeight: FontWeight.bold,
  //           )),

  //       // backgroundColor: _darkMode ? Colors.black : Colors.blueAccent,
  //       actions: [
  //         IconButton(
  //           icon: Icon(
  //             _showCompletedTasks
  //                 ? Icons.check_box
  //                 : Icons.check_box_outline_blank,
  //           ),
  //           onPressed: () {
  //             setState(() {
  //               _showCompletedTasks = !_showCompletedTasks;
  //             });
  //           },
  //         ),
  //         IconButton(
  //           icon: const Icon(
  //             Icons.delete,
  //           ),
  //           onPressed: () {
  //             Navigator.push(
  //               context,
  //               MaterialPageRoute(
  //                 builder: (context) => const RecycleBinScreen(),
  //               ),
  //             );
  //           },
  //         ),
  //       ],
  //     ),
  //     body: _userId == null
  //         ? const Center(
  //             child: CircularProgressIndicator(color: Colors.blueAccent))
  //         : SafeArea(
  //             child: Column(
  //               children: [
  //                 // const Divider(thickness: 0.1),
  //                 _buildPriorityTabs(),
  //                 const SizedBox(
  //                     height:
  //                         1), // Spacing between priority tabs and category box
  //                 _buildCategoryBox(), // Add category box below priority tabs
  //                 Expanded(
  //                   child: StreamBuilder<List<Task>>(
  //                     stream: _taskService.getUserTasks(
  //                       _userId!,
  //                       showCompleted: _showCompletedTasks,
  //                     ),
  //                     builder: (context, snapshot) {
  //                       if (snapshot.connectionState ==
  //                           ConnectionState.waiting) {
  //                         return const Center(
  //                             child: CircularProgressIndicator(
  //                                 color: Colors.blueAccent));
  //                       }
  //                       if (!snapshot.hasData || snapshot.data!.isEmpty) {
  //                         return const Center(
  //                             child: Text('No tasks available'));
  //                       }

  //                       List<Task> tasks = snapshot.data!;

  //                       // Apply category and priority filters
  //                       if (_selectedCategory != 'All') {
  //                         tasks = tasks
  //                             .where(
  //                                 (task) => task.category == _selectedCategory)
  //                             .toList();
  //                       }
  //                       if (_selectedPriority != 'All') {
  //                         tasks = tasks
  //                             .where(
  //                                 (task) => task.priority == _selectedPriority)
  //                             .toList();
  //                       }

  //                       final groupedTasks = _groupTasksByDate(tasks);

  //                       return ListView.builder(
  //                         itemCount: groupedTasks.length,
  //                         itemBuilder: (context, index) {
  //                           final date = groupedTasks.keys.elementAt(index);
  //                           final tasksByDate = groupedTasks[date]!;

  //                           return Column(
  //                             crossAxisAlignment: CrossAxisAlignment.start,
  //                             children: [
  //                               Padding(
  //                                 padding: const EdgeInsets.all(8.0),
  //                                 child: Text(
  //                                   date,
  //                                   style: const TextStyle(
  //                                     fontSize: 16,
  //                                     fontWeight: FontWeight.bold,
  //                                   ),
  //                                 ),
  //                               ),
  //                               ...tasksByDate
  //                                   .map((task) => _buildTaskTile(task))
  //                                   .toList(),
  //                             ],
  //                           );
  //                         },
  //                       );
  //                     },
  //                   ),
  //                 ),
  //                 bannerAd != null
  //                     ? Padding(
  //                         padding: const EdgeInsets.all(12),
  //                         child: ClipRRect(
  //                           borderRadius: BorderRadius.circular(5),
  //                           child: AnimatedContainer(
  //                             duration: Duration(milliseconds: 300),
  //                             curve: Curves.easeInOut,
  //                             decoration: BoxDecoration(
  //                               borderRadius: BorderRadius.circular(5),
  //                               boxShadow: [
  //                                 BoxShadow(
  //                                   color: Colors.purple.withOpacity(0.1),
  //                                   blurRadius: 10,
  //                                 ),
  //                               ],
  //                             ),
  //                             child: StartAppBanner(bannerAd!),
  //                           ),
  //                         ),
  //                       )
  //                     : const SizedBox.shrink(),
  //               ],
  //             ),
  //           ),
  //     floatingActionButton: Padding(
  //       padding:
  //           const EdgeInsets.only(bottom: 60), // Adjust this value as needed
  //       child: FloatingActionButton(
  //         onPressed: _navigateToAddTaskScreen,
  //         backgroundColor: Colors.blueAccent,
  //         tooltip: 'Add Event',
  //         child: const Icon(Icons.add),
  //       ),
  //     ),
  //     // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
  //   );
  // }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _userId == null
          ? const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent))
          : SafeArea(
              child: StreamBuilder<List<Task>>(
                stream: _taskService.getUserTasks(
                  _userId!,
                  showCompleted: _showCompletedTasks,
                ),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                        child: CircularProgressIndicator(
                            color: Colors.blueAccent));
                  }

                  if (!snapshot.hasData || snapshot.data!.isEmpty) {
                    return const Center(child: Text('No tasks available'));
                  }

                  List<Task> tasks = snapshot.data!;

                  if (_selectedCategory != 'All') {
                    tasks = tasks
                        .where((task) => task.category == _selectedCategory)
                        .toList();
                  }

                  if (_selectedPriority != 'All') {
                    tasks = tasks
                        .where((task) => task.priority == _selectedPriority)
                        .toList();
                  }

                  final groupedTasks = _groupTasksByDate(tasks);
                  final sliverItems = <Widget>[];

                  // Add priority tabs and category box at the top
                  // sliverItems.addAll([
                  //   _buildPriorityTabs(),
                  //   const SizedBox(height: 1),
                  //   _buildCategoryBox(),
                  // ]);

                  // Add grouped tasks by date
                  groupedTasks.forEach((date, tasksByDate) {
                    sliverItems.add(
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          date,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    );
                    sliverItems.addAll(
                      tasksByDate.map((task) => _buildTaskTile(task)).toList(),
                    );
                  });

                  // Add ad banner at bottom (optional)
                  if (bannerAd != null) {
                    sliverItems.add(
                      Padding(
                        padding: const EdgeInsets.all(12),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(5),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            curve: Curves.easeInOut,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.purple.withOpacity(0.1),
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: StartAppBanner(bannerAd!),
                          ),
                        ),
                      ),
                    );
                  }

                  return CustomScrollView(
                    slivers: [
                      SliverAppBar(
                        pinned: true,
                        floating: false,
                        scrolledUnderElevation: 0,
                        shadowColor: Colors.white,
                        snap: false,
                        title: const Text(
                          'Tasks',
                          style: TextStyle(
                              fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        actions: [
                          IconButton(
                            icon: Icon(
                              _showCompletedTasks
                                  ? Icons.check_box
                                  : Icons.check_box_outline_blank,
                            ),
                            onPressed: () {
                              setState(() {
                                _showCompletedTasks = !_showCompletedTasks;
                              });
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const RecycleBinScreen(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      SliverAppBar(
                        automaticallyImplyLeading: false,
                        floating: true,
                        pinned: false,
                        snap: true,
                        scrolledUnderElevation: 0,
                        backgroundColor:
                            Theme.of(context).scaffoldBackgroundColor,
                        elevation: 0,
                        toolbarHeight:
                            120, // Match height of _buildCombinedTabsBar
                        flexibleSpace: _buildCombinedTabsBar(),
                      ),
                      SliverList(
                        delegate: SliverChildListDelegate(sliverItems),
                      ),
                    ],
                    physics: const BouncingScrollPhysics(),
                  );
                },
              ),
            ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(bottom: 60),
        child: FloatingActionButton(
          onPressed: _navigateToAddTaskScreen,
          backgroundColor: Colors.blueAccent,
          tooltip: 'Add Task',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
  // @override
  // Widget build(BuildContext context) {
  //   return Scaffold(
  //     appBar: AppBar(
  //       title: const Text('Tasks',
  //           style: TextStyle(
  //             fontSize: 22,
  //             fontWeight: FontWeight.bold,
  //           )),

  //       // backgroundColor: _darkMode ? Colors.black : Colors.blueAccent,
  //       actions: [
  //         IconButton(
  //           icon: Icon(
  //             _showCompletedTasks
  //                 ? Icons.check_box
  //                 : Icons.check_box_outline_blank,
  //           ),
  //           onPressed: () {
  //             setState(() {
  //               _showCompletedTasks = !_showCompletedTasks;
  //             });
  //           },
  //         ),

  //         IconButton(
  //           icon: const Icon(
  //             Icons.delete,
  //           ),
  //           onPressed: () {
  //             Navigator.push(
  //               context,
  //               MaterialPageRoute(
  //                 builder: (context) => const RecycleBinScreen(),
  //               ),
  //             );
  //           },
  //         ),
  //       ],
  //     ),
  //     body:

  //         _userId == null
  //             ? const Center(
  //                 child: CircularProgressIndicator(color: Colors.blueAccent))
  //             : SafeArea(
  //                 child: Column(
  //                   children: [
  //                     // const Divider(thickness: 0.1),
  //                     _buildPriorityTabs(),
  //                     const SizedBox(
  //                         height:
  //                             1), // Spacing between priority tabs and category box
  //                     _buildCategoryBox(), // Add category box below priority tabs
  //                     Expanded(
  //                       child: StreamBuilder<List<Task>>(
  //                         stream: _taskService.getUserTasks(
  //                           _userId!,
  //                           showCompleted: _showCompletedTasks,
  //                         ),
  //                         builder: (context, snapshot) {
  //                           if (snapshot.connectionState ==
  //                               ConnectionState.waiting) {
  //                             return const Center(
  //                                 child: CircularProgressIndicator(
  //                                     color: Colors.blueAccent));
  //                           }
  //                           if (!snapshot.hasData || snapshot.data!.isEmpty) {
  //                             return const Center(
  //                                 child: Text('No tasks available'));
  //                           }

  //                           List<Task> tasks = snapshot.data!;

  //                           // Apply category and priority filters
  //                           if (_selectedCategory != 'All') {
  //                             tasks = tasks
  //                                 .where((task) =>
  //                                     task.category == _selectedCategory)
  //                                 .toList();
  //                           }
  //                           if (_selectedPriority != 'All') {
  //                             tasks = tasks
  //                                 .where((task) =>
  //                                     task.priority == _selectedPriority)
  //                                 .toList();
  //                           }

  //                           final groupedTasks = _groupTasksByDate(tasks);

  //                           return ListView.builder(
  //                             itemCount: groupedTasks.length,
  //                             itemBuilder: (context, index) {
  //                               final date = groupedTasks.keys.elementAt(index);
  //                               final tasksByDate = groupedTasks[date]!;

  //                               return Column(
  //                                 crossAxisAlignment: CrossAxisAlignment.start,
  //                                 children: [
  //                                   Padding(
  //                                     padding: const EdgeInsets.all(8.0),
  //                                     child: Text(
  //                                       date,
  //                                       style: const TextStyle(
  //                                         fontSize: 16,
  //                                         fontWeight: FontWeight.bold,
  //                                       ),
  //                                     ),
  //                                   ),
  //                                   ...tasksByDate
  //                                       .map((task) => _buildTaskTile(task))
  //                                       .toList(),
  //                                 ],
  //                               );
  //                             },
  //                           );
  //                         },
  //                       ),
  //                     ),
  //                     bannerAd != null
  //                         ? Padding(
  //                             padding: const EdgeInsets.all(12),
  //                             child: ClipRRect(
  //                               borderRadius: BorderRadius.circular(5),
  //                               child: AnimatedContainer(
  //                                 duration: Duration(milliseconds: 300),
  //                                 curve: Curves.easeInOut,
  //                                 decoration: BoxDecoration(
  //                                   borderRadius: BorderRadius.circular(5),
  //                                   boxShadow: [
  //                                     BoxShadow(
  //                                       color: Colors.purple.withOpacity(0.1),
  //                                       blurRadius: 10,
  //                                     ),
  //                                   ],
  //                                 ),
  //                                 child: StartAppBanner(bannerAd!),
  //                               ),
  //                             ),
  //                           )
  //                         : const SizedBox.shrink(),
  //                   ],
  //                 ),
  //               ),
  //     floatingActionButton: Padding(
  //       padding:
  //           const EdgeInsets.only(bottom: 60), // Adjust this value as needed
  //       child: FloatingActionButton(
  //         onPressed: _navigateToAddTaskScreen,
  //         backgroundColor: Colors.blueAccent,
  //         tooltip: 'Add Event',
  //         child: const Icon(Icons.add),
  //       ),
  //     ),
  //     // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
  //   );
  // }

  String truncateText(String text, int maxLines) {
    final lines = text.split('\n');
    final truncatedLines = lines.take(maxLines).toList();
    final joinedText = truncatedLines.join(' ');

    // If the text had more lines than allowed, add ellipsis
    return lines.length > maxLines ? '$joinedText...' : joinedText;
  }

  Widget _buildTaskTile(Task task) {
    return Card(
      // duration: const Duration(milliseconds: 200),
      // curve: Curves.easeInOut,
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      color: Theme.of(context).cardColor,
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () => _navigateToEditTaskScreen(task),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Priority Indicator
              Container(
                width: 10,
                height: 40,
                // width: 8,
                // height: 8,
                decoration: BoxDecoration(
                  color: getPriorityColor(task.priority),
                  borderRadius: BorderRadius.circular(5),
                ),
              ),
              const SizedBox(width: 15),
              // Task Details Section
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      truncateText(task.title, 2),
                      // style: const TextStyle(
                      //   fontWeight: FontWeight.bold,
                      //   fontSize: 16,
                      //   // color: Color.fromARGB(255, 255, 255, 255),

                      // ),

                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                      // maxLines: 2, // Limit title to 2 lines
                      overflow:
                          TextOverflow.ellipsis, // Add "..." for truncation
                    ),
                    Text(
                      truncateText(task.description, 3),
                      style: Theme.of(context)
                          .listTileTheme
                          .subtitleTextStyle
                          ?.copyWith(
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            height: 1.2,

                            // color: Color.fromARGB(221, 255, 255, 255),
                          ),
                      maxLines: 3, // Limit description to 3 lines
                      overflow:
                          TextOverflow.ellipsis, // Add "..." for truncation
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'Due: ${task.dueDate.toLocal().toString().split(' ')[0] ?? "Unknown"}',
                      // style: const TextStyle(
                      //   fontWeight: FontWeight.w400,
                      //   // color: Color.fromARGB(137, 255, 255, 255),
                      //   fontSize: 12,
                      // ),
                      style: Theme.of(context)
                          .listTileTheme
                          .subtitleTextStyle
                          ?.copyWith(
                            fontWeight: FontWeight.w400,
                            fontSize: 12,
                          ),
                    ),
                  ],
                ),
              ),
              // Buttons for Actions
              Row(
                children: [
                  // Complete Task Icon
                  IconButton(
                    icon: Icon(
                      task.isCompleted
                          ? Icons.check_circle
                          : Icons.check_circle_outline,
                      color: task.isCompleted
                          ? (_darkMode
                              ? Colors.green[700] // Darker green for dark mode
                              : Colors.green) // Original green for light mode
                          : (_darkMode
                              ? Colors.grey[700] // Darker grey for dark mode
                              : Colors.grey), // Original grey for light mode

                      size: 25,
                    ),
                    onPressed: () async {
                      await _taskService.markTaskAsCompleted(task.id);
                      // setState(() {});
                    },
                  ),
                  const SizedBox(width: 0.00000000000001),
                  IconButton(
                    icon: Icon(
                      Icons.delete,
                      color: _darkMode
                          ? const Color.fromARGB(188, 255, 82, 82)
                          : const Color.fromARGB(188, 255, 82, 82),
                      size: 27,
                    ),
                    onPressed: () async {
                      await _taskService.deleteTask(task.id);
                      // ScaffoldMessenger.of(context).showSnackBar(
                      //   const SnackBar(
                      //     content: Text('Task removed'),
                      //   ),
                      // );
                      // setState(() {});
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Map<String, List<Task>> _groupTasksByDate(List<Task> tasks) {
    final now = DateTime.now();
    final groupedTasks = <String, List<Task>>{};

    for (var task in tasks) {
      if (task.updatedAt != null) {
        final diff = now.difference(task.updatedAt!).inDays;
        String key;

        if (diff == 0) {
          key = 'Today';
        } else if (diff == 1) {
          key = 'Yesterday';
        } else if (diff <= 7) {
          key = 'This Week';
        } else if (diff <= 30) {
          key = 'This Month';
        } else {
          key = 'Earlier';
        }

        groupedTasks.putIfAbsent(key, () => []).add(task);
      }
    }

    // Sort tasks within each group by `updatedAt` in descending order (newest first)
    groupedTasks.forEach((key, taskList) {
      taskList.sort((a, b) => b.updatedAt!.compareTo(a.updatedAt!));
    });

    // Sort the keys to ensure "Today" appears first
    final sortedKeys = [
      'Today',
      'Yesterday',
      'This Week',
      'This Month',
      'Earlier'
    ];
    final sortedGroupedTasks = <String, List<Task>>{};

    for (var key in sortedKeys) {
      if (groupedTasks.containsKey(key)) {
        sortedGroupedTasks[key] = groupedTasks[key]!;
      }
    }

    return sortedGroupedTasks;
  }

  void _navigateToAddTaskScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddTaskScreen(
          taskService: _taskService,
          taskHiveService: _taskHiveService,
        ),
      ),
    );
  }

  void _navigateToEditTaskScreen(Task task) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditTaskScreen(
          taskService: _taskService,
          task: task,
          taskHiveService: _taskHiveService,
        ),
      ),
    );
  }
}
