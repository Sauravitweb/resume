// import 'package:flutter/material.dart';

// Widget _buildCombinedTabsBar() {
//   return Container(
//     padding: const EdgeInsets.symmetric(horizontal: 8),
//     height: 120, // Height = sum of both bars
//     child: Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         _buildPriorityTabs(),
//         const SizedBox(height: 10),
//         Flexible(child: _buildCategoryBox()),
//         const SizedBox(height: 5),
//       ],
//     ),
//   );
// }

// final _selectedPriority = 'All';
// final _selectedCategory = 'All';
// Widget _buildPriorityTabs() {
//   final List<String> priorities = [
//     'All',
//     'High',
//     'Medium',
//     'Low',
//   ];

//   return Row(
//     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//     children: priorities.map((priority) {
//       final isSelected =
//           _selectedPriority == priority; // Check if the tab is selected
//       return ElevatedButton(
//         style: ElevatedButton.styleFrom(
//           foregroundColor: isSelected
//               ? (_darkMode
//                   ? Colors.white
//                   : Colors.white) // Adjust based on dark mode
//               : (_darkMode
//                   ? Colors.white
//                   : Colors.black), // Adjust based on dark mode
//           // White text when selected
//           backgroundColor: isSelected
//               ? getPriorityColor(priority)
//               : _darkMode
//                   ? const Color.fromARGB(255, 0, 0, 0)
//                   : Colors.white, // Dynamic background
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(50),
//           ),
//           elevation: isSelected ? 4 : 1,
//           // padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
//         ),
//         onPressed: () {
//           setState(() {
//             _selectedPriority = priority; // Update selected state
//           });
//         },
//         child: Text(priority),
//       );
//     }).toList(),
//   );
// }

// Widget _buildCategoryBox() {
//   final List<String> categories = [
//     'All',
//     'Home',
//     'Work',
//     'Personal',
//     'Shopping',
//     'Office',
//     'School',
//     'College',
//     'Others'
//   ];
//   return SingleChildScrollView(
//     scrollDirection: Axis.horizontal,
//     child: Row(
//       children: categories.map((category) {
//         final isSelected =
//             _selectedCategory == category; // Use the selected state
//         return Padding(
//           padding: const EdgeInsets.symmetric(
//               horizontal: 4.0), // Add spacing between buttons
//           child: ElevatedButton(
//             style: ElevatedButton.styleFrom(
//               foregroundColor: isSelected
//                   ? (_darkMode
//                       ? Colors.white
//                       : Colors.white) // Adjust based on dark mode
//                   : (_darkMode ? Colors.white : Colors.black),
//               backgroundColor: isSelected
//                   ? const Color.fromARGB(150, 0, 187, 212)
//                   : _darkMode
//                       ? const Color.fromARGB(255, 0, 0, 0)
//                       : Colors.white,
//               shape: RoundedRectangleBorder(
//                 borderRadius: BorderRadius.circular(20),
//               ),
//               elevation: isSelected ? 4 : 1,
//             ),
//             onPressed: () {
//               setState(() {
//                 _selectedCategory = category;
//               });
//             },
//             child: Text(category),
//           ),
//         );
//       }).toList(),
//     ),
//   );
// }
