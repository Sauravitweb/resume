import 'package:flutter/material.dart';

class TaskProvider with ChangeNotifier {
  String _selectedCategory = 'All';
  String _selectedPriority = 'All';

  String get selectedCategory => _selectedCategory;
  String get selectedPriority => _selectedPriority;

  void setCategoryFilter(String Category) {
    _selectedCategory = Category;
    notifyListeners();
  }

  void setPriorityFilter(String Priority) {
    _selectedPriority = Priority;
    notifyListeners();
  }
}
