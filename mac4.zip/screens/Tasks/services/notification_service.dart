import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:timezone/timezone.dart' as tz;

final FlutterLocalNotificationsPlugin _localNotifications =
      FlutterLocalNotificationsPlugin();
  Future<void> scheduleNotification(Task task, BuildContext context,DateTime? reminderDateTime,) async {
    if (reminderDateTime != null) {
      final tzDateTime = tz.TZDateTime.from(reminderDateTime, tz.local,);

      final now = tz.TZDateTime.now(tz.local);

      if (tzDateTime.isBefore(now)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Reminder must be set to a future date',),
          ),
        );
        return;
      }

      try {
        const AndroidNotificationDetails androidDetails =
            AndroidNotificationDetails(
          'task_reminder', // Channel ID
          'Task Reminder', // Channel Name
          importance: Importance.max,
          priority: Priority.high,
          playSound: true, // This will play the sound when notification shows
        );

        const NotificationDetails notificationDetails = NotificationDetails(
          android: androidDetails,
        );

        await _localNotifications.zonedSchedule(
          task.id.hashCode, // Unique notification ID
          'Task Reminder: ${task.title}',
          'Reminder set for ${reminderDateTime.toLocal()} (Due on ${task.dueDate.toLocal()})',

          tzDateTime, // Scheduled time
          notificationDetails,

          androidScheduleMode: AndroidScheduleMode
              .exactAllowWhileIdle, // Ensure notification shows even in idle mode
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      } catch (e) {
        // print('Error scheduling or showing notification: $e');
      }
    }
  }
