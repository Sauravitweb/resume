import 'package:hive/hive.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';

class TaskHiveService {
  final Box<Task> _taskBox = Hive.box<Task>('tasks');

  // Add a new task
  Future<void> addTask(Task task) async {
    await _taskBox.put(task.id, task); // use put for custom keys
  }

  // Get all tasks
  List<Task> getAllTasks() {
    return _taskBox.values.toList();
  }

  // Get a specific task
  Task? getTask(String id) {
    return _taskBox.get(id);
  }

  // Update a task
  Future<void> updateTask(Task task) async {
    await _taskBox.put(task.id, task);
  }

  // Delete a task
  Future<void> deleteTask(String id) async {
    await _taskBox.delete(id);
  }

  // Clear all tasks
  Future<void> clearTasks() async {
    await _taskBox.clear();
  }
}
