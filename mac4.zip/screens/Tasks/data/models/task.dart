import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore package
import 'package:hive/hive.dart'; // Import Hive package

part 'task.g.dart'; // For Hive TypeAdapter (auto-generated)

@HiveType(typeId: 0) // Unique type ID for Hive
class Task extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String description;

  @HiveField(3)
  DateTime dueDate;

  @HiveField(4)
  String priority; // Priority can be "High", "Medium", "Low"

  @HiveField(5)
  bool isCompleted;

  @HiveField(6)
  bool isDeleted;

  @HiveField(7)
  String category;

  @HiveField(8)
  String userId; // Field for user ID

  @HiveField(9)
  DateTime? reminderDateTime; // Optional reminder date-time

  @HiveField(10)
  DateTime? updatedAt; // Field to track last updated time

  Task({
    required this.id,
    required this.title,
    this.description = '',
    required this.dueDate,
    this.priority = 'Medium',
    this.isCompleted = false,
    this.isDeleted = false,
    this.category = 'General',
    required this.userId, // User ID is required
    this.reminderDateTime, // Optional field for reminder
    this.updatedAt, // Optional field for last updated time
  });

  Task copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? dueDate,
    String? priority,
    bool? isCompleted,
    bool? isDeleted,
    String? category,
    String? userId,
    DateTime? reminderDateTime,
    DateTime? updatedAt,
  }) {
    return Task(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      dueDate: dueDate ?? this.dueDate,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
      isDeleted: isDeleted ?? this.isDeleted,
      category: category ?? this.category,
      userId: userId ?? this.userId,
      reminderDateTime: reminderDateTime ?? this.reminderDateTime,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  // Convert Task to Firestore-compatible Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'dueDate': Timestamp.fromDate(dueDate),
      'priority': priority,
      'isCompleted': isCompleted,
      'isDeleted': isDeleted,
      'category': category,
      'userId': userId,
      'reminderDateTime': reminderDateTime != null
          ? Timestamp.fromDate(reminderDateTime!)
          : null,
      'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
    };
  }

  /// Update a specific field of the task dynamically.
  void updateField(String key, dynamic value) {
    switch (key) {
      case 'title':
        title = value;
        break;
      case 'description':
        description = value;
        break;
      case 'dueDate':
        dueDate = DateTime.tryParse(value) ?? dueDate;
        break;
      case 'priority':
        priority = value;
        break;
      case 'isCompleted':
        isCompleted = value;
        break;
      case 'isDeleted':
        isDeleted = value;
        break;
      case 'category':
        category = value;
        break;
      case 'reminderDateTime':
        reminderDateTime = value != null ? DateTime.tryParse(value) : null;
        break;
      case 'updatedAt':
        updatedAt = DateTime.tryParse(value) ?? DateTime.now();
        break;
      default:
        throw ArgumentError('Invalid field key: $key');
    }
    save(); // Save changes to the Hive box
  }

  // Convert Firestore Map to Task
  static Task fromMap(Map<String, dynamic> map, String id) {
    return Task(
      id: id,
      title: map['title'],
      description: map['description'] ?? '',
      dueDate: (map['dueDate'] as Timestamp).toDate(),
      priority: map['priority'] ?? 'Medium',
      isCompleted: map['isCompleted'] ?? false,
      isDeleted: map['isDeleted'] ?? false,
      category: map['category'] ?? 'General',
      userId: map['userId'],
      reminderDateTime: map['reminderDateTime'] != null
          ? (map['reminderDateTime'] as Timestamp).toDate()
          : null,
      updatedAt: map['updatedAt'] != null
          ? (map['updatedAt'] as Timestamp).toDate()
          : null,
    );
  }

  // Convert Firestore DocumentSnapshot to Task
  static Task fromDocument(DocumentSnapshot doc) {
    return Task.fromMap(doc.data() as Map<String, dynamic>, doc.id);
  }
}
