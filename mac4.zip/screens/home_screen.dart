import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:organize/constants/routes.dart';
//import 'package:google_mobile_ads/google_mobile_ads.dart'; // Import AdMob
import 'package:organize/screens/Social/activity_tracking_screen.dart';
import 'package:organize/screens/Social/social_management_screen.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
// import 'package:device_info_plus/device_info_plus.dart';
import 'package:organize/services/settings_service.dart';
import 'package:organize/utilities/build_navigation_card.dart';
import 'package:startapp_sdk/startapp.dart';
import '../services/task_service.dart';


import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';

class HomeScreen extends StatefulWidget {
  final String userId;

  const HomeScreen({super.key, required this.userId});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TaskService _taskService = TaskService();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final User? currentUser = FirebaseAuth.instance.currentUser;
  // late BannerAd _bannerAd;
  // bool _isAdLoaded = false;

  final startAppSdk = StartAppSdk();
  StartAppBannerAd? bannerAd;
  @override
  void initState() {
    super.initState();
    startAppSdk.loadBannerAd(StartAppBannerType.BANNER).then((bannerAd) {
      setState(() {
        this.bannerAd = bannerAd;
      });
    }).onError<StartAppException>((error, stackTrace) {
      // handle error
      print("Failed to load banner: $error");
    });
    checkForUpdate(context);

    // checkGooglePlayServices();
    // _loadBannerAd();
    _fetchSettings();
  }

  Future<void> checkForUpdate(BuildContext context) async {
    final url = Uri.parse(
      'https://lifemanagerupdate.vercel.app/version.json?v=${DateTime.now().millisecondsSinceEpoch}',
    );

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final latestVersion = data['version'];
        final downloadUrl = data['url'];

        final packageInfo = await PackageInfo.fromPlatform();
        final currentVersion = packageInfo.version;

        if (latestVersion != currentVersion) {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              title: Text(
                '🎉 Yay! Update Found!',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              content: Text(
                'A shiny new version ($latestVersion) is ready to make your life even better ✨\n\nYou’re currently using version $currentVersion.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(),
                  child: Text(
                    'Not now 😌',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w500),
                  ),
                ),
                ElevatedButton.icon(
                  onPressed: () async {
                    Navigator.of(ctx).pop();
                    final uri = Uri.parse(downloadUrl);
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri,
                          mode: LaunchMode.externalApplication);
                    }
                  },
                  icon: Icon(
                    Icons.download_rounded,
                    color: Colors.blueAccent,
                  ),
                  label: Text('Update now 🚀'),
                ),
              ],
            ),
          );
        } else {
          debugPrint('💡 You’re already using the latest version!');
        }
      } else {
        debugPrint('⚠️ Failed to check for update. Server error.');
      }
    } catch (e) {
      debugPrint('🐞 Oops! Something went wrong: $e');
    }
  }

  final settingsService = SettingsService();
  final userId = FirebaseAuth.instance.currentUser?.uid;
  Future<void> _fetchSettings() async {
    try {
      final settings = await settingsService.getSettings(userId!);
      setState(() {
        _darkMode = settings.darkMode;
      });
    } catch (error) {
      // print("Error fetching settings: $error");
    }
  }

  bool _darkMode = false;

  @override
  void dispose() {
    //  _bannerAd.dispose(); //this
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.only(
              left: 10.0, right: 0, top: 0, bottom: 0), // Adjust for spacing

          child: SizedBox(
            width: 65, // Increased width
            height: 65, // Increased height
            child: FutureBuilder<DocumentSnapshot>(
              future:
                  _firestore.collection('users').doc(currentUser!.uid).get(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const CircleAvatar(
                    radius: 32, // Bigger loading icon
                    child: CircularProgressIndicator(color: Colors.blueAccent),
                  );
                }
                if (snapshot.hasError || !snapshot.hasData) {
                  return GestureDetector(
                    onTap: () => Navigator.pushNamed(context, profileRoute),
                    child: const CircleAvatar(
                      radius: 32, // Bigger default avatar
                      child:
                          Icon(Icons.person, size: 36), // Larger default icon
                    ),
                  );
                }

                final userData = snapshot.data!.data() as Map<String, dynamic>;
                final profileImageUrl = userData['profileImageUrl'] ?? '';

                return GestureDetector(
                  onTap: () => Navigator.pushNamed(context, profileRoute),
                  child: CircleAvatar(
                    radius: 32, // Bigger profile image
                    backgroundImage: profileImageUrl.isNotEmpty
                        ? CachedNetworkImageProvider(profileImageUrl)
                        : null,
                    child: profileImageUrl.isEmpty
                        ? const Icon(Icons.person,
                            size: 36) // Bigger default icon
                        : null,
                  ),
                );
              },
            ),
          ),
        ),
        title: const Text(
          'Organize',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, settingsRoute),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: SafeArea(
              child: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Column(
                        children: [
                          const SizedBox(height: 5),
                          _buildTaskSummary(),
                          // const SizedBox(height: 20),
                          // NavigationCard(
                          //   title: 'Health',
                          //   subtitle: 'Manage your Health',
                          //   icon: FontAwesomeIcons.heartPulse,
                          //   onTap: () =>
                          //       Navigator.pushNamed(context, '/health'),
                          // ),
                          const SizedBox(height: 20),
                          NavigationCard(
                            title: 'Finance Management',
                            subtitle: 'Manage your expenses and budget',
                            icon: FontAwesomeIcons.wallet,
                            onTap: () => Navigator.pushNamed(
                                context, financeScreenRoute),
                          ),
                          const SizedBox(height: 20),
                          NavigationCard(
                            title: 'Social Events',
                            subtitle: 'Manage upcoming social events',
                            icon: Icons.event,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const SocialManagementScreen(),
                                ),
                              );
                            },
                          ),
                          const SizedBox(height: 20),
                          NavigationCard(
                            title: 'Track Activities',
                            subtitle:
                                'Track social activities and interactions',
                            icon: Icons.trending_up,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      const ActivityTrackingScreen(),
                                ),
                              );
                            },
                          ),
                          const SizedBox(height: 20),
                          NavigationCard(
                            title: 'Chats',
                            subtitle: 'Global and friends',
                            icon: FontAwesomeIcons.commentDots,
                            onTap: () =>
                                Navigator.pushNamed(context, recentChatRoute),
                          ),
                          // if (_bannerAd != null)
                          //   Container(
                          //     color: Colors.transparent,
                          //     width: 200,
                          //     height: 60,
                          //     // width: _bannerAd!.size.width.toDouble(),
                          //     // height: _bannerAd!.size.height.toDouble(),
                          //     child: AdWidget(ad: _bannerAd!),
                          //   ),

                          // WebView displaying the content
                        ],
                      ),
                    ),
                  ),
                  // if (_bannerAd != null)
                  //   Container(
                  //     color: Colors.transparent,
                  //     height: _bannerAd!.size.height.toDouble(),
                  //     child: AdWidget(ad: _bannerAd!),
                  //   ),
                ],
              ),
            ),
          ),
          bannerAd != null
              ? Padding(
                  padding: const EdgeInsets.all(12),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(5),
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.purple.withOpacity(0.1),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: StartAppBanner(bannerAd!),
                    ),
                  ),
                )
              : const SizedBox.shrink(),
        ],
      ),
    );
  }

  Widget _buildTaskSummary() {
    return StreamBuilder<List<Task>>(
      stream: _taskService.gotUserTasks(widget.userId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error loading tasks: ${snapshot.error}'));
        }
        final tasks = snapshot.data ?? [];
        return NavigationCard(
          title: 'Tasks',
          subtitle: 'Total: ${tasks.length}',
          icon: FontAwesomeIcons.tasks,
          onTap: () => Navigator.pushNamed(context, taskRoute),
        );
      },
    );
  }
}
