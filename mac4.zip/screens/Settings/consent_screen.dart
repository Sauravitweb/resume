import 'package:flutter/material.dart';
import 'package:organize/constants/routes.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class ConsentScreen extends StatefulWidget {
  @override
  _ConsentScreenState createState() => _ConsentScreenState();
}

class _ConsentScreenState extends State<ConsentScreen> {
  bool isAgreed = false;

  @override
  void initState() {
    super.initState();
    _checkConsent();
  }

  // Check if consent has already been given
  Future<void> _checkConsent() async {
    final prefs = await SharedPreferences.getInstance();
    bool? consentGiven = prefs.getBool('userConsent');
    if (consentGiven == true) {
      Navigator.pushReplacementNamed(context, homeRoute);
    }
  }

  // Save user consent
  Future<void> _saveConsent() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('userConsent', true);
  }

  // Accept consent and navigate to home screen
  void _acceptConsent() {
    _saveConsent();
    Navigator.pushReplacementNamed(context, homeRoute);
  }

  // Open privacy policy link
  void _launchPrivacyPolicy() async {
    const url =
        'https://sauravkhanal2.com.np/lifemanagerapp-privacy-policy'; // Replace with actual URL
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Could not open privacy policy link.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Terms & Conditions')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          // Allows scrolling if content overflows
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Organize App - Privacy Policy\n\n"
                "Your privacy is important to us. This Privacy Policy explains how we handle your data.\n\n"
                "1. Data Collection\n"
                "   - We collect minimal personal data, such as your name, email, and user preferences.\n"
                "   - Some features may require access to tasks and general usage data.\n"
                "   - We do not sell or share your personal data with third parties for advertising purposes.\n\n"
                "2. Usage of Data\n"
                "   - Your data is used to enhance app functionality, including task management, finance management and social management.\n"
                "   - It helps personalize features and provide insights based on your usage.\n"
                "   - Your information is processed securely and only for necessary purposes.\n\n"
                "3. Third-Party Services\n"
                "   - We use third-party services such as Firebase for cloud storage, authentication, and analytics, and AdMob for displaying ads.\n"
                "   - Firebase helps us store your data securely and provide features like account management and notifications.\n"
                "   - AdMob may collect some anonymous data (e.g., device information, usage data) to serve relevant ads.\n"
                "   - These services are integrated to improve your experience with the app and ensure it runs smoothly.\n\n"
                "4. User Control & Data Management\n"
                "   - You have full control over your data.\n"
                "   - You can request to delete your account or modify personal settings by contacting our support team within the app.\n"
                "   - If you need assistance, you can contact us through our support page.\n\n"
                "5. Security & Protection\n"
                "   - We use encryption, secure authentication, and cloud-based security measures to protect your information.\n"
                "   - Regular security updates are applied to ensure data protection.\n\n"
                "6. Changes to the Privacy Policy\n"
                "   - We may update this Privacy Policy as necessary.\n"
                "   - Users will be notified of significant changes through the app.\n"
                "   - Continued use of the app after updates means acceptance of the revised terms.\n\n",
                style: TextStyle(fontSize: 14),
              ),
              GestureDetector(
                onTap: _launchPrivacyPolicy,
                child: Text(
                  "Read Full Privacy Policy",
                  style: TextStyle(
                      color: Colors.blue, decoration: TextDecoration.underline),
                ),
              ),
              SizedBox(height: 20),
              CheckboxListTile(
                title: Text("I agree to the terms & conditions"),
                value: isAgreed,
                onChanged: (value) {
                  setState(() {
                    isAgreed = value ?? false;
                  });
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: isAgreed ? _acceptConsent : null,
                child: Text("Continue"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
