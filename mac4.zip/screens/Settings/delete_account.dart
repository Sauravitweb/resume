import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:organize/screens/Auth/login_screen.dart';

class DeleteAccountScreen extends StatefulWidget {
  @override
  _DeleteAccountScreenState createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void _confirmDisableForGoogle() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Deactivate Google Account',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          content: Text(
            'Are you sure you want to deactivate your account linked with Google?',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
          ),
          actions: [
            // TextButton(
            //   onPressed: () => Navigator.of(context).pop(),
            //   child: Text('Cancel'),
            // ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              style: TextButton.styleFrom(
                foregroundColor: Colors.black87,
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                overlayColor: Colors.grey.withOpacity(0.2),
              ),
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () async {
                Navigator.of(context).pop();
                await _disableGoogleAccount();
              },
              child: Text('Deactivate', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _disableGoogleAccount() async {
    try {
      User? user = _auth.currentUser;
      if (user == null || user.email == null) {
        _showSnackBar('User not found', Colors.red);
        return;
      }

      // Mark the account as disabled in Firestore
      await _firestore.collection('users').doc(user.uid).update({
        'isDisabled': true,
      });

      await _auth.signOut(); // Sign out from Firebase Auth
      await GoogleSignIn().signOut(); // Sign out from Google

      _showSnackBar(
          'Account is deactivated. You can reactivate it after logging in.',
          Colors.orange);

      if (context.mounted) {
        Future.microtask(() {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false,
          );
        });
      }
    } on FirebaseAuthException catch (e) {
      _showSnackBar(e.message ?? 'Firebase error occurred', Colors.red);
    } catch (e) {
      _showSnackBar('Unexpected error: $e', Colors.red);
    }
  }

// Helper function for SnackBars
  void _showSnackBar(String message, Color color) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message), backgroundColor: color),
      );
    }
  }

  void _confirmDisable() {
    User? user = _auth.currentUser;
    if (user == null) return;

    bool isGoogleUser = false;
    for (UserInfo userInfo in user.providerData) {
      if (userInfo.providerId == 'google.com') {
        isGoogleUser = true;
        break;
      }
    }

    if (isGoogleUser) {
      _confirmDisableForGoogle();
    } else {
      _confirmDisableForEmail();
    }
  }

  void _confirmDisableForEmail() {
    TextEditingController passwordController = TextEditingController();
    bool isLoading = false;
    String? errorMessage;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              title: Text(
                'Deactivate Account',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Enter your password to confirm account deactivation.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                  SizedBox(height: 12),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      labelText: 'Password',
                      labelStyle: TextStyle(color: Colors.black87),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.black, width: 2),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.black, width: 2),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.black, width: 2.5),
                      ),
                    ),
                  ),
                  if (errorMessage != null) ...[
                    SizedBox(height: 8),
                    Text(
                      errorMessage!,
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ],
                ],
              ),
              actions: [
                // TextButton(
                //   onPressed: () => Navigator.of(context).pop(),
                //   child: Text('Cancel'),
                // ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black87,
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    overlayColor: Colors.grey.withOpacity(0.2),
                  ),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: isLoading
                      ? null
                      : () async {
                          setState(() => isLoading = true);
                          String result = await _disableAccountWithPassword(
                              passwordController.text);
                          setState(() {
                            isLoading = false;
                            errorMessage = result.isNotEmpty ? result : null;
                          });

                          if (result.isEmpty) Navigator.of(context).pop();
                        },
                  child: isLoading
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text('Deactivate',
                          style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<String> _disableAccountWithPassword(String password) async {
    User? user = _auth.currentUser;
    if (user == null || user.email == null) return 'User not found';

    try {
      AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: password,
      );
      await user.reauthenticateWithCredential(credential);

      await _firestore.collection('users').doc(user.uid).update({
        'isDisabled': true,
      });

      await _auth.signOut();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Account is deactivated. You can reactivate it after logging in.'),
          backgroundColor: Colors.orange,
        ),
      );
      if (context.mounted) {
        Future.microtask(() {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false,
          );
        });
      }

      return ''; // Success
    } on FirebaseAuthException catch (e) {
      return e.message ?? 'Failed to deactivate account';
    } catch (e) {
      return 'An unexpected error occurred';
    }
  }

  void _confirmDeleteForGoogleUser() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Delete Account',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          content: Text(
            'Your account will be deactivated immediately and permanently deleted after 90 days. If you log in within 90 days, the deletion will be canceled.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              style: TextButton.styleFrom(
                foregroundColor: Colors.black87,
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                overlayColor: Colors.grey.withOpacity(0.2),
              ),
              child: Text(
                'Cancel',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onPressed: () async {
                await _deleteAccountForGoogleUser();
                Navigator.of(context).pop();
              },
              child:
                  Text('Delete Account', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteAccountForGoogleUser() async {
    User? user = _auth.currentUser;
    if (user == null) return;

    try {
      // Get current timestamp
      Timestamp now = Timestamp.now();

      // Update user status in Firestore
      await _firestore.collection('users').doc(user.uid).update({
        'isDisabled': true,
        'toDelete': true,
        'schedule_for_delete': now,
      });

      await _auth.signOut();
      await GoogleSignIn().signOut(); // Sign out from Google

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Account scheduled for deletion. You can cancel deletion by logging in within 90 days.'),
          backgroundColor: Colors.orange,
        ),
      );

      if (context.mounted) {
        Future.microtask(() {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false,
          );
        });
      }
    } catch (e) {
      print('Error deleting Google user: $e');
    }
  }

  void _confirmDelete() {
    TextEditingController passwordController = TextEditingController();
    bool isLoading = false;
    String? errorMessage;

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              title: Text(
                'Delete Account',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Your account will be deactivated immediately and permanently deleted after 90 days. If you log in within 90 days, the deletion will be canceled.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                  ),
                  SizedBox(height: 12),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    style: const TextStyle(color: Colors.black),
                    // decoration: InputDecoration(
                    //   labelText: 'Password',
                    //   labelStyle: const TextStyle(color: Colors.black87),
                    //   border: OutlineInputBorder(
                    //     borderRadius: BorderRadius.circular(12),
                    //   ),
                    // ),
                    decoration: InputDecoration(
                      labelText: 'Password',
                      labelStyle: TextStyle(color: Colors.black87),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                            color: Colors.black, width: 2), // Black border
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                            color: Colors.black, width: 2), // Black border
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                            color: Colors.black,
                            width: 2.5), // Slightly thicker on focus
                      ),
                    ),
                  ),
                  if (errorMessage != null) ...[
                    SizedBox(height: 8),
                    Text(
                      errorMessage!,
                      style: TextStyle(color: Colors.red, fontSize: 12),
                    ),
                  ],
                ],
              ),
              actions: [
                // TextButton(
                //   onPressed: () => Navigator.of(context).pop(),
                //   child: Text('Cancel'),
                // ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.black87, // Text color
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    overlayColor:
                        Colors.grey.withOpacity(0.2), // Subtle hover effect
                  ),
                  child: Text(
                    'Cancel',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5, // Better spacing
                    ),
                  ),
                ),

                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.redAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: isLoading
                      ? null
                      : () async {
                          setState(() => isLoading = true);
                          String result = await _deleteAccount(
                            passwordController.text,
                          );
                          setState(() {
                            isLoading = false;
                            errorMessage = result.isNotEmpty ? result : null;
                          });

                          if (result.isEmpty) Navigator.of(context).pop();
                        },
                  child: isLoading
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text('Delete Account',
                          style: TextStyle(color: Colors.white)),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<String> _deleteAccount(String password) async {
    User? user = _auth.currentUser;
    if (user == null || user.email == null) return 'User not found';

    try {
      // Reauthenticate user before deleting the account
      AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: password,
      );
      await user.reauthenticateWithCredential(credential);

      // Get current timestamp
      Timestamp now = Timestamp.now();

      // Update user status in Firestore
      await _firestore.collection('users').doc(user.uid).update({
        'isDisabled': true,
        'toDelete': true,
        'schedule_for_delete': now,
      });

      await _auth.signOut();

      // Show success message
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Account scheduled for deletion. You can cancel deletion by logging in within 90 days.'),
          backgroundColor: Colors.orange,
        ),
      );

      if (context.mounted) {
        Future.microtask(() {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false,
          );
        });
      }

      return ''; // Success, no error
    } on FirebaseAuthException catch (e) {
      return e.message ?? 'Failed to schedule account deletion';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Manage Account',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        // backgroundColor: Colors.black87,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Deactivate Account Button
            ElevatedButton.icon(
              onPressed: _confirmDisable,
              icon: Icon(Icons.lock_outline, color: Colors.white),
              label: Text(
                'Deactivate My Account',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orangeAccent,
                padding: EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                shadowColor: Colors.orange.withOpacity(0.3),
                elevation: 6,
              ),
            ),
            SizedBox(height: 20),

            ElevatedButton.icon(
              onPressed: () {
                User? user = FirebaseAuth.instance.currentUser;
                bool isGoogleUser = user?.providerData.any(
                      (provider) => provider.providerId == 'google.com',
                    ) ??
                    false;

                if (isGoogleUser) {
                  _confirmDeleteForGoogleUser();
                } else {
                  _confirmDelete();
                }
              },
              icon: Icon(Icons.delete_forever, color: Colors.white),
              label: Text(
                'Delete My Account',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                padding: EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                shadowColor: Colors.red.withOpacity(0.3),
                elevation: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
