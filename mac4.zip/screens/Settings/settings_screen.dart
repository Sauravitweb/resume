import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:organize/screens/Auth/login_screen.dart';
import 'package:organize/services/settings_service.dart';

import 'delete_account.dart';

import 'package:url_launcher/url_launcher.dart';
// import 'package:share_plus/share_plus.dart';

class SettingsScreen extends StatefulWidget {
  final void Function(bool, Color) onThemeChange;
  final String userId;

  const SettingsScreen({
    super.key,
    required this.onThemeChange,
    required this.userId,
  });

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode = false;
  bool _notificationsEnabled = true;
  TimeOfDay? _reminderTime;

  final SettingsService _settingsService = SettingsService();

  @override
  void initState() {
    super.initState();

    // loadServiceAccountFile();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await _settingsService.getSettings(widget.userId);
    setState(() {
      _darkMode = settings.darkMode;
      _notificationsEnabled = settings.notificationsEnabled;
      _reminderTime = settings.reminderTime;
      _themeColor =
          settings.themeColor; // Add this line to load the theme color
    });
  }

  void _updateSettings() {
    _settingsService.updateSettings(
      widget.userId,
      _darkMode,
      _notificationsEnabled,
      language: 'en',
      fontSize: 14.0,
      reminderTime: _reminderTime,
      themeColor: _themeColor, // Pass the updated theme color
    );
    widget.onThemeChange(_darkMode, _themeColor);
  }

  Widget _buildNavigationCard({
    required BuildContext context,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    final theme = Theme.of(context); // Access the current theme

    return GestureDetector(
      onTap: onTap,
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        elevation: 4,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
        ),
        color: theme.cardColor, // Ensures it picks up the theme's card color
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title with bold styling
                    Text(
                      title,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    // Subtitle
                    Text(
                      subtitle,
                      style: theme.textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _themeColor = const Color(0xFF80D0FF); // Default color (Soft Blue)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              _buildNavigationCard(
                context: context,
                title: 'Dark Mode',
                subtitle: _darkMode ? 'Enabled' : 'Disabled',
                onTap: () {
                  setState(() {
                    _darkMode = !_darkMode;
                  });
                  _updateSettings();
                },
              ),
              _buildNavigationCard(
                context: context,
                title: 'Privacy Policy',
                subtitle: 'View our privacy policy',
                onTap: () async {
                  final url =
                      'https://sauravkhanal2.com.np/lifemanagerapp-privacy-policy';
                  if (await canLaunchUrl(Uri.parse(url))) {
                    await launchUrl(Uri.parse(url),
                        mode: LaunchMode.externalApplication);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Could not open privacy policy')),
                    );
                  }
                },
              ),

              _buildNavigationCard(
                context: context,
                title: 'Manage Account',
                subtitle: 'Manage your account',
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            DeleteAccountScreen()), // Now for disabling
                  );
                },
              ),

              const SizedBox(height: 20),

              // Sign Out Button
              ElevatedButton(
                onPressed: _signOut,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  padding:
                      const EdgeInsets.symmetric(vertical: 14, horizontal: 40),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30)),
                  elevation: 5,
                ),
                child: const Text(
                  'Sign Out',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _signOut() async {
    await GoogleSignIn().signOut(); // Sign out from Google

    await FirebaseAuth.instance.signOut();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (route) => false,
    );
  }
}
