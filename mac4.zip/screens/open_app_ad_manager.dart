// import 'package:google_mobile_ads/google_mobile_ads.dart';

// class OpenAppAdManager {
//   static final OpenAppAdManager _instance = OpenAppAdManager._internal();
//   AppOpenAd? _openAppAd;
//   bool _isAdShowing = false;

//   factory OpenAppAdManager() {
//     return _instance;
//   }

//   OpenAppAdManager._internal();

//   /// Load the Open App Ad
//   void loadAd() {
//     AppOpenAd.load(
//       adUnitId:
//           'ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY', // Replace with your actual AdMob Open App Ad Unit ID
//       request: const AdRequest(),
//       adLoadCallback: AppOpenAdLoadCallback(
//         onAdLoaded: (ad) {
//           _openAppAd = ad;
//         },
//         onAdFailedToLoad: (error) {
//           print('Open App Ad failed to load: $error');
//           _openAppAd = null;
//         },
//       ),
//       // Fixed orientation
//     );
//   }

//   /// Show the Open App Ad if it's available
//   void showAdIfAvailable() {
//     if (_openAppAd != null && !_isAdShowing) {
//       _isAdShowing = true;
//       _openAppAd!.fullScreenContentCallback = FullScreenContentCallback(
//         onAdDismissedFullScreenContent: (ad) {
//           _isAdShowing = false;
//           _openAppAd = null;
//           loadAd(); // Preload next ad
//         },
//         onAdFailedToShowFullScreenContent: (ad, error) {
//           _isAdShowing = false;
//           _openAppAd = null;
//           loadAd(); // Preload next ad
//         },
//       );
//       _openAppAd!.show();
//     } else {
//       loadAd(); // Preload if not available
//     }
//   }
// }
//this is something you can use to manage Open App Ads in your Flutter application using Google Mobile Ads SDK.-------------------------------------------------------------------------------
// import 'package:google_mobile_ads/google_mobile_ads.dart';

// class OpenAppAdManager {
//   static final OpenAppAdManager _instance = OpenAppAdManager._internal();
//   AppOpenAd? _openAppAd;
//   bool _isAdShowing = false;

//   factory OpenAppAdManager() {
//     return _instance;
//   }

//   OpenAppAdManager._internal();

//   /// Load the Open App Ad
//   void loadAd() {
//     AppOpenAd.load(
//       adUnitId:
//           'ca-app-pub-9437673525104730/7573922971', // Replace with your actual AdMob Open App Ad Unit ID
//       request: const AdRequest(),
//       adLoadCallback: AppOpenAdLoadCallback(
//         onAdLoaded: (ad) {
//           _openAppAd = ad;
//         },
//         onAdFailedToLoad: (error) {
//           print('Open App Ad failed to load: $error');
//           _openAppAd = null;
//         },
//       ),
//     );
//   }

//   /// Show the Open App Ad if it's available
//   void showAdIfAvailable() {
//     if (_openAppAd != null && !_isAdShowing) {
//       _isAdShowing = true;
//       _openAppAd!.fullScreenContentCallback = FullScreenContentCallback(
//         onAdDismissedFullScreenContent: (ad) {
//           _isAdShowing = false;
//           _openAppAd = null;
//           loadAd(); // Preload next ad
//         },
//         onAdFailedToShowFullScreenContent: (ad, error) {
//           _isAdShowing = false;
//           _openAppAd = null;
//           loadAd(); // Preload next ad
//         },
//       );
//       _openAppAd!.show();
//     } else {
//       loadAd(); // Preload if not available
//     }
//   }
// }
