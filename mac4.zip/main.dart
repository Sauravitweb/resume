import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
//import 'package:jitsi_meet_flutter_sdk/jitsi_meet_flutter_sdk.dart';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:organize/constants/routes.dart';
import 'package:organize/screens/Chats/friend_request_screen.dart';
import 'package:organize/screens/Chats/profile_screen.dart';
import 'package:organize/screens/Settings/consent_screen.dart';
import 'package:organize/screens/Settings/settings_screen.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';
import 'package:organize/screens/Tasks/providers/task_provider.dart';
// import 'package:organize/screens/LiveKitCallScreen.dart';
import 'package:organize/screens/finance/budget_management_screen.dart';
import 'package:organize/screens/finance/expense_tracking_screen.dart';
import 'package:organize/screens/finance/finance_overview_screen.dart';
import 'package:organize/screens/finance/finance_screen.dart';
import 'package:organize/screens/Finance/financial_goals_screen.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:organize/screens/Auth/auth_screen.dart';
import 'package:startapp_sdk/startapp.dart';

import 'package:organize/screens/Chats/recent_chats_screen.dart';
import 'package:organize/screens/Social/social_screen.dart';
import 'package:organize/services/task_service.dart';
import 'package:timezone/data/latest.dart';
// import 'package:webview_flutter/webview_flutter.dart';
import 'services/notification_service.dart';
// import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'screens/home_screen.dart';
import 'package:organize/screens/Tasks/presentation/screens/task_list_screen.dart';

import 'screens/splash_screen.dart';
import 'package:organize/screens/Auth/login_screen.dart';
import 'package:organize/screens/Auth/registration_screen.dart';

import 'services/settings_service.dart';

import 'screens/open_app_ad_manager.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  initializeTimeZones();

  try {
    await Firebase.initializeApp();
    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
    await Hive.initFlutter();
    await NotificationService().init();
    await NotificationService().requestPermission();

    Hive.registerAdapter(TaskAdapter());
    await Hive.openBox<Task>('taskBox');
    await Hive.openBox<Task>('tasks');

    setupFCM();

    final prefs = await SharedPreferences.getInstance();
    bool hasConsented = prefs.getBool('userConsent') ?? false;

    runApp(
      ChangeNotifierProvider(
        create: (context) => TaskProvider(),
        child: MyApp(hasConsented),
      ),
    );
  } catch (e) {}
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {}

class HiveService {
  static Box<Task>? _taskBox;

  static Future<Box<Task>> get taskBox async {
    _taskBox ??= await Hive.openBox<Task>('tasks');
    return _taskBox!;
  }
}

void setupFCM() {
  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    NotificationService().showNotification(
      message.notification?.title ?? 'New Notification',
      message.notification?.body ?? '',
    );
  });

  FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
    navigatorKey.currentState?.pushNamed(recentChatRoute);
    // navigator.of(Context)
    // print('Message clicked: ${message.messageId}');
  });
}

class MyApp extends StatefulWidget {
  // const MyApp({super.key});
  final bool hasConsented;
  MyApp(this.hasConsented);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  bool _darkMode = false;
  bool _adShownInThisSession = false;

  Color themeColor = Colors.red;
  // final OpenAppAdManager _adManager = OpenAppAdManager();
  StartAppInterstitialAd? interstitialAd;
  final startAppSdk = StartAppSdk();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // _adManager.loadAd();
    loadInterstitialAd();
    if (interstitialAd != null) {
      interstitialAd!.show().then((shown) {
        if (shown) {
          setState(() {
            // NOTE interstitial ad can be shown only once
            this.interstitialAd = null;

            // NOTE load again
            loadInterstitialAd();
          });
        }

        return null;
      }).onError((error, stackTrace) {
        debugPrint("Error showing Interstitial ad: $error");
      });
    }
    setOnlineStatus();
    _loadSettings();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      setOfflineStatus();
      stopHeartbeat();
      _updateSystemUI();
      _adShownInThisSession = false; // Reset for next resume
    } else if (state == AppLifecycleState.resumed) {
      // Only show ad if not shown yet in this resume cycle
      if (!_adShownInThisSession && interstitialAd != null) {
        interstitialAd!.show().then((shown) {
          if (shown) {
            setState(() {
              interstitialAd = null;
              loadInterstitialAd();
            });
            _adShownInThisSession = true; // Prevent multiple ads per resume
          }
          return null;
        }).onError((error, stackTrace) {
          debugPrint("Error showing Interstitial ad: $error");
        });
      }

      startHeartbeat();
      setOnlineStatus();
    }
  }

  void loadInterstitialAd() {
    startAppSdk.loadInterstitialAd().then((interstitialAd) {
      setState(() {
        this.interstitialAd = interstitialAd;
      });
    }).onError((ex, stackTrace) {
      debugPrint("Error loading Interstitial ad: ${ex}");
    }).onError((error, stackTrace) {
      debugPrint("Error loading Interstitial ad: $error");
    });
  }

  Future<void> updateUserStatus(bool isOnline) async {
    final user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      final userRef =
          FirebaseFirestore.instance.collection('users').doc(user.uid);

      try {
        await userRef.update({
          'isOnline': isOnline,
          if (!isOnline) 'lastSeen': FieldValue.serverTimestamp(),
        });
      } catch (e) {
        debugPrint('Failed to update user status: $e');
      }
    }
  }

  Timer? _heartbeatTimer;

  void startHeartbeat() {
    _heartbeatTimer?.cancel(); // cancel any previous
    _heartbeatTimer = Timer.periodic(Duration(seconds: 300), (_) {
      updateUserStatus(true); // update lastSeen every 30s
    });
  }

  void stopHeartbeat() {
    _heartbeatTimer?.cancel();
  }

// Call this when the app is opened
  void setOnlineStatus() {
    updateUserStatus(true);
  }

// Call this when the app is closed or goes to background
  void setOfflineStatus() {
    updateUserStatus(false);
  }

  @override
  void dispose() {
    setOfflineStatus();
    stopHeartbeat();

    WidgetsBinding.instance.removeObserver(
        this); // Removing the observer when the widget is disposed
    super.dispose();
  }

  void _loadSettings() async {
    final settingsService = SettingsService();
    final userId = FirebaseAuth.instance.currentUser?.uid;

    if (userId != null) {
      try {
        final settings = await settingsService.getSettings(userId);
        setState(() {
          _darkMode = settings.darkMode;
          themeColor = settings.themeColor;
        });
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _updateSystemUI();
        });
      } catch (e) {
        // print("Error loading settings: $e");
        _applyDefaultSettings();
      }
    } else {
      // print("No user logged in.");
      _applyDefaultSettings();
    }
  }

  @override
  void _updateSystemUI() {
    // print(
    //     'Updating System UI: Dark Mode = $_darkMode, Theme Color = $themeColor');

    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor:
            _darkMode ? Colors.black : Colors.white, // Change status bar color
        systemNavigationBarColor: _darkMode
            ? Colors.black
            : Colors.white, // Change navigation bar color
        systemNavigationBarIconBrightness: _darkMode
            ? Brightness.light
            : Brightness.dark, // Adjust icon brightness
      ),
    );
  }

  void _applyDefaultSettings() {
    setState(() {
      _darkMode = false;
      themeColor = Colors.blue;
    });
  }

  void _updateTheme(bool isDarkMode, Color newThemeColor) {
    setState(() {
      _darkMode = isDarkMode;
      themeColor = newThemeColor;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Organize',
      navigatorKey: navigatorKey,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: const AppBarTheme(
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          iconTheme: IconThemeData(color: Colors.black),
          titleTextStyle: TextStyle(color: Colors.black, fontSize: 20),
        ),
        cardColor: const Color.fromARGB(255, 255, 255, 255),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.black),
          bodyMedium: TextStyle(
              color: Color.fromARGB(183, 0, 0, 0), fontWeight: FontWeight.w700),
          bodySmall: TextStyle(
              color: Colors.black87, fontWeight: FontWeight.w500, fontSize: 16),
        ),
        iconTheme: const IconThemeData(color: Color.fromRGBO(96, 148, 238, 1)),
        // iconTheme: const IconThemeData(color: Color.fromRGBO(102, 102, 204, 1)),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.teal, // Button background color
            foregroundColor: Colors.black, // Button text color
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
          ),
        ),

        dropdownMenuTheme: DropdownMenuThemeData(
          menuStyle: MenuStyle(
            backgroundColor: WidgetStateProperty.all(Colors.white),
          ),
        ),
        popupMenuTheme: PopupMenuThemeData(
          color: Colors.white, // Background color of the popup menu
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.all(Radius.circular(8.0)), // Rounded corners
          ),
          textStyle: const TextStyle(
            color: Colors.black, // Text color of menu items
            fontWeight: FontWeight.w500,
          ),
          elevation: 4, // Elevation/shadow for the popup menu
        ),

        listTileTheme: const ListTileThemeData(
          tileColor: Colors.white, // Default background color for light theme
          textColor: Colors.black, // Default text color for light theme
          iconColor: Colors.black, // Icon color
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
          titleTextStyle: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
          subtitleTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            height: 1.2,
            color: Colors.grey,
          ),
        ),
      ),
      darkTheme: ThemeData(
        scaffoldBackgroundColor: Colors.black,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
          iconTheme: IconThemeData(color: Colors.white),
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
        ),
        bottomAppBarTheme: BottomAppBarTheme(
          color:
              Colors.black, // Background color of the BottomAppBar in dark mode
          elevation: 8,
        ),
        popupMenuTheme: PopupMenuThemeData(
          color: Colors.white, // Background color of the popup menu
          shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.all(Radius.circular(8.0)), // Rounded corners
          ),
          textStyle: const TextStyle(
            color: Colors.black, // Text color of menu items
            fontWeight: FontWeight.w500,
          ),
          elevation: 4, // Elevation/shadow for the popup menu
        ),
        cardColor: const Color.fromARGB(214, 0, 0, 0),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Colors.white),
          bodyMedium: TextStyle(
              color: Color.fromARGB(255, 224, 224, 224),
              fontWeight: FontWeight.w700),
          bodySmall: TextStyle(
              color: Color.fromARGB(176, 255, 255, 255),
              fontWeight: FontWeight.w500,
              fontSize: 16),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor:
                Colors.grey, // Button background color for dark theme
            foregroundColor: Colors.black, // Button text color for dark theme
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
          ),
        ),
        dropdownMenuTheme: DropdownMenuThemeData(
          menuStyle: MenuStyle(
            backgroundColor: WidgetStateProperty.all(Colors.black),
          ),
        ),
        listTileTheme: const ListTileThemeData(
          tileColor: Colors.black, // Default background color for dark theme
          textColor: Colors.white, // Default text color for dark theme
          iconColor: Colors.white, // Icon color
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(16)),
          ),
          titleTextStyle: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
          subtitleTextStyle: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            height: 1.2,
            color: Colors.white54,
          ),
        ),
      ),
      themeMode: _darkMode ? ThemeMode.dark : ThemeMode.light,
      home: _buildHome(),
      routes: _buildRoutes(),
    );
  }

  Widget _buildHome() {
    return FutureBuilder<bool>(
      future: _checkConsent(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }
        if (snapshot.hasError) {
          return Center(child: Text("Error: \${snapshot.error}"));
        }
        if (snapshot.hasData && !snapshot.data!) {
          return ConsentScreen(); // Show ConsentScreen if user hasn't given consent
        }
        return _buildAuthCheck();
      },
    );
  }

  Future<bool> _checkConsent() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('userConsent') ?? false;
  }

  Widget _buildAuthCheck() {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: Colors.blueAccent));
        }
        if (snapshot.hasError) {
          return Center(child: Text("Error: \${snapshot.error}"));
        }
        if (snapshot.hasData) {
          return SplashScreen();
          // return ConsentScreen();
        }
        return const LoginScreen();
      },
    );
  }

  Map<String, WidgetBuilder> _buildRoutes() {
    return {
      splashRoute: (context) => SplashScreen(),
      loginRoute: (context) => const LoginScreen(),
      registerRoute: (context) => const RegistrationScreen(),
      homeRoute: (context) => _getHomeScreen(context),
      taskRoute: (context) => const TaskListScreen(),
      authRoute: (context) => const AuthScreen(),
      profileRoute: (context) => const ProfileScreen(),
      settingsRoute: (context) => _getSettingsScreen(context),
      socialRoute: (context) => SocialScreen(),
      recentChatRoute: (context) => RecentChatsScreen(),
      friendRequestRoute: (context) => FriendRequestScreen(),
      financeScreenRoute: (context) => FinanceScreen(),
      financeOverviewRoute: (context) => FinanceOverviewScreen(),
      budgetRoute: (context) => BudgetManagementScreen(),
      expenseRoute: (context) => ExpenseTrackingScreen(),
      financialGoalRoute: (context) => FinancialGoalsScreen(),
    };
  }

  Widget _getHomeScreen(BuildContext context) {
    final userId = _getUserId();
    return userId != null ? HomeScreen(userId: userId) : const LoginScreen();
  }

  Widget _getSettingsScreen(BuildContext context) {
    final userId = _getUserId();
    return userId != null
        ? SettingsScreen(onThemeChange: _updateTheme, userId: userId)
        : const LoginScreen();
  }

  String? _getUserId() {
    return FirebaseAuth.instance.currentUser?.uid;
  }
}
