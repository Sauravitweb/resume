   import 'package:flutter/material.dart';

late TextEditingController titleController;
  late TextEditingController descriptionController;

 
 final List<String> categories = [
    'Home',
    'Work',
    'Personal',
    'Shopping',
    'Office',
    'School',
    'College',
    'Others'
  ];
    Color getPriorityColor(String? priority) {
    switch (priority) {
      case 'High':
        return Colors.redAccent;
      case 'Medium':
        return Colors.orangeAccent;
      case 'Low':
        return Colors.greenAccent;
      default:
        return Colors.blueGrey;
    }
  }

Color bordercolor = const Color.fromARGB(255, 58, 56, 70);
  final List<String> priorities = ['High', 'Medium', 'Low'];

