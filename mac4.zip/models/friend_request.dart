class FriendRequest {
  final String id;
  final String from;
  final String to;
  final String status;

  FriendRequest(
      {required this.id,
      required this.from,
      required this.to,
      required this.status});

  Map<String, dynamic> toMap() {
    return {
      'from': from,
      'to': to,
      'status': status,
    };
  }

  FriendRequest.fromMap(String id, Map<String, dynamic> data)
      : id = id,
        from = data['from'],
        to = data['to'],
        status = data['status'];
}
