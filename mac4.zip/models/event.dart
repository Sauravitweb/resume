class Event {
  final String id; // Firestore document ID
  final String title;
  final DateTime dateTime;
  final String location;
  final List<String> invitees; // Assuming invitees is a List of Strings

  Event({
    required this.id,
    required this.title,
    required this.dateTime,
    required this.location,
    required this.invitees, // Include invitees in the constructor
  });
}
