import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Settings {
  final bool darkMode;
  final bool notificationsEnabled;
  final String language;
  final double fontSize;
  final TimeOfDay? reminderTime;
  final String userId;
  final Color themeColor; // Add themeColor field

  Settings({
    required this.darkMode,
    required this.notificationsEnabled,
    required this.language,
    required this.fontSize,
    this.reminderTime,
    required this.userId,
    required this.themeColor, // Include themeColor in the constructor
  });

  // Convert Firestore map to Settings
  factory Settings.fromMap(Map<String, dynamic> map) {
    return Settings(
      darkMode: map['darkMode'] ?? false,
      notificationsEnabled: map['notificationsEnabled'] ?? true,
      language: map['language'] ?? 'en',
      fontSize: map['fontSize'] ?? 14.0,
      reminderTime: map['reminderTime'] != null
          ? TimeOfDay.fromDateTime((map['reminderTime'] as Timestamp).toDate())
          : null,
      userId: map['userId'] ?? '',
      themeColor:
          _fromHex(map['themeColor'] ?? '#80D0FF'), // Default to Soft Blue
    );
  }

  // Convert Settings to Firestore map
  Map<String, dynamic> toMap() {
    return {
      'darkMode': darkMode,
      'notificationsEnabled': notificationsEnabled,
      'language': language,
      'fontSize': fontSize,
      'reminderTime': reminderTime != null
          ? Timestamp.fromDate(
              DateTime(1970, 1, 1, reminderTime!.hour, reminderTime!.minute))
          : null,
      'userId': userId,
      'themeColor': _toHex(themeColor), // Save themeColor as hex
    };
  }

  // Helper to convert Color to Hex
  String _toHex(Color color) {
    return '#${color.value.toRadixString(16).substring(2)}';
  }

  // Helper to convert Hex to Color
  static Color _fromHex(String hex) {
    final buffer = StringBuffer();
    if (hex.length == 6 || hex.length == 7) buffer.write('ff');
    buffer.write(hex.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
