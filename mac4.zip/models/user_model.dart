// user_model.dart
class UserModel {
  final String userId;
  final String userName;
  final String? profilePictureUrl;
  final List<String> friends;

  UserModel({
    required this.userId,
    required this.userName,
    this.profilePictureUrl,
    this.friends = const [],
  });

  // Method to convert UserModel to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'userName': userName,
      'profilePictureUrl': profilePictureUrl,
      'friends': friends,
    };
  }

  // Factory method to create UserModel from Firestore map
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      userId: map['userId'],
      userName: map['userName'],
      profilePictureUrl: map['profilePictureUrl'],
      friends: List<String>.from(map['friends']),
    );
  }
}
