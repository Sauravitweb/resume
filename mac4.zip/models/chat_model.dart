import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMessage {
  final String senderId;
  final String recipientId;
  final String text;
  final String userName; // Added userName
  final Timestamp timestamp;

  ChatMessage({
    required this.senderId,
    required this.recipientId,
    required this.text,
    required this.userName, // Initialize userName
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'senderId': senderId,
      'recipientId': recipientId,
      'text': text,
      'userName': userName, // Include userName
      'timestamp': timestamp,
    };
  }

  factory ChatMessage.fromMap(Map<String, dynamic> map) {
    return ChatMessage(
      senderId: map['senderId'],
      recipientId: map['recipientId'],
      text: map['text'],
      userName: map['userName'], // Fetch userName from map
      timestamp: map['timestamp'],
    );
  }
}
