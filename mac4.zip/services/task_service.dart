import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:hive/hive.dart';
import 'package:organize/screens/Tasks/data/models/task.dart';

import 'notification_service.dart';

class TaskService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final NotificationService _notificationService = NotificationService();
  final Box<Task> _taskBox = Hive.box('taskBox');

  // / Stream to get user-specific tasks with optional filtering for completion status
  Stream<List<Task>> getUserTasks(String userId,
      {bool showCompleted = true, bool showDeleted = false}) {
    return _db
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .where('isCompleted', isEqualTo: showCompleted) // Dynamic filter
        .where('isDeleted', isEqualTo: showDeleted)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Task.fromMap(doc.data(), doc.id))
            .toList());
  }

  Stream<List<Task>> gotUserTasks(String userId,
      {bool showCompleted = false, bool showDeleted = false}) {
    return _db
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .where('isCompleted', isEqualTo: showCompleted) // Dynamic filter
        .where('isDeleted', isEqualTo: showDeleted)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Task.fromMap(doc.data(), doc.id))
            .toList());
  }

  Stream<List<Task>> recyclegetUserTasks(String userId,
      {bool? showCompleted, bool showDeleted = false}) {
    var query = _db
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .where('isDeleted', isEqualTo: showDeleted);

    if (showCompleted != null) {
      query = query.where('isCompleted', isEqualTo: showCompleted);
    }

    return query.snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => Task.fromMap(doc.data(), doc.id)).toList());
  }

  /// Add a new task to the database
  Future<void> addTask(Task task) async {
    await _db.collection('tasks').add(task.toMap());

    // Schedule a notification for the task due date
    final duration = task.dueDate.difference(DateTime.now());
    // final duration = reminderDateTime!.toLocal();

    if (duration.inSeconds > 0) {
      Future.delayed(duration, () {
        _notificationService.showNotification(
          'Task Reminder',
          'Don\'t forget to complete ${task.title}\n${task.description}',
        );
      });
    }
  }

  Future<void> editTask(String taskId, Task updatedTask) async {
    // Update the task in the database
    await _db.collection('tasks').doc(taskId).update(updatedTask.toMap());

    // Reschedule the notification for the updated due date
    final duration = updatedTask.dueDate.difference(DateTime.now());

    if (duration.inSeconds > 0) {
      Future.delayed(duration, () {
        _notificationService.showNotification(
          'Task Reminder',
          'Don\'t forget to complete ${updatedTask.title}\n${updatedTask.description}',
        );
      });
    }
  }

  /// Update specific fields of a task
  Future<void> updateTask(
      String taskId, Map<String, dynamic> updatedFields) async {
    await _db.collection('tasks').doc(taskId).update(updatedFields);
  }

  Future<void> deleteTask(String taskId,
      {bool permanentlyDelete = false}) async {
    final taskDoc = await _db.collection('tasks').doc(taskId).get();

    if (taskDoc.exists) {
      if (permanentlyDelete) {
        // If permanentlyDelete is true, delete the task permanently from both the tasks and recycle_bin collections
        // Move to Recycle Bin
        await _db
            .collection('tasks')
            .doc(taskId)
            .delete(); // Permanently delete from tasks
      } else {
        // Otherwise, just mark it as deleted in the tasks collection
        await _db
            .collection('tasks')
            .doc(taskId)
            .update({'isDeleted': true}); // Mark task as deleted
      }
    }
  }

  Future<void> deletedTask(String taskId) async {
    await _db.collection('tasks').doc(taskId).delete();
  }

  // Restore a deleted task
  Future<void> restoreTask(String taskId) async {
    await _db.collection('tasks').doc(taskId).update({'isDeleted': false});
  }

  /// Mark a task as completed
  // Future<void> markTaskAsCompleted(String taskId) async {
  //   await updateTask(taskId, {'isCompleted': true});
  // }
  Future<void> markTaskAsCompleted(String taskId) async {
    final taskRef = _db.collection('tasks').doc(taskId);
    final taskDoc = await taskRef.get();

    if (taskDoc.exists) {
      final currentStatus = taskDoc['isCompleted'] ?? false;
      await taskRef.update({
        'isCompleted': !currentStatus, // Toggle the completion status
      });
    }
  }

  Future<void> saveTaskOffline(Task task) async {
    try {
      // Save the task to the box
      await _taskBox.add(task);
    } catch (error) {
      throw 'Error saving task offline: $error';
    }
  }

  /// Set the priority level of a task
  Future<void> setTaskPriority(String taskId, String priority) async {
    await updateTask(taskId, {'priority': priority});
  }

  /// Set a reminder for a task and schedule a notification
  Future<void> setReminderForTask(String taskId, DateTime reminderTime) async {
    await updateTask(taskId, {'reminderTime': reminderTime.toIso8601String()});

    final duration = reminderTime.difference(DateTime.now());
    if (duration.inSeconds > 0) {
      Future.delayed(duration, () {
        _notificationService.showNotification(
          'Task Reminder',
          'Reminder for your task!',
        );
      });
    }
  }

  /// Refresh tasks logic (optional implementation placeholder)
  Future<void> refreshTasks() async {
    // Implement logic to refresh tasks if needed
  }

  /// Stream for real-time updates of all tasks
  Stream<List<Task>> getAllTasks() {
    return _db.collection('tasks').snapshots().map((snapshot) =>
        snapshot.docs.map((doc) => Task.fromMap(doc.data(), doc.id)).toList());
  }

  /// Stream to get only incomplete tasks
  Stream<List<Task>> getIncompletedTasks(String userId) {
    return _db
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .where('isCompleted', isEqualTo: false)
        .where('isDeleted', isEqualTo: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Task.fromMap(doc.data(), doc.id))
            .toList());
  }

  /// Stream to get only completed tasks
  Stream<List<Task>> getCompletedTasks(String userId) {
    return _db
        .collection('tasks')
        .where('userId', isEqualTo: userId)
        .where('isCompleted', isEqualTo: true)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => Task.fromMap(doc.data(), doc.id))
            .toList());
  }

  Future<void> syncTasks() async {
    final box = await Hive.openBox<Task>('taskBox');
    final tasks = box.values.toList();

    for (var task in tasks) {
      try {
        await addTask(task); // Add task to Firebase
        await box.delete(task.id); // Remove from Hive after successful sync
      } catch (error) {
        // print('Error syncing task: $error');
      }
    }
  }

  /// Placeholder for additional task fetching logic
  Future<List<Task>> getTasks() async {
    // Implement additional logic if needed
    return [];
  }
}
