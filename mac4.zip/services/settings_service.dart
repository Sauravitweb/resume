import 'package:cloud_firestore/cloud_firestore.dart' as firestore;
import '../models/settings.dart';
import 'package:flutter/material.dart'; // Required for TimeOfDay

class SettingsService {
  final firestore.FirebaseFirestore _db = firestore.FirebaseFirestore.instance;

  Future<Settings> getSettings(String userId) async {
    final snapshot = await _db.collection('settings').doc(userId).get();

    if (snapshot.exists) {
      return Settings.fromMap(snapshot.data()!);
    } else {
      // Return default settings if none exist in Firestore
      return Settings(
        darkMode: false,
        notificationsEnabled: true,
        language: 'en',
        fontSize: 14.0,
        reminderTime: TimeOfDay.now(), // Default reminder time
        userId: userId, // Ensure the userId is set
        themeColor: Colors.blue, // Default theme color
      );
    }
  }

  Future<void> updateSettings(
    String userId, // Accept userId as a parameter
    bool darkMode,
    bool notificationsEnabled, {
    String? language,
    double? fontSize,
    TimeOfDay? reminderTime,
    Color? themeColor, // New themeColor parameter
  }) async {
    final settings = Settings(
      darkMode: darkMode,
      notificationsEnabled: notificationsEnabled,
      language: language ?? 'en', // Default to 'en' if null
      fontSize: fontSize ?? 14.0, // Default to 14.0 if null
      reminderTime: reminderTime, // Set the reminder time
      userId: userId, // Set the user ID
      themeColor: themeColor ?? Colors.blue, // Default themeColor if null
    );

    // Update the settings in Firestore
    await _db.collection('settings').doc(userId).set(settings.toMap());
  }
}
