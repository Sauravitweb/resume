import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:organize/screens/Social/social_screen.dart';

class Event {
  final String id; // Firestore document ID
  final String title;
  final DateTime dateTime;
  final String location;
  final List<String> invitees; // Assuming invitees is a List of Strings

  Event({
    required this.id,
    required this.title,
    required this.dateTime,
    required this.location,
    required this.invitees, // Include invitees in the constructor
  });
}

class EventService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Add a new event to the database
  Future<void> createEvent(String title, DateTime dateTime, String location,
      List<String> invitees) async {
    await _firestore.collection('events').add({
      'title': title,
      'dateTime': dateTime,
      'location': location,
      'invitees': invitees,
    });
  }

  // Fetch all events from the database
  Future<List<Map<String, dynamic>>> getEvents() async {
    final snapshot = await _firestore.collection('events').get();
    return snapshot.docs.map((doc) {
      final data = doc.data();
      return {
        'id': doc.id, // Add the document ID
        ...data,
      };
    }).toList();
  }

  // Update an existing event in the database
  Future<void> updateEvent(Event event) async {
    await _firestore.collection('events').doc(event.id).update({
      'title': event.title,
      'dateTime': event.dateTime,
      'location': event.location,
      // You can add other fields if necessary
    });
  }

  // Delete an event from the database
  Future<void> deleteEvent(String eventId) async {
    await _firestore.collection('events').doc(eventId).delete();
  }
}
