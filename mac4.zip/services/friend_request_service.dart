// friend_request_service.dart
import 'package:cloud_firestore/cloud_firestore.dart';

class FriendRequestService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Method to send a friend request
  Future<void> sendyFriendRequest(String currentUserId, String friendId) async {
    await _firestore.collection('friend_requests').add({
      'fromUserId': currentUserId,
      'toUserId': friendId,
      'status': 'pending',
      'timestamp': FieldValue.serverTimestamp(),
    });
  }

  // Method to accept a friend request
  Future<void> acceptFriendRequest(
      String requestId, String currentUserId, String friendId) async {
    // Update friend request status
    await _firestore.collection('friend_requests').doc(requestId).update({
      'status': 'accepted',
    });

    // Add each other to friends list
    await _firestore.collection('users').doc(currentUserId).update({
      'friends': FieldValue.arrayUnion([friendId]),
    });
    await _firestore.collection('users').doc(friendId).update({
      'friends': FieldValue.arrayUnion([currentUserId]),
    });
  }

  // Method to reject a friend request
  Future<void> rejectFriendRequest(String requestId) async {
    await _firestore.collection('friend_requests').doc(requestId).update({
      'status': 'rejected',
    });
  }
}
