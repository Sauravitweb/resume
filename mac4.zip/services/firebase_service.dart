import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:organize/models/chat_model.dart';
import '../models/chat_model.dart';
import '../models/user_model.dart';

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> sendMessage(String chatId, ChatMessage message) async {
    await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .add(message.toMap());
  }

  Future<List<ChatMessage>> fetchMessages(String chatId) async {
    final snapshot = await _firestore
        .collection('chats')
        .doc(chatId)
        .collection('messages')
        .orderBy('timestamp')
        .get();
    return snapshot.docs.map((doc) => ChatMessage.fromMap(doc.data())).toList();
  }

  Future<UserModel> fetchUser(String userId) async {
    final snapshot = await _firestore.collection('users').doc(userId).get();
    return UserModel.fromMap(snapshot.data() as Map<String, dynamic>);
  }
}
