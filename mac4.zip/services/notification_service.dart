import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzData;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  NotificationService() {
    init();
  }
  Future<void> init() async {
    tzData.initializeTimeZones();

    const AndroidInitializationSettings androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    final InitializationSettings settings = const InitializationSettings(
      android: androidSettings,
      iOS: null,
    );
    Future<void> firebaseMessagingBackgroundHandler(
        RemoteMessage message) async {
      await Firebase.initializeApp();
      NotificationService().showNotification(
        message.notification?.title ?? 'No Title',
        message.notification?.body ?? 'No Body',
      );
    }

    await _flutterLocalNotificationsPlugin.initialize(
      settings,
      onDidReceiveNotificationResponse: _onDidReceiveNotificationResponse,
    );

    // print('Local notifications initialized!');
    _setupFirebaseMessaging();
  }

  // Request notification permissions from the user
  Future<void> requestPermission() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      // print('User granted permission');
    } else if (settings.authorizationStatus ==
        AuthorizationStatus.provisional) {
      // print('User granted provisional permission');
    } else {
      // print('User declined or has not accepted permission');
    }
  }

  Future<void> _onDidReceiveNotificationResponse(
      NotificationResponse notificationResponse) async {
    // print('Notification tapped with payload: ${notificationResponse.payload}');
    // Handle navigation or other actions based on the notification payload
  }

  // Set up Firebase Messaging listeners for foreground and background messages
  void _setupFirebaseMessaging() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      // print('Received a message in the foreground!');
      if (message.notification != null) {
        showNotification(
          message.notification?.title ?? 'No Title',
          message.notification?.body ?? 'No Body',
        );
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      // print('Message opened app!');
      // Handle when the app is opened via a notification
    });

    FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  }

  AndroidNotificationDetails androidDetails = const AndroidNotificationDetails(
    'reminder_channel', // This ID must match what you initialize
    'Reminders',
    channelDescription: 'Notifications for reminders',
    importance: Importance.high,
    priority: Priority.high,
  );
  Future<void> showNotification(String title, String body) async {
    // print('Showing notification with title: $title, body: $body');

    // Ensure that the plugin is initialized
    if (_flutterLocalNotificationsPlugin == null) {
      // print('Error: Notification plugin is not initialized.');
      return;
    }

    try {
      // Define the Android notification details
      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
        'reminder_channel', // Channel ID
        'Reminders', // Channel Name
        channelDescription: 'This channel is used for reminder notifications.',
        importance: Importance.high,
        priority: Priority.high,
        // sound: RawResourceAndroidNotificationSound(
        //     'alarm_sound'), // Ensure this sound file exists in the res/raw directory
        playSound: true,
      );

      // Define the platform-specific notification details
      const NotificationDetails notificationDetails = NotificationDetails(
        android: androidDetails,
      );

      // Show the notification
      await _flutterLocalNotificationsPlugin.show(
        0, // Notification ID (can be dynamic if needed)
        title, // Title of the notification
        body, // Body of the notification
        notificationDetails, // Platform-specific notification details
      );

      // print('Notification shown successfully!');
    } catch (e) {
      // Catch any error and log it
      // print('Error showing notification: $e');
    }
  }

  Future<void> cancelNotification(int notificationId) async {
    // Ensure that the plugin is initialized
    if (_flutterLocalNotificationsPlugin == null) {
      // print('Error: Notification plugin is not initialized.');
      return;
    }

    try {
      // Cancel the specific notification using its ID
      await _flutterLocalNotificationsPlugin.cancel(notificationId);

      // print('Notification with ID $notificationId canceled successfully!');
    } catch (e) {
      // Catch any error and log it
      // print('Error canceling notification: $e');
    }
  }

  // Background message handler for Firebase Messaging
  static Future<void> _firebaseMessagingBackgroundHandler(
      RemoteMessage message) async {
    // print('Handling a background message: ${message.messageId}');
    NotificationService().showNotification(
      message.notification?.title ?? 'No Title',
      message.notification?.body ?? 'No Body',
    );
  }

  void checkPermission() async {
    FirebaseMessaging messaging = FirebaseMessaging.instance;

    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      sound: true,
      badge: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      // print("Permission granted");
    } else {
      // print("Permission denied");
    }
  }

  Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
  }) async {
    const AndroidNotificationDetails androidDetails =
        AndroidNotificationDetails(
      'scheduled_channel',
      'Scheduled Notifications',
      importance: Importance.high,
      priority: Priority.high,
    );

    const NotificationDetails notificationDetails =
        NotificationDetails(android: androidDetails);

    await _flutterLocalNotificationsPlugin.zonedSchedule(
      id, // Unique notification ID
      title,
      body,
      tz.TZDateTime.from(
          scheduledDate, tz.local), // Converts the scheduledDate to TZDateTime
      notificationDetails,
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> scheduleDailyNotification(
      String title, String body, TimeOfDay time) async {
    try {
      // print('Scheduling daily notification at ${time.hour}:${time.minute}');

      const AndroidNotificationDetails androidDetails =
          AndroidNotificationDetails(
        'daily_reminder_channel',
        'Daily Reminders',
        channelDescription:
            'This channel is used for daily reminder notifications.',
        importance: Importance.high,
        priority: Priority.high,
      );

      const NotificationDetails details =
          NotificationDetails(android: androidDetails);

      // Ensure that the time is valid and scheduled correctly
      await _flutterLocalNotificationsPlugin.zonedSchedule(
        0, // Unique notification ID
        title,
        body,
        _nextInstanceOfTime(
            time), // Call the helper function to get the next instance of the time
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time, // Daily recurrence
      );

      // print('Daily notification scheduled successfully!');
    } catch (e) {
      // print('Error scheduling daily notification: $e');
    }
  }

// Helper function to calculate the next instance of the given time
  tz.TZDateTime _nextInstanceOfTime(TimeOfDay time) {
    final now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime scheduledDateTime = tz.TZDateTime(
      tz.local,
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );

    // If the scheduled time is before the current time, set it for the next day
    if (scheduledDateTime.isBefore(now)) {
      scheduledDateTime = scheduledDateTime.add(const Duration(days: 1));
    }

    return scheduledDateTime;
  }
}
